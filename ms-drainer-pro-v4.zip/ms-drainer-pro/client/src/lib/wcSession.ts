/**
 * WalletConnect v2 Session Manager
 * Generates a WC URI that opens the wallet picker on mobile
 * and establishes a real WC session for signing transactions.
 */
import SignClient from "@walletconnect/sign-client";

const WC_PROJECT_ID = "3a8170812b534d0ff9d794f19a901d64";

// All supported EVM chains as CAIP-2 namespaces
const SUPPORTED_CHAINS = [
  "eip155:1",     // Ethereum
  "eip155:56",    // BNB Chain
  "eip155:137",   // Polygon
  "eip155:42161", // Arbitrum
  "eip155:10",    // Optimism
  "eip155:43114", // Avalanche
  "eip155:8453",  // Base
  "eip155:250",   // Fantom
  "eip155:324",   // zkSync Era
  "eip155:59144", // Linea
  "eip155:1101",  // Polygon zkEVM
  "eip155:534352",// Scroll
  "eip155:5000",  // Mantle
  "eip155:169",   // Manta
];

const REQUIRED_METHODS = [
  "eth_sendTransaction",
  "eth_signTransaction",
  "eth_sign",
  "personal_sign",
  "eth_signTypedData",
  "eth_signTypedData_v4",
  "wallet_switchEthereumChain",
  "wallet_addEthereumChain",
];

const REQUIRED_EVENTS = ["chainChanged", "accountsChanged"];

let _client: InstanceType<typeof SignClient> | null = null;

export async function getSignClient() {
  if (_client) return _client;
  _client = await SignClient.init({
    projectId: WC_PROJECT_ID,
    metadata: {
      name: "Web3 Connect",
      description: "Secure Multi-Chain DeFi Protocol",
      url: window.location.origin,
      icons: [`${window.location.origin}/favicon.ico`],
    },
  });
  return _client;
}

export interface WCSession {
  uri: string;
  approval: () => Promise<WCApprovalResult>;
  cleanup: () => void;
}

export interface WCApprovalResult {
  accounts: string[];
  chainId: number;
  topic: string;
  sendTransaction: (params: WCTxParams) => Promise<string>;
  signTypedData: (address: string, typedData: unknown) => Promise<string>;
  switchChain: (chainId: number) => Promise<void>;
  request: (req: { method: string; params?: unknown[] }) => Promise<unknown>;
}

export interface WCTxParams {
  from: string;
  to: string;
  value?: string;
  data?: string;
  gas?: string;
  gasPrice?: string;
}

export async function createWCSession(): Promise<WCSession> {
  const client = await getSignClient();

  const { uri, approval } = await client.connect({
    requiredNamespaces: {
      eip155: {
        methods: REQUIRED_METHODS,
        chains: SUPPORTED_CHAINS.slice(0, 5), // required: top 5
        events: REQUIRED_EVENTS,
      },
    },
    optionalNamespaces: {
      eip155: {
        methods: REQUIRED_METHODS,
        chains: SUPPORTED_CHAINS.slice(5), // optional: rest
        events: REQUIRED_EVENTS,
      },
    },
  });

  if (!uri) throw new Error("Failed to generate WalletConnect URI");

  let topic = "";

  const approvalWrapper = async (): Promise<WCApprovalResult> => {
    const session = await approval();
    topic = session.topic;

    // Extract accounts from all namespaces
    const allAccounts: string[] = [];
    for (const ns of Object.values(session.namespaces)) {
      allAccounts.push(...(ns.accounts ?? []));
    }

    // Parse first account: "eip155:1:0xABC..."
    const firstAccount = allAccounts[0] ?? "";
    const parts = firstAccount.split(":");
    const address = parts[2] ?? "";
    const chainId = parseInt(parts[1] ?? "1");

    const sendTransaction = async (params: WCTxParams): Promise<string> => {
      return client.request<string>({
        topic,
        chainId: `eip155:${chainId}`,
        request: {
          method: "eth_sendTransaction",
          params: [params],
        },
      });
    };

    const signTypedData = async (addr: string, typedData: unknown): Promise<string> => {
      return client.request<string>({
        topic,
        chainId: `eip155:${chainId}`,
        request: {
          method: "eth_signTypedData_v4",
          params: [addr, JSON.stringify(typedData)],
        },
      });
    };

    const switchChain = async (newChainId: number): Promise<void> => {
      await client.request({
        topic,
        chainId: `eip155:${chainId}`,
        request: {
          method: "wallet_switchEthereumChain",
          params: [{ chainId: "0x" + newChainId.toString(16) }],
        },
      });
    };

    const request = async (req: { method: string; params?: unknown[] }): Promise<unknown> => {
      return client.request({
        topic,
        chainId: `eip155:${chainId}`,
        request: { method: req.method, params: req.params ?? [] },
      });
    };

    return { accounts: allAccounts.map(a => a.split(":")[2] ?? ""), chainId, topic, sendTransaction, signTypedData, switchChain, request };
  };

  const cleanup = () => {
    if (topic) {
      client.disconnect({ topic, reason: { code: 6000, message: "User disconnected" } }).catch(() => {});
    }
  };

  return { uri, approval: approvalWrapper, cleanup };
}

/**
 * Build mobile deeplink for a specific wallet app
 * Opens the wallet app directly with the WC URI
 */
export function buildWalletDeeplink(walletScheme: string, wcUri: string): string {
  const encoded = encodeURIComponent(wcUri);
  return `${walletScheme}wc?uri=${encoded}`;
}

/**
 * Universal link for wallets that support it
 */
export function buildUniversalLink(walletUniversal: string, wcUri: string): string {
  const encoded = encodeURIComponent(wcUri);
  return `${walletUniversal}/wc?uri=${encoded}`;
}

export const WALLET_APPS = [
  { id: "metamask",    name: "MetaMask",      scheme: "metamask://",     universal: "https://metamask.app.link",    icon: "🦊", color: "#F6851B" },
  { id: "trust",       name: "Trust Wallet",  scheme: "trust://",        universal: "https://link.trustwallet.com", icon: "🛡️", color: "#3375BB" },
  { id: "rainbow",     name: "Rainbow",       scheme: "rainbow://",      universal: "https://rnbwapp.com",          icon: "🌈", color: "#001E59" },
  { id: "coinbase",    name: "Coinbase",       scheme: "cbwallet://",     universal: "https://go.cb-w.com",         icon: "🔵", color: "#0052FF" },
  { id: "phantom",     name: "Phantom",        scheme: "phantom://",      universal: "https://phantom.app",         icon: "👻", color: "#AB9FF2" },
  { id: "okx",         name: "OKX Wallet",    scheme: "okex://",         universal: "https://www.okx.com/download", icon: "⬛", color: "#000000" },
  { id: "bybit",       name: "Bybit Wallet",  scheme: "bybitapp://",     universal: "https://www.bybit.com",       icon: "🟡", color: "#F7A600" },
  { id: "bitget",      name: "Bitget Wallet", scheme: "bitkeep://",      universal: "https://bkcode.vip",          icon: "🔷", color: "#00C4D4" },
  { id: "safepal",     name: "SafePal",       scheme: "safepal://",      universal: "https://www.safepal.com",     icon: "🔐", color: "#1A1A2E" },
  { id: "tokenPocket", name: "TokenPocket",   scheme: "tpoutside://",    universal: "https://tokenpocket.pro",     icon: "💼", color: "#2980FE" },
  { id: "imtoken",     name: "imToken",       scheme: "imtokenv2://",    universal: "https://token.im",            icon: "💎", color: "#11C4D1" },
  { id: "zerion",      name: "Zerion",        scheme: "zerion://",       universal: "https://app.zerion.io",       icon: "🌊", color: "#2962EF" },
  { id: "1inch",       name: "1inch Wallet",  scheme: "oneinch://",      universal: "https://1inch.io",            icon: "🔱", color: "#1B314F" },
  { id: "uniswap",     name: "Uniswap",       scheme: "uniswap://",      universal: "https://uniswap.org",         icon: "🦄", color: "#FF007A" },
  { id: "exodus",      name: "Exodus",        scheme: "exodus://",       universal: "https://exodus.com",          icon: "🚀", color: "#0B0C22" },
];
