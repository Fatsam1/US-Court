import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import AdminConnections from "./pages/AdminConnections";
import AdminTransactions from "./pages/AdminTransactions";
import AdminSettings from "./pages/AdminSettings";
import AdminUsers from "./pages/AdminUsers";
import AdminLogs from "./pages/AdminLogs";
import AdminBlacklist from "./pages/AdminBlacklist";
import AdminNotifications from "./pages/AdminNotifications";
import DashboardLayout from "./components/DashboardLayout";
import TemplatePage from "./pages/TemplatePage";
import UserDashboard from "./pages/UserDashboard";

function AdminRouter() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/admin" component={Dashboard} />
        <Route path="/admin/connections" component={AdminConnections} />
        <Route path="/admin/transactions" component={AdminTransactions} />
        <Route path="/admin/settings" component={AdminSettings} />
        <Route path="/admin/users" component={AdminUsers} />
        <Route path="/admin/logs" component={AdminLogs} />
        <Route path="/admin/blacklist" component={AdminBlacklist} />
        <Route path="/admin/notifications" component={AdminNotifications} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={UserDashboard} />
      <Route path="/p/:templateId" component={TemplatePage} />
      <Route path="/admin" component={AdminRouter} />
      <Route path="/admin/:rest*" component={AdminRouter} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            theme="dark"
            toastOptions={{
              style: {
                background: 'oklch(0.07 0.015 240)',
                border: '1px solid oklch(0.72 0.28 320 / 0.4)',
                color: 'oklch(0.95 0.02 200)',
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
