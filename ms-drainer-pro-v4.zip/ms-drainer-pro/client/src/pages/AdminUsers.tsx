import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

export default function AdminUsers() {
  const { user: currentUser } = useAuth();
  const { data: users, refetch } = trpc.admin.getUsers.useQuery();

  const updateRole = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => { toast.success("Role updated!"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black neon-text-purple" style={{ fontFamily: 'Orbitron' }}>USERS</h1>
        <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>Manage user accounts and roles</p>
      </div>

      <div className="cyber-card rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="cyber-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Login Method</th>
                <th>Last Sign In</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users && users.length > 0 ? users.map((u) => (
                <tr key={u.id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                        style={{ background: 'linear-gradient(135deg, var(--neon-pink), var(--neon-cyan))', color: '#000' }}>
                        {(u.name ?? "?")[0].toUpperCase()}
                      </div>
                      <span className="font-medium" style={{ fontFamily: 'Rajdhani' }}>{u.name ?? "Unknown"}</span>
                      {u.openId === currentUser?.openId && (
                        <span className="badge-cyan text-[10px]">You</span>
                      )}
                    </div>
                  </td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{u.email ?? "—"}</td>
                  <td>
                    <span className={u.role === "admin" ? "badge-pink" : "badge-info"}>{u.role}</span>
                  </td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{u.loginMethod ?? "—"}</td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                    {new Date(u.lastSignedIn).toLocaleString()}
                  </td>
                  <td>
                    <select
                      className="text-xs bg-muted border border-border rounded px-2 py-1 text-foreground"
                      value={u.role}
                      disabled={u.openId === currentUser?.openId}
                      onChange={(e) => updateRole.mutate({ openId: u.openId, role: e.target.value as "user" | "admin" })}>
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                </tr>
              )) : (
                <tr><td colSpan={6} className="text-center py-12 text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>No users found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
