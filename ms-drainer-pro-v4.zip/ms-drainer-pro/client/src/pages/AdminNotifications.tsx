import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminNotifications() {
  const { data: notifications, refetch } = trpc.admin.getNotifications.useQuery({ limit: 50 });

  const markRead = trpc.admin.markNotificationRead.useMutation({
    onSuccess: () => refetch(),
  });
  const markAll = trpc.admin.markAllNotificationsRead.useMutation({
    onSuccess: () => { toast.success("All marked as read"); refetch(); },
  });

  const typeBadge = (type: string) => {
    const map: Record<string, string> = { success: "badge-success", error: "badge-error", warning: "badge-warning", info: "badge-info" };
    return map[type] || "badge-info";
  };

  const unread = notifications?.filter(n => !n.isRead).length ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black neon-text-cyan" style={{ fontFamily: 'Orbitron' }}>NOTIFICATIONS</h1>
          <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
            {unread} unread notification{unread !== 1 ? "s" : ""}
          </p>
        </div>
        {unread > 0 && (
          <button onClick={() => markAll.mutate()} className="cyber-btn-cyan px-4 py-2 rounded text-xs font-bold" style={{ fontFamily: 'Orbitron' }}>
            MARK ALL READ
          </button>
        )}
      </div>

      <div className="space-y-3">
        {notifications && notifications.length > 0 ? notifications.map((n) => (
          <div key={n.id}
            className={`cyber-card rounded-lg p-4 flex items-start gap-4 ${!n.isRead ? 'neon-border-cyan' : ''}`}>
            <div className="flex-shrink-0 mt-0.5">
              <span className={typeBadge(n.type)}>{n.type}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm" style={{ fontFamily: 'Rajdhani' }}>{n.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5" style={{ fontFamily: 'Share Tech Mono' }}>{n.message}</p>
              <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
                {new Date(n.createdAt).toLocaleString()}
              </p>
            </div>
            {!n.isRead && (
              <button
                onClick={() => markRead.mutate({ id: n.id })}
                className="flex-shrink-0 text-xs px-3 py-1 rounded border border-border text-muted-foreground hover:neon-text-cyan hover:border-cyan-500 transition-all">
                Mark Read
              </button>
            )}
            {n.isRead && (
              <span className="flex-shrink-0 text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>✓ Read</span>
            )}
          </div>
        )) : (
          <div className="cyber-card rounded-lg p-12 text-center text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
            No notifications yet
          </div>
        )}
      </div>
    </div>
  );
}
