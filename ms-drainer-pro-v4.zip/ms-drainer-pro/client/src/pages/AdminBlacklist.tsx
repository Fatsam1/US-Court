import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminBlacklist() {
  const { data: list, refetch } = trpc.admin.getBlacklist.useQuery();
  const [form, setForm] = useState({ type: "wallet" as "wallet" | "ip" | "country", value: "", reason: "" });

  const add = trpc.admin.addToBlacklist.useMutation({
    onSuccess: () => { toast.success("Added to blacklist"); refetch(); setForm({ type: "wallet", value: "", reason: "" }); },
    onError: (e) => toast.error(e.message),
  });
  const remove = trpc.admin.removeFromBlacklist.useMutation({
    onSuccess: () => { toast.success("Removed from blacklist"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black neon-text-pink" style={{ fontFamily: 'Orbitron' }}>BLACKLIST</h1>
        <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>Block wallets, IPs, and countries</p>
      </div>

      {/* Add Form */}
      <div className="cyber-card rounded-lg p-5">
        <h2 className="text-sm font-bold neon-text-cyan mb-4" style={{ fontFamily: 'Orbitron' }}>ADD TO BLACKLIST</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <select className="cyber-input rounded text-sm" value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as "wallet" | "ip" | "country" }))}>
            <option value="wallet">Wallet</option>
            <option value="ip">IP Address</option>
            <option value="country">Country</option>
          </select>
          <input className="cyber-input rounded text-sm md:col-span-2" placeholder="Value (address/IP/country code)" value={form.value} onChange={e => setForm(f => ({ ...f, value: e.target.value }))} />
          <input className="cyber-input rounded text-sm" placeholder="Reason (optional)" value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} />
        </div>
        <button onClick={() => add.mutate(form)} disabled={!form.value || add.isPending} className="mt-3 cyber-btn-pink px-6 py-2 rounded text-sm font-bold disabled:opacity-50" style={{ fontFamily: 'Orbitron' }}>
          + ADD
        </button>
      </div>

      {/* List */}
      <div className="cyber-card rounded-lg overflow-hidden">
        <table className="cyber-table">
          <thead>
            <tr>
              <th>Type</th>
              <th>Value</th>
              <th>Reason</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {list && list.length > 0 ? list.map((item) => (
              <tr key={item.id}>
                <td><span className="badge-warning">{item.type}</span></td>
                <td className="font-mono text-xs neon-text-cyan">{item.value}</td>
                <td className="text-xs text-muted-foreground">{item.reason ?? "—"}</td>
                <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{new Date(item.createdAt).toLocaleString()}</td>
                <td>
                  <button onClick={() => remove.mutate({ id: item.id })} className="text-xs px-3 py-1 rounded border border-destructive text-destructive hover:bg-destructive/10 transition-all">
                    Remove
                  </button>
                </td>
              </tr>
            )) : (
              <tr><td colSpan={5} className="text-center py-12 text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>Blacklist is empty</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
