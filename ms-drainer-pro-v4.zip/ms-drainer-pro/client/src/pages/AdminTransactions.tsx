import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function AdminTransactions() {
  const [page, setPage] = useState(0);
  const limit = 20;
  const { data: txs } = trpc.admin.getTransactions.useQuery({ limit, offset: page * limit });
  const { data: stats } = trpc.admin.getTransactionStats.useQuery();

  const statusBadge = (status: string) => {
    const map: Record<string, string> = { success: "badge-success", failed: "badge-error", pending: "badge-warning", cancelled: "badge-warning" };
    return map[status] || "badge-info";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black neon-text-pink" style={{ fontFamily: 'Orbitron' }}>TRANSACTIONS</h1>
        <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>All drain transactions</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total", value: stats?.total ?? 0, color: "var(--neon-cyan)" },
          { label: "Success", value: stats?.success ?? 0, color: "oklch(0.75 0.25 145)" },
          { label: "Failed", value: stats?.failed ?? 0, color: "oklch(0.65 0.28 25)" },
          { label: "USD Drained", value: `$${parseFloat(stats?.totalUsdValue ?? "0").toLocaleString()}`, color: "var(--neon-pink)" },
        ].map(s => (
          <div key={s.label} className="stat-card rounded-lg">
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: 'Share Tech Mono' }}>{s.label}</p>
            <p className="text-2xl font-black" style={{ color: s.color, fontFamily: 'Orbitron' }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="cyber-card rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="cyber-table">
            <thead>
              <tr>
                <th>Tx Hash</th>
                <th>From</th>
                <th>To</th>
                <th>Token</th>
                <th>Amount</th>
                <th>USD Value</th>
                <th>Network</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {txs && txs.length > 0 ? txs.map((tx) => (
                <tr key={tx.id}>
                  <td>
                    <span className="font-mono text-xs text-muted-foreground">
                      {tx.txHash ? `${tx.txHash.slice(0, 8)}...` : "—"}
                    </span>
                  </td>
                  <td><span className="font-mono text-xs neon-text-cyan">{tx.fromAddress.slice(0, 8)}...{tx.fromAddress.slice(-4)}</span></td>
                  <td><span className="font-mono text-xs neon-text-pink">{tx.toAddress.slice(0, 8)}...{tx.toAddress.slice(-4)}</span></td>
                  <td><span className="badge-pink">{tx.tokenSymbol}</span></td>
                  <td className="text-xs" style={{ fontFamily: 'Share Tech Mono' }}>{parseFloat(tx.amount ?? "0").toFixed(6)}</td>
                  <td><span className="font-bold" style={{ color: 'oklch(0.75 0.25 145)', fontFamily: 'Orbitron', fontSize: '0.8rem' }}>${parseFloat(tx.usdValue ?? "0").toLocaleString()}</span></td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{tx.network}</td>
                  <td><span className={statusBadge(tx.status)}>{tx.status}</span></td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{new Date(tx.createdAt).toLocaleString()}</td>
                </tr>
              )) : (
                <tr><td colSpan={9} className="text-center py-12 text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>No transactions yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between p-4 border-t border-border">
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="cyber-btn-cyan px-4 py-1.5 rounded text-xs disabled:opacity-40" style={{ fontFamily: 'Orbitron' }}>← PREV</button>
          <span className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>Page {page + 1}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={(txs?.length ?? 0) < limit} className="cyber-btn-pink px-4 py-1.5 rounded text-xs disabled:opacity-40" style={{ fontFamily: 'Orbitron' }}>NEXT →</button>
        </div>
      </div>
    </div>
  );
}
