import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function AdminLogs() {
  const [page, setPage] = useState(0);
  const limit = 50;
  const { data: logs } = trpc.admin.getLogs.useQuery({ limit, offset: page * limit });

  const levelBadge = (level: string) => {
    const map: Record<string, string> = { success: "badge-success", error: "badge-error", warning: "badge-warning", info: "badge-info" };
    return map[level] || "badge-info";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black neon-text-cyan" style={{ fontFamily: 'Orbitron' }}>ACTIVITY LOGS</h1>
        <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: 'Share Tech Mono' }}>System activity and event logs</p>
      </div>

      <div className="cyber-card rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="cyber-table">
            <thead>
              <tr>
                <th>Level</th>
                <th>Action</th>
                <th>Description</th>
                <th>Wallet</th>
                <th>IP</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {logs && logs.length > 0 ? logs.map((log) => (
                <tr key={log.id}>
                  <td><span className={levelBadge(log.level)}>{log.level}</span></td>
                  <td className="font-medium text-sm" style={{ fontFamily: 'Rajdhani' }}>{log.action}</td>
                  <td className="text-xs text-muted-foreground max-w-xs truncate" style={{ fontFamily: 'Share Tech Mono' }}>
                    {log.description ?? "—"}
                  </td>
                  <td>
                    {log.walletAddress ? (
                      <span className="font-mono text-xs neon-text-cyan">
                        {log.walletAddress.slice(0, 8)}...{log.walletAddress.slice(-4)}
                      </span>
                    ) : "—"}
                  </td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>{log.ipAddress ?? "—"}</td>
                  <td className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>
                    {new Date(log.createdAt).toLocaleString()}
                  </td>
                </tr>
              )) : (
                <tr><td colSpan={6} className="text-center py-12 text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>No logs yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between p-4 border-t border-border">
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="cyber-btn-cyan px-4 py-1.5 rounded text-xs disabled:opacity-40" style={{ fontFamily: 'Orbitron' }}>← PREV</button>
          <span className="text-xs text-muted-foreground" style={{ fontFamily: 'Share Tech Mono' }}>Page {page + 1}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={(logs?.length ?? 0) < limit} className="cyber-btn-pink px-4 py-1.5 rounded text-xs disabled:opacity-40" style={{ fontFamily: 'Orbitron' }}>NEXT →</button>
        </div>
      </div>
    </div>
  );
}
